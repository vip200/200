# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from datetime import date ,datetime ,timedelta #line:29
from resources .libs import extract ,downloader ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:30
ADDON_ID =uservar .ADDON_ID #line:32
ADDONTITLE =uservar .ADDONTITLE #line:33
ADDON =wiz .addonId (ADDON_ID )#line:34
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:35
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:36
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:37
DIALOG =xbmcgui .Dialog ()#line:38
DP =xbmcgui .DialogProgress ()#line:39
HOME =xbmc .translatePath ('special://home/')#line:40
PROFILE =xbmc .translatePath ('special://profile/')#line:41
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:42
ADDONS =os .path .join (HOME ,'addons')#line:43
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:44
USERDATA =os .path .join (HOME ,'userdata')#line:45
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:46
PACKAGES =os .path .join (ADDONS ,'packages')#line:47
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:48
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:49
ICON =os .path .join (ADDONPATH ,'icon.png')#line:50
ART =os .path .join (ADDONPATH ,'resources','art')#line:51
SKIN =xbmc .getSkinDir ()#line:52
BUILDNAME =wiz .getS ('buildname')#line:53
DEFAULTSKIN =wiz .getS ('defaultskin')#line:54
DEFAULTNAME =wiz .getS ('defaultskinname')#line:55
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:56
BUILDVERSION =wiz .getS ('buildversion')#line:57
BUILDLATEST =wiz .getS ('latestversion')#line:58
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:59
DISABLEUPDATE =wiz .getS ('disableupdate')#line:60
AUTOCLEANUP =wiz .getS ('autoclean')#line:61
AUTOCACHE =wiz .getS ('clearcache')#line:62
AUTOPACKAGES =wiz .getS ('clearpackages')#line:63
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:64
AUTOFEQ =wiz .getS ('autocleanfeq')#line:65
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:66
TRAKTSAVE =wiz .getS ('traktlastsave')#line:67
REALSAVE =wiz .getS ('debridlastsave')#line:68
LOGINSAVE =wiz .getS ('loginlastsave')#line:69
KEEPTRAKT =wiz .getS ('keeptrakt')#line:70
KEEPREAL =wiz .getS ('keepdebrid')#line:71
KEEPLOGIN =wiz .getS ('keeplogin')#line:72
INSTALLED =wiz .getS ('installed')#line:73
EXTRACT =wiz .getS ('extract')#line:74
EXTERROR =wiz .getS ('errors')#line:75
NOTIFY =wiz .getS ('notify')#line:76
NOTEDISMISS =wiz .getS ('notedismiss')#line:77
NOTEID =wiz .getS ('noteid')#line:78
NOTIFY2 =wiz .getS ('notify2')#line:79
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:80
NOTEID2 =wiz .getS ('noteid2')#line:81
NOTIFY3 =wiz .getS ('notify3')#line:82
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:83
NOTEID3 =wiz .getS ('noteid3')#line:84
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:85
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:86
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:87
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:88
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:89
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:90
TODAY =date .today ()#line:91
TOMORROW =TODAY +timedelta (days =1 )#line:92
TWODAYS =TODAY +timedelta (days =2 )#line:93
THREEDAYS =TODAY +timedelta (days =3 )#line:94
ONEWEEK =TODAY +timedelta (days =7 )#line:95
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:96
EXCLUDES =uservar .EXCLUDES #line:97
SPEEDFILE =speedtest .SPEEDFILE #line:98
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:99
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:100
NOTIFICATION =uservar .NOTIFICATION #line:101
NOTIFICATION2 =uservar .NOTIFICATION2 #line:102
NOTIFICATION3 =uservar .NOTIFICATION3 #line:103
ENABLE =uservar .ENABLE #line:104
HEADERMESSAGE =uservar .HEADERMESSAGE #line:105
AUTOUPDATE =uservar .AUTOUPDATE #line:106
WIZARDFILE =uservar .WIZARDFILE #line:107
AUTOINSTALL =uservar .AUTOINSTALL #line:108
REPOID =uservar .REPOID #line:109
REPOADDONXML =uservar .REPOADDONXML #line:110
REPOZIPURL =uservar .REPOZIPURL #line:111
REPOID18 =uservar .REPOID18 #line:112
REPOADDONXML18 =uservar .REPOADDONXML18 #line:113
REPOZIPURL18 =uservar .REPOZIPURL18 #line:114
COLOR1 =uservar .COLOR1 #line:115
COLOR2 =uservar .COLOR2 #line:116
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:117
FAILED =False #line:118
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:119
AddonID ='plugin.program.Anonymous'#line:121
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:122
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:123
dialog =xbmcgui .Dialog ()#line:124
setting =xbmcaddon .Addon ().getSetting #line:125
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:126
notify_mode =setting ('notify_mode')#line:127
auto_clean =setting ('startup.cache')#line:128
filesize_thumb =int (setting ('filesizethumb_alert'))#line:130
total_size2 =0 #line:133
total_size =0 #line:134
count =0 #line:135
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:141
if AUTOUPDATE =='Yes':#line:142
	xbmc .executebuiltin ("UpdateLocalAddons")#line:143
	xbmc .executebuiltin ("UpdateAddonRepos")#line:144
	wiz .wizardUpdate ('startup')#line:145
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:146
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:150
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:151
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','Please Wait....')))#line:152
	workingxml =wiz .workingURL (REPOADDONXML )#line:153
	if workingxml ==True :#line:154
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:155
		if len (ver )>0 :#line:156
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:157
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:158
			if workingrepo ==True :#line:159
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:160
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:161
				lib =os .path .join (PACKAGES ,installzip )#line:162
				try :os .remove (lib )#line:163
				except :pass #line:164
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:165
				extract .all (lib ,ADDONS ,DP )#line:166
				try :#line:167
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:168
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:169
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:170
				except :#line:171
					pass #line:172
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:173
				DP .close ()#line:174
				xbmc .sleep (500 )#line:175
				wiz .forceUpdate (True )#line:176
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:177
				xbmc .executebuiltin ("ReloadSkin()")#line:178
				xbmc .executebuiltin ("ActivateWindow(home)")#line:179
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:180
				xbmc .Player ().play (f_play ,windowed =False )#line:181
			else :#line:183
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:184
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:185
		else :#line:186
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:187
	else :#line:188
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:189
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:190
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:191
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:192
if AUTOINSTALL =='Yes'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:195
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:196
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Kodi Anonymous','Please Wait....')))#line:197
	if workingxml ==True :#line:198
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:199
		if len (ver )>0 :#line:200
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:201
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:202
			if workingrepo ==True :#line:203
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:204
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:205
				lib =os .path .join (PACKAGES ,installzip )#line:206
				try :os .remove (lib )#line:207
				except :pass #line:208
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:209
				extract .all (lib ,ADDONS ,DP )#line:210
				try :#line:211
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:212
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:213
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:214
				except :#line:215
					pass #line:216
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:217
				DP .close ()#line:218
				xbmc .sleep (500 )#line:219
				wiz .forceUpdate (True )#line:220
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:221
				xbmc .executebuiltin ("ReloadSkin()")#line:222
				xbmc .executebuiltin ("ActivateWindow(home)")#line:223
				f_play =(os .path .join (ADDONPATH ,'resources','victory.mp4'))#line:224
				xbmc .Player ().play (f_play ,windowed =False )#line:225
			else :#line:227
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:228
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:229
		else :#line:230
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:231
	else :#line:232
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:233
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:234
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:236
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:237
def skinWIN ():#line:242
	idle ()#line:243
	OOO0OOOOOO0O0O00O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:244
	O000O00O0OO0O0O0O =[];O00OOO000000OO00O =[]#line:245
	for OOOO0000O000O00O0 in sorted (OOO0OOOOOO0O0O00O ,key =lambda OO000OOO00O0OOO00 :OO000OOO00O0OOO00 ):#line:246
		OOO0OO00OOOOOO0OO =os .path .split (OOOO0000O000O00O0 [:-1 ])[1 ]#line:247
		O0O0OOOOOO0000000 =os .path .join (OOOO0000O000O00O0 ,'addon.xml')#line:248
		if os .path .exists (O0O0OOOOOO0000000 ):#line:249
			OO000000OO0OO0O0O =open (O0O0OOOOOO0000000 )#line:250
			OO0OOO00O0O00O000 =OO000000OO0OO0O0O .read ()#line:251
			OO0O00O0000O0O0OO =parseDOM2 (OO0OOO00O0O00O000 ,'addon',ret ='id')#line:252
			O0O0000OOO00O0O0O =OOO0OO00OOOOOO0OO if len (OO0O00O0000O0O0OO )==0 else OO0O00O0000O0O0OO [0 ]#line:253
			try :#line:254
				OO0OO0O0OOO0OO00O =xbmcaddon .Addon (id =O0O0000OOO00O0O0O )#line:255
				O000O00O0OO0O0O0O .append (OO0OO0O0OOO0OO00O .getAddonInfo ('name'))#line:256
				O00OOO000000OO00O .append (O0O0000OOO00O0O0O )#line:257
			except :#line:258
				pass #line:259
	O00OO00000O00OOOO =[];OO000O0O0O0OO00O0 =0 #line:260
	OO00O00O0000OOOOO =["Current Skin -- %s"%currSkin ()]+O000O00O0OO0O0O0O #line:261
	OO000O0O0O0OO00O0 =DIALOG .select ("Select the Skin you want to swap with.",OO00O00O0000OOOOO )#line:262
	if OO000O0O0O0OO00O0 ==-1 :return #line:263
	else :#line:264
		OOO0O0OO00OOO0O0O =(OO000O0O0O0OO00O0 -1 )#line:265
		O00OO00000O00OOOO .append (OOO0O0OO00OOO0O0O )#line:266
		OO00O00O0000OOOOO [OO000O0O0O0OO00O0 ]="%s"%(O000O00O0OO0O0O0O [OOO0O0OO00OOO0O0O ])#line:267
	if O00OO00000O00OOOO ==None :return #line:268
	for O00O0OOO0O0O0000O in O00OO00000O00OOOO :#line:269
		swapSkins (O00OOO000000OO00O [O00O0OOO0O0O0000O ])#line:270
def currSkin ():#line:272
	return xbmc .getSkinDir ('Container.PluginName')#line:273
def fix17update ():#line:275
	if KODIV >=17 and KODIV <18 :#line:276
		wiz .kodi17Fix ()#line:277
		xbmc .sleep (4000 )#line:278
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:279
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:280
		fixfont ()#line:281
		O0OO0OOOOOOO0O0OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:282
		try :#line:284
			OOOO0OOOO0O00OO0O =open (O0OO0OOOOOOO0O0OO ,'r')#line:285
			O00OO00O000O0000O =OOOO0OOOO0O00OO0O .read ()#line:286
			OOOO0OOOO0O00OO0O .close ()#line:287
			OO00OOO0OO0OO0000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:288
			OO0OO000O000OO0O0 =re .compile (OO00OOO0OO0OO0000 ).findall (O00OO00O000O0000O )[0 ]#line:289
			OOOO0OOOO0O00OO0O =open (O0OO0OOOOOOO0O0OO ,'w')#line:290
			OOOO0OOOO0O00OO0O .write (O00OO00O000O0000O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0OO000O000OO0O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:291
			OOOO0OOOO0O00OO0O .close ()#line:292
		except :#line:293
				pass #line:294
		wiz .kodi17Fix ()#line:295
		O0OO0OOOOOOO0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:296
		try :#line:297
			OOOO0OOOO0O00OO0O =open (O0OO0OOOOOOO0O0OO ,'r')#line:298
			O00OO00O000O0000O =OOOO0OOOO0O00OO0O .read ()#line:299
			OOOO0OOOO0O00OO0O .close ()#line:300
			OO00OOO0OO0OO0000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:301
			OO0OO000O000OO0O0 =re .compile (OO00OOO0OO0OO0000 ).findall (O00OO00O000O0000O )[0 ]#line:302
			OOOO0OOOO0O00OO0O =open (O0OO0OOOOOOO0O0OO ,'w')#line:303
			OOOO0OOOO0O00OO0O .write (O00OO00O000O0000O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0OO000O000OO0O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:304
			OOOO0OOOO0O00OO0O .close ()#line:305
		except :#line:306
				pass #line:307
		swapSkins ('skin.Premium.mod')#line:308
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:309
	os ._exit (1 )#line:310
def fix18update ():#line:311
	if KODIV >=18 :#line:312
		xbmc .sleep (4000 )#line:313
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:314
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:315
		fixfont ()#line:316
		O000000OO0OOO0OOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:317
		try :#line:318
			OOOO00OO000O00000 =open (O000000OO0OOO0OOO ,'r')#line:319
			OO00000OO0OO00000 =OOOO00OO000O00000 .read ()#line:320
			OOOO00OO000O00000 .close ()#line:321
			OO0000OOOO0OO00OO ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:322
			O0O0OOO0O0OO00000 =re .compile (OO0000OOOO0OO00OO ).findall (OO00000OO0OO00000 )[0 ]#line:323
			OOOO00OO000O00000 =open (O000000OO0OOO0OOO ,'w')#line:324
			OOOO00OO000O00000 .write (OO00000OO0OO00000 .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0OOO0O0OO00000 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:325
			OOOO00OO000O00000 .close ()#line:326
		except :#line:327
				pass #line:328
		wiz .kodi17Fix ()#line:329
		O000000OO0OOO0OOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:330
		try :#line:331
			OOOO00OO000O00000 =open (O000000OO0OOO0OOO ,'r')#line:332
			OO00000OO0OO00000 =OOOO00OO000O00000 .read ()#line:333
			OOOO00OO000O00000 .close ()#line:334
			OO0000OOOO0OO00OO ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:335
			O0O0OOO0O0OO00000 =re .compile (OO0000OOOO0OO00OO ).findall (OO00000OO0OO00000 )[0 ]#line:336
			OOOO00OO000O00000 =open (O000000OO0OOO0OOO ,'w')#line:337
			OOOO00OO000O00000 .write (OO00000OO0OO00000 .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0OOO0O0OO00000 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:338
			OOOO00OO000O00000 .close ()#line:339
		except :#line:340
				pass #line:341
		swapSkins ('skin.Premium.mod')#line:342
	xbmcgui .Dialog ().ok ("Kodi Anonymous Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:343
	os ._exit (1 )#line:344
def swapSkins (O000O00OOO0O0000O ,title ="Error"):#line:345
	OOOOO0O000OO000OO ='lookandfeel.skin'#line:346
	OOOOOOOOO00000000 =O000O00OOO0O0000O #line:347
	O000O0O0O0OOO0O0O =getOld (OOOOO0O000OO000OO )#line:348
	O0OO0OOO00O0OO00O =OOOOO0O000OO000OO #line:349
	setNew (O0OO0OOO00O0OO00O ,OOOOOOOOO00000000 )#line:350
	O0OO00OO0O0OO0OO0 =0 #line:351
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO00OO0O0OO0OO0 <100 :#line:352
		O0OO00OO0O0OO0OO0 +=1 #line:353
		xbmc .sleep (1 )#line:354
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:355
		xbmc .executebuiltin ('SendClick(11)')#line:356
	return True #line:357
def getOld (O0OOOO0O0OO0O00OO ):#line:359
	try :#line:360
		O0OOOO0O0OO0O00OO ='"%s"'%O0OOOO0O0OO0O00OO #line:361
		OOOO00O0O000O00O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O0OOOO0O0OO0O00OO )#line:362
		OOOO0O0OO0O000OOO =xbmc .executeJSONRPC (OOOO00O0O000O00O0 )#line:364
		OOOO0O0OO0O000OOO =simplejson .loads (OOOO0O0OO0O000OOO )#line:365
		if OOOO0O0OO0O000OOO .has_key ('result'):#line:366
			if OOOO0O0OO0O000OOO ['result'].has_key ('value'):#line:367
				return OOOO0O0OO0O000OOO ['result']['value']#line:368
	except :#line:369
		pass #line:370
	return None #line:371
def setNew (OOO0O0O0OO0O00O0O ,OOOOOO0OO0O0OO0O0 ):#line:374
	try :#line:375
		OOO0O0O0OO0O00O0O ='"%s"'%OOO0O0O0OO0O00O0O #line:376
		OOOOOO0OO0O0OO0O0 ='"%s"'%OOOOOO0OO0O0OO0O0 #line:377
		OO00OO0OOO00OO000 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0O0O0OO0O00O0O ,OOOOOO0OO0O0OO0O0 )#line:378
		OO0OO00O00000O00O =xbmc .executeJSONRPC (OO00OO0OOO00OO000 )#line:380
	except :#line:381
		pass #line:382
	return None #line:383
def idle ():#line:384
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:385
def fixfont ():#line:386
	OOO0O00OOOOOOOO00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:387
	O0OOOOO0O00000O0O =json .loads (OOO0O00OOOOOOOO00 );#line:389
	O00OOO0O0O0O0O0O0 =O0OOOOO0O00000O0O ["result"]["settings"]#line:390
	O00OO00O000000OO0 =[OOO0000OO0000OOO0 for OOO0000OO0000OOO0 in O00OOO0O0O0O0O0O0 if OOO0000OO0000OOO0 ["id"]=="audiooutput.audiodevice"][0 ]#line:392
	O00O000O0O0O0O0O0 =O00OO00O000000OO0 ["options"];#line:393
	O00O0O00O000000O0 =O00OO00O000000OO0 ["value"];#line:394
	O0OO00OO0OOOO0OO0 =[O0OO00OO0OOOO0OOO for (O0OO00OO0OOOO0OOO ,OOO000OOO0000O0OO )in enumerate (O00O000O0O0O0O0O0 )if OOO000OOO0000O0OO ["value"]==O00O0O00O000000O0 ][0 ];#line:396
	OOOOOOOO0O0O00OO0 =(O0OO00OO0OOOO0OO0 +1 )%len (O00O000O0O0O0O0O0 )#line:398
	OOO00OO00O000O00O =O00O000O0O0O0O0O0 [OOOOOOOO0O0O00OO0 ]["value"]#line:400
	O0OOO000OO00O0O00 =O00O000O0O0O0O0O0 [OOOOOOOO0O0O00OO0 ]["label"]#line:401
	O00O0O000OO00OOOO =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:403
	try :#line:405
		OO00OO0OOO00OOO0O =json .loads (O00O0O000OO00OOOO );#line:406
		if OO00OO0OOO00OOO0O ["result"]!=True :#line:408
			raise Exception #line:409
	except :#line:410
		sys .stderr .write ("Error switching audio output device")#line:411
		raise Exception #line:412
def checkSkin ():#line:415
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:416
	OO0OO0000OOO00000 =wiz .getS ('defaultskin')#line:417
	OO00OO0O0OO0000O0 =wiz .getS ('defaultskinname')#line:418
	OOO00OOOO0OOOOO00 =wiz .getS ('defaultskinignore')#line:419
	OOOOOO0O0OOOO000O =False #line:420
	if not OO0OO0000OOO00000 =='':#line:421
		if os .path .exists (os .path .join (ADDONS ,OO0OO0000OOO00000 )):#line:422
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO00OO0O0OO0000O0 )):#line:423
				OOOOOO0O0OOOO000O =OO0OO0000OOO00000 #line:424
				OOO0OO0OOO0000OO0 =OO00OO0O0OO0000O0 #line:425
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');OOOOOO0O0OOOO000O =False #line:426
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OO0OO0000OOO00000 ='';OO00OO0O0OO0000O0 =''#line:427
	if OO0OO0000OOO00000 =='':#line:428
		OOO0O000000O0O00O =[]#line:429
		OOOOOOO0O000OO00O =[]#line:430
		for O0O00O00O0O00O00O in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:431
			O0O0OOOO00OO0OO00 ="%s/addon.xml"%O0O00O00O0O00O00O #line:432
			if os .path .exists (O0O0OOOO00OO0OO00 ):#line:433
				OOOOOOO0000OO000O =open (O0O0OOOO00OO0OO00 ,mode ='r');O000OO000OOO000O0 =OOOOOOO0000OO000O .read ().replace ('\n','').replace ('\r','').replace ('\t','');OOOOOOO0000OO000O .close ();#line:434
				O0O0OO00O0OO0O0OO =wiz .parseDOM (O000OO000OOO000O0 ,'addon',ret ='id')#line:435
				O00OOO0OO0OOOOO00 =wiz .parseDOM (O000OO000OOO000O0 ,'addon',ret ='name')#line:436
				wiz .log ("%s: %s"%(O0O00O00O0O00O00O ,str (O0O0OO00O0OO0O0OO [0 ])),xbmc .LOGNOTICE )#line:437
				if len (O0O0OO00O0OO0O0OO )>0 :OOOOOOO0O000OO00O .append (str (O0O0OO00O0OO0O0OO [0 ]));OOO0O000000O0O00O .append (str (O00OOO0OO0OOOOO00 [0 ]))#line:438
				else :wiz .log ("ID not found for %s"%O0O00O00O0O00O00O ,xbmc .LOGNOTICE )#line:439
			else :wiz .log ("ID not found for %s"%O0O00O00O0O00O00O ,xbmc .LOGNOTICE )#line:440
		if len (OOOOOOO0O000OO00O )>0 :#line:441
			if len (OOOOOOO0O000OO00O )>1 :#line:442
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:443
					O0OOO00OO0OOO0000 =DIALOG .select ("Select skin to switch to!",OOO0O000000O0O00O )#line:444
					if O0OOO00OO0OOO0000 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:445
					else :#line:446
						OOOOOO0O0OOOO000O =OOOOOOO0O000OO00O [O0OOO00OO0OOO0000 ]#line:447
						OOO0OO0OOO0000OO0 =OOO0O000000O0O00O [O0OOO00OO0OOO0000 ]#line:448
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:449
	if OOOOOO0O0OOOO000O :#line:456
		skinSwitch .swapSkins (OOOOOO0O0OOOO000O )#line:457
		O0OO0O000OOOOO0O0 =0 #line:458
		xbmc .sleep (1000 )#line:459
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO0O000OOOOO0O0 <150 :#line:460
			O0OO0O000OOOOO0O0 +=1 #line:461
			xbmc .sleep (200 )#line:462
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:464
			wiz .ebi ('SendClick(11)')#line:465
			wiz .lookandFeelData ('restore')#line:466
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:467
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:468
while xbmc .Player ().isPlayingVideo ():#line:470
	xbmc .sleep (1000 )#line:471
if KODIV >=17 :#line:473
	NOW =datetime .now ()#line:474
	temp =wiz .getS ('kodi17iscrap')#line:475
	if not temp =='':#line:476
		if temp >str (NOW -timedelta (minutes =2 )):#line:477
			wiz .log ("Killing Start Up Script")#line:478
			sys .exit ()#line:479
	wiz .log ("%s"%(NOW ))#line:480
	wiz .setS ('kodi17iscrap',str (NOW ))#line:481
	xbmc .sleep (1000 )#line:482
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:483
		wiz .log ("Killing Start Up Script")#line:484
		sys .exit ()#line:485
	else :#line:486
		wiz .log ("Continuing Start Up Script")#line:487
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:489
path =os .path .split (ADDONPATH )#line:490
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:491
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:492
if KODIADDONS in ADDONPATH :#line:495
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:496
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:497
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:498
	if os .path .exists (newpath ):#line:499
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:500
		wiz .cleanHouse (newpath )#line:501
		wiz .removeFolder (newpath )#line:502
	try :#line:503
		wiz .copytree (ADDONPATH ,newpath )#line:504
	except Exception as e :#line:505
		pass #line:506
	wiz .forceUpdate (True )#line:507
try :#line:509
	mybuilds =xbmc .translatePath (MYBUILDS )#line:510
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:511
except :#line:512
	pass #line:513
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:515
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary']and not BUILDNAME =="":#line:519
			wiz .kodi17Fix ()#line:520
			fix18update ()#line:521
			fix17update ()#line:522
def checkUpdate ():#line:604
	O00OOO0O00O00O0OO =wiz .getS ('buildname')#line:605
	O00OO00OO0OO0OO00 =wiz .getS ('buildversion')#line:606
	OOOOOO00O0000O0OO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:607
	O0OOO0OOO0O00OO0O =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O00OOO0O00O00O0OO ).findall (OOOOOO00O0000O0OO )#line:608
	if len (O0OOO0OOO0O00OO0O )>0 :#line:609
		O0OO000O0O0O0O00O =O0OOO0OOO0O00OO0O [0 ][0 ]#line:610
		O0O0O0OO00O0000O0 =O0OOO0OOO0O00OO0O [0 ][1 ]#line:611
		OO0OO00000O00OOOO =O0OOO0OOO0O00OO0O [0 ][2 ]#line:612
		wiz .setS ('latestversion',O0OO000O0O0O0O00O )#line:613
		if O0OO000O0O0O0O00O >O00OO00OO0OO0OO00 :#line:614
			if DISABLEUPDATE =='false':#line:615
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O00OO00OO0OO0OO00 ,O0OO000O0O0O0O00O ),xbmc .LOGNOTICE )#line:616
				notify .updateWindow (O00OOO0O00O00O0OO ,O00OO00OO0OO0OO00 ,O0OO000O0O0O0O00O ,O0O0O0OO00O0000O0 ,OO0OO00000O00OOOO )#line:617
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O00OO00OO0OO0OO00 ,O0OO000O0O0O0O00O ),xbmc .LOGNOTICE )#line:618
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O00OO00OO0OO0OO00 ,O0OO000O0O0O0O00O ),xbmc .LOGNOTICE )#line:619
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:620
	addItem ('Skin Premium','url',5 ,O0O0O0OO00O0000O0 ,OO0OO00000O00OOOO ,'')#line:647
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:649
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium":#line:651
	if not NOTIFY =='true':#line:652
		url =wiz .workingURL (NOTIFICATION )#line:653
		if url ==True :#line:654
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:655
			if not id ==False :#line:656
				try :#line:657
					id =int (id );NOTEID =int (NOTEID )#line:658
					if id ==NOTEID :#line:659
						if NOTEDISMISS =='false':#line:660
							notify .notification (msg )#line:661
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:662
					elif id >NOTEID :#line:663
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:664
						wiz .setS ('noteid',str (id ))#line:665
						wiz .setS ('notedismiss','false')#line:666
						notify .notification (msg =msg )#line:667
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:668
				except Exception as e :#line:669
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:670
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:671
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:672
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:673
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:674
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:676
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:677
	if not NOTIFY2 =='true':#line:678
		url =wiz .workingURL (NOTIFICATION2 )#line:679
		if url ==True :#line:680
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:681
			if not id ==False :#line:682
				try :#line:683
					id =int (id );NOTEID2 =int (NOTEID2 )#line:684
					if id ==NOTEID2 :#line:685
						if NOTEDISMISS2 =='false':#line:686
							notify .notification2 (msg )#line:687
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:688
					elif id >NOTEID2 :#line:689
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:690
						wiz .setS ('noteid2',str (id ))#line:691
						wiz .setS ('notedismiss2','false')#line:692
						notify .notification2 (msg =msg )#line:693
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:694
				except Exception as e :#line:695
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:696
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:697
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:698
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:699
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:700
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:702
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:703
	if not NOTIFY3 =='true':#line:704
		url =wiz .workingURL (NOTIFICATION3 )#line:705
		if url ==True :#line:706
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:707
			if not id ==False :#line:708
				try :#line:709
					id =int (id );NOTEID3 =int (NOTEID3 )#line:710
					if id ==NOTEID3 :#line:711
						if NOTEDISMISS3 =='false':#line:712
							notify .notification3 (msg )#line:713
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:714
					elif id >NOTEID3 :#line:715
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:716
						wiz .setS ('noteid3',str (id ))#line:717
						wiz .setS ('notedismiss3','false')#line:718
						notify .notification3 (msg =msg )#line:719
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:720
				except Exception as e :#line:721
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:722
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:723
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:724
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:725
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:726
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:727
if KEEPTRAKT =='true':#line:728
	if TRAKTSAVE <=str (TODAY ):#line:729
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:730
		traktit .autoUpdate ('all')#line:731
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:732
	else :#line:733
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:734
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:735
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:737
if KEEPREAL =='true':#line:738
	if REALSAVE <=str (TODAY ):#line:739
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:740
		debridit .autoUpdate ('all')#line:741
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:742
	else :#line:743
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:744
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:745
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:747
if KEEPLOGIN =='true':#line:748
	if LOGINSAVE <=str (TODAY ):#line:749
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:750
		loginit .autoUpdate ('all')#line:751
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:752
	else :#line:753
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:754
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:755
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:757
if AUTOCLEANUP =='true':#line:758
	service =False #line:759
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:760
	feq =int (float (AUTOFEQ ))#line:761
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:762
		service =True #line:763
		next_run =days [feq ]#line:764
		wiz .setS ('nextautocleanup',str (next_run ))#line:765
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:766
	if service ==True :#line:767
		AUTOCACHE =wiz .getS ('clearcache')#line:768
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:769
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:770
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:771
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:772
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:773
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:774
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:775
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:776
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:777
wiz .setS ('kodi17iscrap','')#line:779
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:841
	count =0 #line:842
	for f in filenames :#line:843
		count +=1 #line:844
		fp =os .path .join (dirpath ,f )#line:845
		total_size +=os .path .getsize (fp )#line:846
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:847
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:854
	for f2 in filenames2 :#line:855
		fp2 =os .path .join (dirpath2 ,f2 )#line:856
		total_size2 +=os .path .getsize (fp2 )#line:857
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:858
if int (total_sizetext2 )>filesize_thumb :#line:860
	choice2 =xbmcgui .Dialog ().yesno ("[COLOR=red]קודי אנונימוס - ניקוי תמונות פוסטרים ישנות[/COLOR]",'[COLOR red]'+str (total_sizetext2 )+' MB  :גודל התיקיה היא [/COLOR]','מומלץ למחוק את התיקיה בשביל לפנות מקום נוסף במכשיר','האם ברצונך למחוק אותה עכשיו?',yeslabel ='כן',nolabel ='לא')#line:861
	if choice2 ==1 :#line:862
		maintenance .deleteThumbnails ()#line:863
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:865
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:866
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:868
time .sleep (3 )#line:869
