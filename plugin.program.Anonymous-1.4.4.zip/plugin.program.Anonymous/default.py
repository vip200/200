# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re #line:24
import json #line:25
import zipfile #line:26
import uservar #line:27
import speedtest #line:28
import fnmatch #line:29
try :from sqlite3 import dbapi2 as database #line:30
except :from pysqlite2 import dbapi2 as database #line:31
from datetime import date ,datetime ,timedelta #line:32
from urlparse import urljoin #line:33
from resources .libs import extract ,downloader ,notify ,debridit ,traktit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:34
ADDON_ID =uservar .ADDON_ID #line:37
ADDONTITLE =uservar .ADDONTITLE #line:38
ADDON =wiz .addonId (ADDON_ID )#line:39
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:40
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:41
DIALOG =xbmcgui .Dialog ()#line:42
DP =xbmcgui .DialogProgress ()#line:43
HOME =xbmc .translatePath ('special://home/')#line:44
LOG =xbmc .translatePath ('special://logpath/')#line:45
PROFILE =xbmc .translatePath ('special://profile/')#line:46
ADDONS =os .path .join (HOME ,'addons')#line:47
USERDATA =os .path .join (HOME ,'userdata')#line:48
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:49
PACKAGES =os .path .join (ADDONS ,'packages')#line:50
ADDOND =os .path .join (USERDATA ,'addon_data')#line:51
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:52
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:53
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:54
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:55
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:56
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:57
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:58
DATABASE =os .path .join (USERDATA ,'Database')#line:59
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:60
ICON =os .path .join (ADDONPATH ,'icon.png')#line:61
ART =os .path .join (ADDONPATH ,'resources','art')#line:62
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:63
SKIN =xbmc .getSkinDir ()#line:64
BUILDNAME =wiz .getS ('buildname')#line:65
DEFAULTSKIN =wiz .getS ('defaultskin')#line:66
DEFAULTNAME =wiz .getS ('defaultskinname')#line:67
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:68
BUILDVERSION =wiz .getS ('buildversion')#line:69
BUILDTHEME =wiz .getS ('buildtheme')#line:70
BUILDLATEST =wiz .getS ('latestversion')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
SHOW15 =wiz .getS ('show15')#line:73
SHOW16 =wiz .getS ('show16')#line:74
SHOW17 =wiz .getS ('show17')#line:75
SHOW18 =wiz .getS ('show18')#line:76
SHOWADULT =wiz .getS ('adult')#line:77
SHOWMAINT =wiz .getS ('showmaint')#line:78
AUTOCLEANUP =wiz .getS ('autoclean')#line:79
AUTOCACHE =wiz .getS ('clearcache')#line:80
AUTOPACKAGES =wiz .getS ('clearpackages')#line:81
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:82
AUTOFEQ =wiz .getS ('autocleanfeq')#line:83
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:84
INCLUDENAN =wiz .getS ('includenan')#line:85
INCLUDEURL =wiz .getS ('includeurl')#line:86
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:87
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:88
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:89
INCLUDEVIDEO =wiz .getS ('includevideo')#line:90
INCLUDEALL =wiz .getS ('includeall')#line:91
INCLUDEBOB =wiz .getS ('includebob')#line:92
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:93
INCLUDESPECTO =wiz .getS ('includespecto')#line:94
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:95
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:96
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:97
INCLUDESALTS =wiz .getS ('includesalts')#line:98
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:99
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:100
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:101
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:102
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:103
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:104
INCLUDEURANUS =wiz .getS ('includeuranus')#line:105
SEPERATE =wiz .getS ('seperate')#line:106
NOTIFY =wiz .getS ('notify')#line:107
NOTEID =wiz .getS ('noteid')#line:108
NOTEDISMISS =wiz .getS ('notedismiss')#line:109
NOTIFY2 =wiz .getS ('notify2')#line:110
NOTEID2 =wiz .getS ('noteid2')#line:111
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:112
NOTIFY3 =wiz .getS ('notify3')#line:113
NOTEID3 =wiz .getS ('noteid3')#line:114
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:115
TRAKTSAVE =wiz .getS ('traktlastsave')#line:116
REALSAVE =wiz .getS ('debridlastsave')#line:117
LOGINSAVE =wiz .getS ('loginlastsave')#line:118
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:119
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:120
KEEPINFO =wiz .getS ('keepinfo')#line:121
KEEPSOUND =wiz .getS ('keepsound')#line:123
KEEPVIEW =wiz .getS ('keepview')#line:124
KEEPSKIN =wiz .getS ('keepskin')#line:125
KEEPADDONS =wiz .getS ('keepaddons')#line:126
KEEPSKIN2 =wiz .getS ('keepskin2')#line:127
KEEPSKIN3 =wiz .getS ('keepskin3')#line:128
KEEPTORNET =wiz .getS ('keeptornet')#line:129
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:130
KEEPPVR =wiz .getS ('keeppvr')#line:131
KEEPTVLIST =wiz .getS ('keeptvlist')#line:133
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:134
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:135
KEEPHUBTV =wiz .getS ('keephubtv')#line:136
KEEPHUBVOD =wiz .getS ('keephubvod')#line:137
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:138
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:139
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:140
KEEPFAVS =wiz .getS ('keepfavourites')#line:143
KEEPSOURCES =wiz .getS ('keepsources')#line:144
KEEPPROFILES =wiz .getS ('keepprofiles')#line:145
KEEPADVANCED =wiz .getS ('keepadvanced')#line:146
KEEPREPOS =wiz .getS ('keeprepos')#line:147
KEEPSUPER =wiz .getS ('keepsuper')#line:148
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:149
KEEPTRAKT =wiz .getS ('keeptrakt')#line:150
KEEPREAL =wiz .getS ('keepdebrid')#line:151
KEEPRD2 =wiz .getS ('keeprd2')#line:152
KEEPLOGIN =wiz .getS ('keeplogin')#line:153
LOGINSAVE =wiz .getS ('loginlastsave')#line:154
DEVELOPER =wiz .getS ('developer')#line:155
THIRDPARTY =wiz .getS ('enable3rd')#line:156
THIRD1NAME =wiz .getS ('wizard1name')#line:157
THIRD1URL =wiz .getS ('wizard1url')#line:158
THIRD2NAME =wiz .getS ('wizard2name')#line:159
THIRD2URL =wiz .getS ('wizard2url')#line:160
THIRD3NAME =wiz .getS ('wizard3name')#line:161
THIRD3URL =wiz .getS ('wizard3url')#line:162
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:163
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:164
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:165
TODAY =date .today ()#line:166
TOMORROW =TODAY +timedelta (days =1 )#line:167
THREEDAYS =TODAY +timedelta (days =3 )#line:168
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:169
MCNAME =wiz .mediaCenter ()#line:170
EXCLUDES =uservar .EXCLUDES #line:171
SPEEDFILE =speedtest .SPEEDFILE #line:172
APKFILE =uservar .APKFILE #line:173
YOUTUBETITLE =uservar .YOUTUBETITLE #line:174
YOUTUBEFILE =uservar .YOUTUBEFILE #line:175
SPEED =speedtest .SPEED #line:176
ADDONFILE =uservar .ADDONFILE #line:177
ADVANCEDFILE =uservar .ADVANCEDFILE #line:178
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:179
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:180
NOTIFICATION =uservar .NOTIFICATION #line:181
NOTIFICATION2 =uservar .NOTIFICATION2 #line:182
NOTIFICATION3 =uservar .NOTIFICATION3 #line:183
HELPINFO =uservar .HELPINFO #line:184
ENABLE =uservar .ENABLE #line:185
HEADERMESSAGE =uservar .HEADERMESSAGE #line:186
AUTOUPDATE =uservar .AUTOUPDATE #line:187
WIZARDFILE =uservar .WIZARDFILE #line:188
HIDECONTACT =uservar .HIDECONTACT #line:189
SKINID18 =uservar .SKINID18 #line:190
SKINID18DDONXML =uservar .SKINID18DDONXML #line:191
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:192
SKINID17 =uservar .SKINID17 #line:193
SKINID17DDONXML =uservar .SKINID17DDONXML #line:194
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:195
CONTACT =uservar .CONTACT #line:196
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:197
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:198
HIDESPACERS =uservar .HIDESPACERS #line:199
TMDB_NEW_API =uservar .TMDB_NEW_API #line:200
COLOR1 =uservar .COLOR1 #line:201
COLOR2 =uservar .COLOR2 #line:202
THEME1 =uservar .THEME1 #line:203
THEME2 =uservar .THEME2 #line:204
THEME3 =uservar .THEME3 #line:205
THEME4 =uservar .THEME4 #line:206
THEME5 =uservar .THEME5 #line:207
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:208
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:209
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:210
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:211
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:212
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:213
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:214
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:215
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:216
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:217
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:218
LOGFILES =wiz .LOGFILES #line:219
TRAKTID =traktit .TRAKTID #line:220
DEBRIDID =debridit .DEBRIDID #line:221
LOGINID =loginit .LOGINID #line:222
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:223
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:224
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:225
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:226
fullsecfold =xbmc .translatePath ('special://home')#line:227
addons_folder =os .path .join (fullsecfold ,'addons')#line:229
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:231
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:233
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:235
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:236
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:237
def MainMenu ():#line:244
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:246
def skinWIN ():#line:247
	idle ()#line:248
	O0OOOO00O000O00O0 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:249
	OO0O0OOOOO0O0000O =[];O00OO0OOO0O00O00O =[]#line:250
	for OO0O0O0O0OO000OOO in sorted (O0OOOO00O000O00O0 ,key =lambda O0OOOOO0OO0O0OO00 :O0OOOOO0OO0O0OO00 ):#line:251
		OO00O0O00O00O0O00 =os .path .split (OO0O0O0O0OO000OOO [:-1 ])[1 ]#line:252
		O000OO000000OOO0O =os .path .join (OO0O0O0O0OO000OOO ,'addon.xml')#line:253
		if os .path .exists (O000OO000000OOO0O ):#line:254
			OO000O00000OOOO00 =open (O000OO000000OOO0O )#line:255
			O00000OO0OO0O00O0 =OO000O00000OOOO00 .read ()#line:256
			OO000OOO000000OOO =parseDOM2 (O00000OO0OO0O00O0 ,'addon',ret ='id')#line:257
			O000OO0O0O0O000O0 =OO00O0O00O00O0O00 if len (OO000OOO000000OOO )==0 else OO000OOO000000OOO [0 ]#line:258
			try :#line:259
				OO00OOO000O00O0OO =xbmcaddon .Addon (id =O000OO0O0O0O000O0 )#line:260
				OO0O0OOOOO0O0000O .append (OO00OOO000O00O0OO .getAddonInfo ('name'))#line:261
				O00OO0OOO0O00O00O .append (O000OO0O0O0O000O0 )#line:262
			except :#line:263
				pass #line:264
	OOO0O0OO0000OOO00 =[];OO00O0000O0O0O000 =0 #line:265
	OO00O0000O0OOOO0O =["Current Skin -- %s"%currSkin ()]+OO0O0OOOOO0O0000O #line:266
	OO00O0000O0O0O000 =DIALOG .select ("Select the Skin you want to swap with.",OO00O0000O0OOOO0O )#line:267
	if OO00O0000O0O0O000 ==-1 :return #line:268
	else :#line:269
		OOO0O0OO00000OOOO =(OO00O0000O0O0O000 -1 )#line:270
		OOO0O0OO0000OOO00 .append (OOO0O0OO00000OOOO )#line:271
		OO00O0000O0OOOO0O [OO00O0000O0O0O000 ]="%s"%(OO0O0OOOOO0O0000O [OOO0O0OO00000OOOO ])#line:272
	if OOO0O0OO0000OOO00 ==None :return #line:273
	for OOOO0000O0O0O000O in OOO0O0OO0000OOO00 :#line:274
		swapSkins (O00OO0OOO0O00O00O [OOOO0000O0O0O000O ])#line:275
def currSkin ():#line:277
	return xbmc .getSkinDir ('Container.PluginName')#line:278
def swapSkins (OO0000OOOO0OOO000 ,title ="Error"):#line:279
	O00O0OOO0O0OOOO0O ='lookandfeel.skin'#line:280
	OOOO0OO00O0000OO0 =OO0000OOOO0OOO000 #line:281
	OOOOOO0OOO000O00O =getOld (O00O0OOO0O0OOOO0O )#line:282
	OOOO000OO00OO00O0 =O00O0OOO0O0OOOO0O #line:283
	setNew (OOOO000OO00OO00O0 ,OOOO0OO00O0000OO0 )#line:284
	OOOOOO0OOO00O000O =0 #line:285
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOOOOO0OOO00O000O <100 :#line:286
		OOOOOO0OOO00O000O +=1 #line:287
		xbmc .sleep (1 )#line:288
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:289
		xbmc .executebuiltin ('SendClick(11)')#line:290
	return True #line:291
def getOld (O00O000OO000O0O0O ):#line:293
	try :#line:294
		O00O000OO000O0O0O ='"%s"'%O00O000OO000O0O0O #line:295
		O00OO00O00O0OOO00 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(O00O000OO000O0O0O )#line:296
		OOOO00OOOO00O0O0O =xbmc .executeJSONRPC (O00OO00O00O0OOO00 )#line:298
		OOOO00OOOO00O0O0O =simplejson .loads (OOOO00OOOO00O0O0O )#line:299
		if OOOO00OOOO00O0O0O .has_key ('result'):#line:300
			if OOOO00OOOO00O0O0O ['result'].has_key ('value'):#line:301
				return OOOO00OOOO00O0O0O ['result']['value']#line:302
	except :#line:303
		pass #line:304
	return None #line:305
def setNew (O00OOO0OOO000O00O ,O000000O00OOO000O ):#line:308
	try :#line:309
		O00OOO0OOO000O00O ='"%s"'%O00OOO0OOO000O00O #line:310
		O000000O00OOO000O ='"%s"'%O000000O00OOO000O #line:311
		OOOO00OO0O0O00OOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00OOO0OOO000O00O ,O000000O00OOO000O )#line:312
		O000O00O0OOO000OO =xbmc .executeJSONRPC (OOOO00OO0O0O00OOO )#line:314
	except :#line:315
		pass #line:316
	return None #line:317
def idle ():#line:318
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:319
def backtokodi ():#line:321
	if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary']and not BUILDNAME =="":#line:322
			wiz .kodi17Fix ()#line:323
			fix18update ()#line:324
			fix17update ()#line:325
def fixfont ():#line:328
	O0O0OO0O0OO0OO0O0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:329
	OOOOOOO0O0OOOO0OO =json .loads (O0O0OO0O0OO0OO0O0 );#line:331
	O00000O0O00O000OO =OOOOOOO0O0OOOO0OO ["result"]["settings"]#line:332
	O000OO0O0O0000000 =[OOO00OOOO00O0O00O for OOO00OOOO00O0O00O in O00000O0O00O000OO if OOO00OOOO00O0O00O ["id"]=="audiooutput.audiodevice"][0 ]#line:334
	OO0O0OO0OOOO000O0 =O000OO0O0O0000000 ["options"];#line:335
	O00O0OOOO000O0OOO =O000OO0O0O0000000 ["value"];#line:336
	O00OO0O00OOO0OO00 =[OO0O0O000000O00O0 for (OO0O0O000000O00O0 ,OO0O00O0OOOO0O00O )in enumerate (OO0O0OO0OOOO000O0 )if OO0O00O0OOOO0O00O ["value"]==O00O0OOOO000O0OOO ][0 ];#line:338
	OO0OOOO0000O00OOO =(O00OO0O00OOO0OO00 +1 )%len (OO0O0OO0OOOO000O0 )#line:340
	OO0O0O00OO0OOO0OO =OO0O0OO0OOOO000O0 [OO0OOOO0000O00OOO ]["value"]#line:342
	O0OO00O0000000O0O =OO0O0OO0OOOO000O0 [OO0OOOO0000O00OOO ]["label"]#line:343
	O00OOO00O00OOO000 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:345
	try :#line:347
		OOO0OOOOO0OO0O0OO =json .loads (O00OOO00O00OOO000 );#line:348
		if OOO0OOOOO0OO0O0OO ["result"]!=True :#line:350
			raise Exception #line:351
	except :#line:352
		sys .stderr .write ("Error switching audio output device")#line:353
		raise Exception #line:354
def parseDOM2 (OO0OOO0OO0O000000 ,name =u"",attrs ={},ret =False ):#line:355
	if isinstance (OO0OOO0OO0O000000 ,str ):#line:358
		try :#line:359
			OO0OOO0OO0O000000 =[OO0OOO0OO0O000000 .decode ("utf-8")]#line:360
		except :#line:361
			OO0OOO0OO0O000000 =[OO0OOO0OO0O000000 ]#line:362
	elif isinstance (OO0OOO0OO0O000000 ,unicode ):#line:363
		OO0OOO0OO0O000000 =[OO0OOO0OO0O000000 ]#line:364
	elif not isinstance (OO0OOO0OO0O000000 ,list ):#line:365
		return u""#line:366
	if not name .strip ():#line:368
		return u""#line:369
	O0O0000OOOOOO00OO =[]#line:371
	for O0O000O00OOO00O0O in OO0OOO0OO0O000000 :#line:372
		O000000O0O000OO0O =re .compile ('(<[^>]*?\n[^>]*?>)').findall (O0O000O00OOO00O0O )#line:373
		for OOOO0O0OOOO00OO0O in O000000O0O000OO0O :#line:374
			O0O000O00OOO00O0O =O0O000O00OOO00O0O .replace (OOOO0O0OOOO00OO0O ,OOOO0O0OOOO00OO0O .replace ("\n"," "))#line:375
		OO00O0O00O00O0OO0 =[]#line:377
		for O00O000OOO0OOOOO0 in attrs :#line:378
			O0000OO0O000OO00O =re .compile ('(<'+name +'[^>]*?(?:'+O00O000OOO0OOOOO0 +'=[\'"]'+attrs [O00O000OOO0OOOOO0 ]+'[\'"].*?>))',re .M |re .S ).findall (O0O000O00OOO00O0O )#line:379
			if len (O0000OO0O000OO00O )==0 and attrs [O00O000OOO0OOOOO0 ].find (" ")==-1 :#line:380
				O0000OO0O000OO00O =re .compile ('(<'+name +'[^>]*?(?:'+O00O000OOO0OOOOO0 +'='+attrs [O00O000OOO0OOOOO0 ]+'.*?>))',re .M |re .S ).findall (O0O000O00OOO00O0O )#line:381
			if len (OO00O0O00O00O0OO0 )==0 :#line:383
				OO00O0O00O00O0OO0 =O0000OO0O000OO00O #line:384
				O0000OO0O000OO00O =[]#line:385
			else :#line:386
				OOO0OOO000OOOOO0O =range (len (OO00O0O00O00O0OO0 ))#line:387
				OOO0OOO000OOOOO0O .reverse ()#line:388
				for OO00O00000O000OOO in OOO0OOO000OOOOO0O :#line:389
					if not OO00O0O00O00O0OO0 [OO00O00000O000OOO ]in O0000OO0O000OO00O :#line:390
						del (OO00O0O00O00O0OO0 [OO00O00000O000OOO ])#line:391
		if len (OO00O0O00O00O0OO0 )==0 and attrs =={}:#line:393
			OO00O0O00O00O0OO0 =re .compile ('(<'+name +'>)',re .M |re .S ).findall (O0O000O00OOO00O0O )#line:394
			if len (OO00O0O00O00O0OO0 )==0 :#line:395
				OO00O0O00O00O0OO0 =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (O0O000O00OOO00O0O )#line:396
		if isinstance (ret ,str ):#line:398
			O0000OO0O000OO00O =[]#line:399
			for OOOO0O0OOOO00OO0O in OO00O0O00O00O0OO0 :#line:400
				O0OOO00OO00O00OO0 =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OOOO0O0OOOO00OO0O )#line:401
				if len (O0OOO00OO00O00OO0 )==0 :#line:402
					O0OOO00OO00O00OO0 =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OOOO0O0OOOO00OO0O )#line:403
				for O00OO00000O00OO0O in O0OOO00OO00O00OO0 :#line:404
					O0O0OOO0OO0O0O00O =O00OO00000O00OO0O [0 ]#line:405
					if O0O0OOO0OO0O0O00O in "'\"":#line:406
						if O00OO00000O00OO0O .find ('='+O0O0OOO0OO0O0O00O ,O00OO00000O00OO0O .find (O0O0OOO0OO0O0O00O ,1 ))>-1 :#line:407
							O00OO00000O00OO0O =O00OO00000O00OO0O [:O00OO00000O00OO0O .find ('='+O0O0OOO0OO0O0O00O ,O00OO00000O00OO0O .find (O0O0OOO0OO0O0O00O ,1 ))]#line:408
						if O00OO00000O00OO0O .rfind (O0O0OOO0OO0O0O00O ,1 )>-1 :#line:410
							O00OO00000O00OO0O =O00OO00000O00OO0O [1 :O00OO00000O00OO0O .rfind (O0O0OOO0OO0O0O00O )]#line:411
					else :#line:412
						if O00OO00000O00OO0O .find (" ")>0 :#line:413
							O00OO00000O00OO0O =O00OO00000O00OO0O [:O00OO00000O00OO0O .find (" ")]#line:414
						elif O00OO00000O00OO0O .find ("/")>0 :#line:415
							O00OO00000O00OO0O =O00OO00000O00OO0O [:O00OO00000O00OO0O .find ("/")]#line:416
						elif O00OO00000O00OO0O .find (">")>0 :#line:417
							O00OO00000O00OO0O =O00OO00000O00OO0O [:O00OO00000O00OO0O .find (">")]#line:418
					O0000OO0O000OO00O .append (O00OO00000O00OO0O .strip ())#line:420
			OO00O0O00O00O0OO0 =O0000OO0O000OO00O #line:421
		else :#line:422
			O0000OO0O000OO00O =[]#line:423
			for OOOO0O0OOOO00OO0O in OO00O0O00O00O0OO0 :#line:424
				O00000OOO0OO00O00 =u"</"+name #line:425
				OO0O000O0OOO0OO0O =O0O000O00OOO00O0O .find (OOOO0O0OOOO00OO0O )#line:427
				O0000OOO0000O0000 =O0O000O00OOO00O0O .find (O00000OOO0OO00O00 ,OO0O000O0OOO0OO0O )#line:428
				O00O00O00OOOOO000 =O0O000O00OOO00O0O .find ("<"+name ,OO0O000O0OOO0OO0O +1 )#line:429
				while O00O00O00OOOOO000 <O0000OOO0000O0000 and O00O00O00OOOOO000 !=-1 :#line:431
					OO0OO0OOOOO0OOO00 =O0O000O00OOO00O0O .find (O00000OOO0OO00O00 ,O0000OOO0000O0000 +len (O00000OOO0OO00O00 ))#line:432
					if OO0OO0OOOOO0OOO00 !=-1 :#line:433
						O0000OOO0000O0000 =OO0OO0OOOOO0OOO00 #line:434
					O00O00O00OOOOO000 =O0O000O00OOO00O0O .find ("<"+name ,O00O00O00OOOOO000 +1 )#line:435
				if OO0O000O0OOO0OO0O ==-1 and O0000OOO0000O0000 ==-1 :#line:437
					OO00OOOO0OOOOOOO0 =u""#line:438
				elif OO0O000O0OOO0OO0O >-1 and O0000OOO0000O0000 >-1 :#line:439
					OO00OOOO0OOOOOOO0 =O0O000O00OOO00O0O [OO0O000O0OOO0OO0O +len (OOOO0O0OOOO00OO0O ):O0000OOO0000O0000 ]#line:440
				elif O0000OOO0000O0000 >-1 :#line:441
					OO00OOOO0OOOOOOO0 =O0O000O00OOO00O0O [:O0000OOO0000O0000 ]#line:442
				elif OO0O000O0OOO0OO0O >-1 :#line:443
					OO00OOOO0OOOOOOO0 =O0O000O00OOO00O0O [OO0O000O0OOO0OO0O +len (OOOO0O0OOOO00OO0O ):]#line:444
				if ret :#line:446
					O00000OOO0OO00O00 =O0O000O00OOO00O0O [O0000OOO0000O0000 :O0O000O00OOO00O0O .find (">",O0O000O00OOO00O0O .find (O00000OOO0OO00O00 ))+1 ]#line:447
					OO00OOOO0OOOOOOO0 =OOOO0O0OOOO00OO0O +OO00OOOO0OOOOOOO0 +O00000OOO0OO00O00 #line:448
				O0O000O00OOO00O0O =O0O000O00OOO00O0O [O0O000O00OOO00O0O .find (OO00OOOO0OOOOOOO0 ,O0O000O00OOO00O0O .find (OOOO0O0OOOO00OO0O ))+len (OO00OOOO0OOOOOOO0 ):]#line:450
				O0000OO0O000OO00O .append (OO00OOOO0OOOOOOO0 )#line:451
			OO00O0O00O00O0OO0 =O0000OO0O000OO00O #line:452
		O0O0000OOOOOO00OO +=OO00O0O00O00O0OO0 #line:453
	return O0O0000OOOOOO00OO #line:455
def addItem (O000OO00OO00O0OO0 ,O00OO0O0O0O00OOOO ,O00OOO00O0O0O0OOO ,OOO00O00OO0OOO0O0 ,O0O0O0OOOOOOO00O0 ,description =None ):#line:457
	if description ==None :description =''#line:458
	description ='[COLOR white]'+description +'[/COLOR]'#line:459
	OO000OO0000OOOO0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O00OO0O0O0O00OOOO )+"&mode="+str (O00OOO00O0O0O0OOO )+"&name="+urllib .quote_plus (O000OO00OO00O0OO0 )+"&iconimage="+urllib .quote_plus (OOO00O00OO0OOO0O0 )+"&fanart="+urllib .quote_plus (O0O0O0OOOOOOO00O0 )#line:460
	OOOOO0O0O0O0O0O00 =True #line:461
	O0OOO0000O000O0O0 =xbmcgui .ListItem (O000OO00OO00O0OO0 ,iconImage =OOO00O00OO0OOO0O0 ,thumbnailImage =OOO00O00OO0OOO0O0 )#line:462
	O0OOO0000O000O0O0 .setInfo (type ="Video",infoLabels ={"Title":O000OO00OO00O0OO0 ,"Plot":description })#line:463
	O0OOO0000O000O0O0 .setProperty ("fanart_Image",O0O0O0OOOOOOO00O0 )#line:464
	O0OOO0000O000O0O0 .setProperty ("icon_Image",OOO00O00OO0OOO0O0 )#line:465
	OOOOO0O0O0O0O0O00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OO000OO0000OOOO0O ,listitem =O0OOO0000O000O0O0 ,isFolder =False )#line:466
	return OOOOO0O0O0O0O0O00 #line:467
def get_params ():#line:469
		O00O00O0OOOO0OO0O =[]#line:470
		OOO00O000O0O0OOO0 =sys .argv [2 ]#line:471
		if len (OOO00O000O0O0OOO0 )>=2 :#line:472
				O0OO0OO0O000O00OO =sys .argv [2 ]#line:473
				OO0O000OO00OOOO0O =O0OO0OO0O000O00OO .replace ('?','')#line:474
				if (O0OO0OO0O000O00OO [len (O0OO0OO0O000O00OO )-1 ]=='/'):#line:475
						O0OO0OO0O000O00OO =O0OO0OO0O000O00OO [0 :len (O0OO0OO0O000O00OO )-2 ]#line:476
				O00O000OOO00O0OO0 =OO0O000OO00OOOO0O .split ('&')#line:477
				O00O00O0OOOO0OO0O ={}#line:478
				for OOO00OO000OOOO00O in range (len (O00O000OOO00O0OO0 )):#line:479
						O0OOO0OO00000OO00 ={}#line:480
						O0OOO0OO00000OO00 =O00O000OOO00O0OO0 [OOO00OO000OOOO00O ].split ('=')#line:481
						if (len (O0OOO0OO00000OO00 ))==2 :#line:482
								O00O00O0OOOO0OO0O [O0OOO0OO00000OO00 [0 ]]=O0OOO0OO00000OO00 [1 ]#line:483
		return O00O00O0OOOO0OO0O #line:485
def decode (OOOO0O000OOOO0OOO ,O00O0OO0O0OOOO0OO ):#line:490
    import base64 #line:491
    OOO00OOOOO00O0OOO =[]#line:492
    if (len (OOOO0O000OOOO0OOO ))!=4 :#line:494
     return 10 #line:495
    O00O0OO0O0OOOO0OO =base64 .urlsafe_b64decode (O00O0OO0O0OOOO0OO )#line:496
    logging .warning ('enc')#line:497
    logging .warning (O00O0OO0O0OOOO0OO )#line:498
    for O0OO0000O00O0O000 in range (len (O00O0OO0O0OOOO0OO )):#line:499
        OO0OO0O0OOO000OO0 =OOOO0O000OOOO0OOO [O0OO0000O00O0O000 %len (OOOO0O000OOOO0OOO )]#line:500
        OOOO0O00000O00O0O =chr ((256 +ord (O00O0OO0O0OOOO0OO [O0OO0000O00O0O000 ])-ord (OO0OO0O0OOO000OO0 ))%256 )#line:501
        OOO00OOOOO00O0OOO .append (OOOO0O00000O00O0O )#line:502
    return "".join (OOO00OOOOO00O0OOO )#line:503
def tmdb_list (O0OO0O00O0OO000O0 ):#line:504
    OOOO00OOO0OO0OO0O =decode ("7643",O0OO0O00O0OO000O0 )#line:507
    return int (OOOO00OOO0OO0OO0O )#line:510
def u_list (OO000O000O0OOOOO0 ):#line:511
    from math import sqrt #line:513
    OO0O0O00O00O0OOOO =tmdb_list (TMDB_NEW_API )#line:514
    O000OOOOOO0O000O0 =str ((getHwAddr ('eth0'))*OO0O0O00O00O0OOOO )#line:516
    OOO0OO0O0OOOOO0OO =int (O000OOOOOO0O000O0 [1 ]+O000OOOOOO0O000O0 [2 ]+O000OOOOOO0O000O0 [5 ]+O000OOOOOO0O000O0 [7 ])#line:517
    O0000OO0OO000O0O0 =(ADDON .getSetting ("pass"))#line:519
    OO00O0OO0O00O0O00 =(str (round (sqrt ((OOO0OO0O0OOOOO0OO *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:524
    if '.'in OO00O0OO0O00O0O00 :#line:525
     OO00O0OO0O00O0O00 =(str (round (sqrt ((OOO0OO0O0OOOOO0OO *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:526
    if O0000OO0OO000O0O0 ==OO00O0OO0O00O0O00 :#line:527
      OOO0O0OOOO000O0O0 =OO000O000O0OOOOO0 #line:529
    else :#line:531
       if STARTP ()=='ok':#line:532
         return OO000O000O0OOOOO0 #line:534
       OOO0O0OOOO000O0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:535
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:536
       sys .exit ()#line:537
    return OOO0O0OOOO000O0O0 #line:538
def disply_hwr ():#line:540
   OO0000000OOO00OOO =tmdb_list (TMDB_NEW_API )#line:541
   O0OOO0O0O0000OOOO =str ((getHwAddr ('eth0'))*OO0000000OOO00OOO )#line:542
   O00OO0O0OO0OOO00O =(O0OOO0O0O0000OOOO [1 ]+O0OOO0O0O0000OOOO [2 ]+O0OOO0O0O0000OOOO [5 ]+O0OOO0O0O0000OOOO [7 ])#line:549
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",O00OO0O0OO0OOO00O )#line:550
def getHwAddr (O0O00000O00O0O00O ):#line:552
   import subprocess ,time #line:553
   O0000OO00O0OO000O ='windows'#line:554
   if xbmc .getCondVisibility ('system.platform.android'):#line:555
       O0000OO00O0OO000O ='android'#line:556
   if (O0000OO00O0OO000O =='android'):#line:557
     OO00OOO00OOOOO0OO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:558
     OOO000O0O0000OO00 =re .compile ('link/ether (.+?) brd').findall (str (OO00OOO00OOOOO0OO ))#line:560
     for OOOO00OOOO0OO00OO in OOO000O0O0000OO00 :#line:561
      if OOO000O0O0000OO00 !='00:00:00:00:00:00':#line:562
          OOOO0O000O000O0O0 =OOOO00OOOO0OO00OO #line:563
          break #line:564
   else :#line:565
       O0OO0OO00O0O0OO00 =0 #line:566
       while (1 ):#line:567
         OOOO0O000O000O0O0 =xbmc .getInfoLabel ("network.macaddress")#line:568
         if OOOO0O000O000O0O0 !="Busy"and OOOO0O000O000O0O0 !=' עסוק':#line:570
            break #line:572
         else :#line:573
           O0OO0OO00O0O0OO00 =O0OO0OO00O0O0OO00 +1 #line:574
           time .sleep (1 )#line:575
           if O0OO0OO00O0O0OO00 >30 :#line:576
            break #line:577
   O0OO0OOOOO000O00O =int (OOOO0O000O000O0O0 .replace (':',''),16 )#line:579
   return O0OO0OOOOO000O00O #line:580
def getpass ():#line:581
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.Anonymous/default.py?mode=9&url=clearCache)")#line:583
def setpass ():#line:584
    OOO0OO0O00O000O00 =''#line:585
    O00O00OOO0OO0O0OO =xbmc .Keyboard (OOO0OO0O00O000O00 ,'הכנס סיסמה')#line:586
    O00O00OOO0OO0O0OO .doModal ()#line:587
    if O00O00OOO0OO0O0OO .isConfirmed ():#line:588
           OOO0OO0O00O000O00 =O00O00OOO0OO0O0OO .getText ()#line:589
           wiz .setS ('pass',str (OOO0OO0O00O000O00 ))#line:590
def powerkodi ():#line:592
    os ._exit (1 )#line:593
def buffer1 ():#line:595
	O000O00O0O0O0000O =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:596
	O00OOO000O0OO0000 =xbmc .getInfoLabel ("System.Memory(total)")#line:597
	OO0OOO0OO0000000O =xbmc .getInfoLabel ("System.FreeMemory")#line:598
	O0O000OOO0O000O00 =re .sub ('[^0-9]','',OO0OOO0OO0000000O )#line:599
	O0O000OOO0O000O00 =int (O0O000OOO0O000O00 )/3 #line:600
	OOOO00O0OOOOO0000 =O0O000OOO0O000O00 *1024 *1024 #line:601
	try :OOOO0O0OO000000O0 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:602
	except :OOOO0O0OO000000O0 =16 #line:603
	O00000O000OOO0OOO =DIALOG .yesno ('FREE MEMORY: '+str (OO0OOO0OO0000000O ),'Based on your free Memory your optimal buffersize is: '+str (O0O000OOO0O000O00 )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:606
	if O00000O000OOO0OOO ==1 :#line:607
		with open (O000O00O0O0O0000O ,"w")as OOOO0O0O0OO0OOOOO :#line:608
			if OOOO0O0OO000000O0 >=17 :OOOOOO0O00O0OO0O0 =xml_data_advSettings_New (str (OOOO00O0OOOOO0000 ))#line:609
			else :OOOOOO0O00O0OO0O0 =xml_data_advSettings_old (str (OOOO00O0OOOOO0000 ))#line:610
			OOOO0O0O0OO0OOOOO .write (OOOOOO0O00O0OO0O0 )#line:612
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO00O0OOOOO0000 ),'Please restart Kodi for settings to apply.','')#line:613
	elif O00000O000OOO0OOO ==0 :#line:615
		OOOO00O0OOOOO0000 =_OO000OO00OO000OOO (default =str (OOOO00O0OOOOO0000 ),heading ="INPUT BUFFER SIZE")#line:616
		with open (O000O00O0O0O0000O ,"w")as OOOO0O0O0OO0OOOOO :#line:617
			if OOOO0O0OO000000O0 >=17 :OOOOOO0O00O0OO0O0 =xml_data_advSettings_New (str (OOOO00O0OOOOO0000 ))#line:618
			else :OOOOOO0O00O0OO0O0 =xml_data_advSettings_old (str (OOOO00O0OOOOO0000 ))#line:619
			OOOO0O0O0OO0OOOOO .write (OOOOOO0O00O0OO0O0 )#line:620
			DIALOG .ok ('Buffer Size Set to: '+str (OOOO00O0OOOOO0000 ),'Please restart Kodi for settings to apply.','')#line:621
def xml_data_advSettings_old (O00000OOOOOOO0000 ):#line:622
	OOOO0OOO0OO0OOOO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O00000OOOOOOO0000 #line:632
	return OOOO0OOO0OO0OOOO0 #line:633
def xml_data_advSettings_New (O0OOOO0O0000O00OO ):#line:635
	O0O00OO00O00OOOO0 ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%O0OOOO0O0000O00OO #line:647
	return O0O00OO00O00OOOO0 #line:648
def write_ADV_SETTINGS_XML (O0OOOO0OOO0OO0O00 ):#line:649
    if not os .path .exists (xml_file ):#line:650
        with open (xml_file ,"w")as O0OOO00O000000O00 :#line:651
            O0OOO00O000000O00 .write (xml_data )#line:652
def _OO000OO00OO000OOO (default ="",heading ="",hidden =False ):#line:653
    ""#line:654
    OO0O00OOO0O00O0OO =xbmc .Keyboard (default ,heading ,hidden )#line:655
    OO0O00OOO0O00O0OO .doModal ()#line:656
    if (OO0O00OOO0O00O0OO .isConfirmed ()):#line:657
        return unicode (OO0O00OOO0O00O0OO .getText (),"utf-8")#line:658
    return default #line:659
def index ():#line:661
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:662
	if AUTOUPDATE =='Yes':#line:663
		if wiz .workingURL (WIZARDFILE )==True :#line:664
			OOOO00O00O0OOO000 =wiz .checkWizard ('version')#line:665
			if OOOO00O00O0OOO000 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OOOO00O00O0OOO000 ),'wizardupdate',themeit =THEME2 )#line:666
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:667
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:668
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:669
	if len (BUILDNAME )>0 :#line:670
		O0OOO0OOOOO00O0OO =wiz .checkBuild (BUILDNAME ,'version')#line:671
		O0O0OO0O0O00O00OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:672
		if O0OOO0OOOOO00O0OO >BUILDVERSION :O0O0OO0O0O00O00OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0O0OO0O0O00O00OO ,O0OOO0OOOOO00O0OO )#line:673
		addDir (O0O0OO0O0O00O00OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:675
		try :#line:677
		     OOO000OO0OO0O0O00 =wiz .themeCount (BUILDNAME )#line:678
		except :#line:679
		   OOO000OO0OO0O0O00 =False #line:680
		if not OOO000OO0OO0O0O00 ==False :#line:681
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:682
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:683
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:686
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:687
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:688
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:689
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:690
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:693
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:695
def morsetup ():#line:697
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:698
	if not ADDONFILE =='http://':addDir ('התקנת הרחבות','addons',icon =ICONADDONS ,themeit =THEME1 )#line:699
	addDir ('תחזוקה','maint',icon =ICONMAINT ,themeit =THEME1 )#line:700
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:701
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:702
	addFile ('איפוס הגדרות ויזארד','fixwizard',icon =ICONMAINT ,themeit =THEME1 )#line:704
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:705
	addFile ('גיבוי הבילד','backupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:707
	addFile ('שחזור הבילד','restorezip',icon =ICONMAINT ,themeit =THEME1 )#line:708
	addFile ('הגדרות','settings',icon =ICONSETTINGS ,themeit =THEME1 )#line:709
	addDir ('הגדרת חשבון RD','rdset',icon =ICONSAVE ,themeit =THEME1 )#line:710
	addDir ('הגדרת חשבון Trakt','traktset',icon =ICONTRAKT ,themeit =THEME1 )#line:711
	addFile ('כיבוי מהיר','power',icon =ICONCONTACT ,themeit =THEME1 )#line:713
	setView ('files','viewType')#line:714
def morsetup2 ():#line:715
	addFile ('מתקין ומגדיר - קודי אנונימוס','',themeit =THEME3 )#line:716
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:717
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:718
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:719
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:720
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:721
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:722
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:723
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:724
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:725
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:726
def fastupdate ():#line:727
		addFile ('עדכון מהיר - קודי 17','testnotify',themeit =THEME1 )#line:728
		addFile ('עדכון מהיר - קודי 18','testnotify2',themeit =THEME1 )#line:729
def forcefastupdate ():#line:730
			O0OO0O0OOOO0O0O0O ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:731
			wiz .ForceFastUpDate (ADDONTITLE ,O0OO0O0OOOO0O0O0O )#line:732
def rdsetup ():#line:736
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:737
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:738
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:739
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:740
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:741
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:742
	setView ('files','viewType')#line:743
def traktsetup ():#line:745
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:746
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:747
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:748
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:749
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:750
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:751
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:752
	setView ('files','viewType')#line:753
def resolveurlsetup ():#line:755
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:756
def urlresolversetup ():#line:757
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:758
def placentasetup ():#line:760
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:761
def reptiliasetup ():#line:762
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:763
def flixnetsetup ():#line:764
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:765
def yodasetup ():#line:766
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:767
def numberssetup ():#line:768
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:769
def uranussetup ():#line:770
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:771
def genesissetup ():#line:772
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:773
def net_tools (view =None ):#line:775
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:776
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:777
	setView ('files','viewType')#line:779
def speedMenu ():#line:780
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.Anonymous/speedtest.py")')#line:781
def viewIP ():#line:782
	O00O0O0OOOO000O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:796
	O0O0OO00OO00O000O =[];OOOO0OOO00O0O0000 =0 #line:797
	for OO00OO0OOOOO0OO0O in O00O0O0OOOO000O0O :#line:798
		O0O0OOO0OOO000OO0 =wiz .getInfo (OO00OO0OOOOO0OO0O )#line:799
		O00OO00O0O0OO0OOO =0 #line:800
		while O0O0OOO0OOO000OO0 =="Busy"and O00OO00O0O0OO0OOO <10 :#line:801
			O0O0OOO0OOO000OO0 =wiz .getInfo (OO00OO0OOOOO0OO0O );O00OO00O0O0OO0OOO +=1 ;wiz .log ("%s sleep %s"%(OO00OO0OOOOO0OO0O ,str (O00OO00O0O0OO0OOO )));xbmc .sleep (1000 )#line:802
		O0O0OO00OO00O000O .append (O0O0OOO0OOO000OO0 )#line:803
		OOOO0OOO00O0O0000 +=1 #line:804
	OO0O0OO000OOOOOO0 ,O00OOOO00OO0O000O ,O00O0OOOOO0OOOOO0 =getIP ()#line:805
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00OO00O000O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:806
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OO000OOOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:807
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOO00OO0O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:808
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0OOOOO0OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:809
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO00OO00O000O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:810
	setView ('files','viewType')#line:811
def buildMenu ():#line:813
	OOO000OOOOOO0OO0O =u_list (SPEEDFILE )#line:814
	(OOO000OOOOOO0OO0O )#line:815
	OOO000O0000OO00O0 =(wiz .workingURL (OOO000OOOOOO0OO0O ))#line:816
	(OOO000O0000OO00O0 )#line:817
	OOO000O0000OO00O0 =wiz .workingURL (SPEEDFILE )#line:818
	if not OOO000O0000OO00O0 ==True :#line:819
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:820
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:821
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:822
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:823
		addFile ('%s'%OOO000O0000OO00O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:824
	else :#line:825
		O0OO00O0O00OO00O0 ,O0OO00OOO0OOO0O0O ,O00OOO0O0O00O000O ,O0O000000OOO00OO0 ,OO0O00O0O0OOOOOOO ,OO0O0O0O0O00OO000 ,OOOO00O0O00O0OO00 =wiz .buildCount ()#line:826
		OO0O000OO0O0O0000 =False ;O0OOO00OO00O0OOO0 =[]#line:827
		if THIRDPARTY =='true':#line:828
			if not THIRD1NAME ==''and not THIRD1URL =='':OO0O000OO0O0O0000 =True ;O0OOO00OO00O0OOO0 .append ('1')#line:829
			if not THIRD2NAME ==''and not THIRD2URL =='':OO0O000OO0O0O0000 =True ;O0OOO00OO00O0OOO0 .append ('2')#line:830
			if not THIRD3NAME ==''and not THIRD3URL =='':OO0O000OO0O0O0000 =True ;O0OOO00OO00O0OOO0 .append ('3')#line:831
		O000O0OOO0O0OOOO0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:832
		O00000OO0OO0O0O0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O000O0OOO0O0OOOO0 )#line:833
		if O0OO00O0O00OO00O0 ==1 and OO0O000OO0O0O0000 ==False :#line:834
			for OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ,OOOO00O0OOOO0O00O ,O0OOOOO0O00O000OO ,OO00000OOO00O00OO ,O000OO00OOOO0OOOO ,OO000O000O0O00000 ,OOOOOO0OOOOOO0O0O ,OOOO0O00OOO00OOO0 ,OO0OOOO000O000000 in O00000OO0OO0O0O0O :#line:835
				if not SHOWADULT =='true'and OOOO0O00OOO00OOO0 .lower ()=='yes':continue #line:836
				if not DEVELOPER =='true'and wiz .strTest (OOOOOOO0O0OOO0000 ):continue #line:837
				viewBuild (O00000OO0OO0O0O0O [0 ][0 ])#line:838
				return #line:839
		addDir ('כניסה לעדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:842
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:843
		if OO0O000OO0O0O0000 ==True :#line:844
			for O000O0OO0OO00O0O0 in O0OOO00OO00O0OOO0 :#line:845
				OOOOOOO0O0OOO0000 =eval ('THIRD%sNAME'%O000O0OO0OO00O0O0 )#line:846
		if len (O00000OO0OO0O0O0O )>=1 :#line:848
			if SEPERATE =='true':#line:849
				for OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ,OOOO00O0OOOO0O00O ,O0OOOOO0O00O000OO ,OO00000OOO00O00OO ,O000OO00OOOO0OOOO ,OO000O000O0O00000 ,OOOOOO0OOOOOO0O0O ,OOOO0O00OOO00OOO0 ,OO0OOOO000O000000 in O00000OO0OO0O0O0O :#line:850
					if not SHOWADULT =='true'and OOOO0O00OOO00OOO0 .lower ()=='yes':continue #line:851
					if not DEVELOPER =='true'and wiz .strTest (OOOOOOO0O0OOO0000 ):continue #line:852
					O00OOO0000000000O =createMenu ('install','',OOOOOOO0O0OOO0000 )#line:853
					addDir ('[%s] %s (v%s)'%(float (OO00000OOO00O00OO ),OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ),'viewbuild',OOOOOOO0O0OOO0000 ,description =OO0OOOO000O000000 ,fanart =OOOOOO0OOOOOO0O0O ,icon =OO000O000O0O00000 ,menu =O00OOO0000000000O ,themeit =THEME2 )#line:854
			else :#line:855
				if O0O000000OOO00OO0 >0 :#line:856
					O00O00O0O0O0OOO00 ='+'if SHOW17 =='false'else '-'#line:857
					if SHOW17 =='true':#line:859
						for OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ,OOOO00O0OOOO0O00O ,O0OOOOO0O00O000OO ,OO00000OOO00O00OO ,O000OO00OOOO0OOOO ,OO000O000O0O00000 ,OOOOOO0OOOOOO0O0O ,OOOO0O00OOO00OOO0 ,OO0OOOO000O000000 in O00000OO0OO0O0O0O :#line:861
							if not SHOWADULT =='true'and OOOO0O00OOO00OOO0 .lower ()=='yes':continue #line:862
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOO0O0OOO0000 ):continue #line:863
							O0O0OO00000O00OO0 =int (float (OO00000OOO00O00OO ))#line:864
							if O0O0OO00000O00OO0 ==17 :#line:865
								O00OOO0000000000O =createMenu ('install','',OOOOOOO0O0OOO0000 )#line:866
								addDir ('[%s] %s (v%s)'%(float (OO00000OOO00O00OO ),OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ),'viewbuild',OOOOOOO0O0OOO0000 ,description =OO0OOOO000O000000 ,fanart =OOOOOO0OOOOOO0O0O ,icon =OO000O000O0O00000 ,menu =O00OOO0000000000O ,themeit =THEME2 )#line:867
				if OO0O00O0O0OOOOOOO >0 :#line:868
					O00O00O0O0O0OOO00 ='+'if SHOW18 =='false'else '-'#line:869
					if SHOW18 =='true':#line:871
						for OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ,OOOO00O0OOOO0O00O ,O0OOOOO0O00O000OO ,OO00000OOO00O00OO ,O000OO00OOOO0OOOO ,OO000O000O0O00000 ,OOOOOO0OOOOOO0O0O ,OOOO0O00OOO00OOO0 ,OO0OOOO000O000000 in O00000OO0OO0O0O0O :#line:873
							if not SHOWADULT =='true'and OOOO0O00OOO00OOO0 .lower ()=='yes':continue #line:874
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOO0O0OOO0000 ):continue #line:875
							O0O0OO00000O00OO0 =int (float (OO00000OOO00O00OO ))#line:876
							if O0O0OO00000O00OO0 ==18 :#line:877
								O00OOO0000000000O =createMenu ('install','',OOOOOOO0O0OOO0000 )#line:878
								addDir ('[%s] %s (v%s)'%(float (OO00000OOO00O00OO ),OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ),'viewbuild',OOOOOOO0O0OOO0000 ,description =OO0OOOO000O000000 ,fanart =OOOOOO0OOOOOO0O0O ,icon =OO000O000O0O00000 ,menu =O00OOO0000000000O ,themeit =THEME2 )#line:879
				if O00OOO0O0O00O000O >0 :#line:880
					O00O00O0O0O0OOO00 ='+'if SHOW16 =='false'else '-'#line:881
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00O00O0O0O0OOO00 ,O00OOO0O0O00O000O ),'togglesetting','show16',themeit =THEME3 )#line:882
					if SHOW16 =='true':#line:883
						for OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ,OOOO00O0OOOO0O00O ,O0OOOOO0O00O000OO ,OO00000OOO00O00OO ,O000OO00OOOO0OOOO ,OO000O000O0O00000 ,OOOOOO0OOOOOO0O0O ,OOOO0O00OOO00OOO0 ,OO0OOOO000O000000 in O00000OO0OO0O0O0O :#line:884
							if not SHOWADULT =='true'and OOOO0O00OOO00OOO0 .lower ()=='yes':continue #line:885
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOO0O0OOO0000 ):continue #line:886
							O0O0OO00000O00OO0 =int (float (OO00000OOO00O00OO ))#line:887
							if O0O0OO00000O00OO0 ==16 :#line:888
								O00OOO0000000000O =createMenu ('install','',OOOOOOO0O0OOO0000 )#line:889
								addDir ('[%s] %s (v%s)'%(float (OO00000OOO00O00OO ),OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ),'viewbuild',OOOOOOO0O0OOO0000 ,description =OO0OOOO000O000000 ,fanart =OOOOOO0OOOOOO0O0O ,icon =OO000O000O0O00000 ,menu =O00OOO0000000000O ,themeit =THEME2 )#line:890
				if O0OO00OOO0OOO0O0O >0 :#line:891
					O00O00O0O0O0OOO00 ='+'if SHOW15 =='false'else '-'#line:892
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(O00O00O0O0O0OOO00 ,O0OO00OOO0OOO0O0O ),'togglesetting','show15',themeit =THEME3 )#line:893
					if SHOW15 =='true':#line:894
						for OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ,OOOO00O0OOOO0O00O ,O0OOOOO0O00O000OO ,OO00000OOO00O00OO ,O000OO00OOOO0OOOO ,OO000O000O0O00000 ,OOOOOO0OOOOOO0O0O ,OOOO0O00OOO00OOO0 ,OO0OOOO000O000000 in O00000OO0OO0O0O0O :#line:895
							if not SHOWADULT =='true'and OOOO0O00OOO00OOO0 .lower ()=='yes':continue #line:896
							if not DEVELOPER =='true'and wiz .strTest (OOOOOOO0O0OOO0000 ):continue #line:897
							O0O0OO00000O00OO0 =int (float (OO00000OOO00O00OO ))#line:898
							if O0O0OO00000O00OO0 <=15 :#line:899
								O00OOO0000000000O =createMenu ('install','',OOOOOOO0O0OOO0000 )#line:900
								addDir ('[%s] %s (v%s)'%(float (OO00000OOO00O00OO ),OOOOOOO0O0OOO0000 ,O0OO0O0OOO0O0OOO0 ),'viewbuild',OOOOOOO0O0OOO0000 ,description =OO0OOOO000O000000 ,fanart =OOOOOO0OOOOOO0O0O ,icon =OO000O000O0O00000 ,menu =O00OOO0000000000O ,themeit =THEME2 )#line:901
		elif OOOO00O0O00O0OO00 >0 :#line:902
			if OO0O0O0O0O00OO000 >0 :#line:903
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:904
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:905
			else :#line:906
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:907
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:908
	setView ('files','viewType')#line:909
def viewBuild (OO0OO00OO0OO00000 ):#line:911
	O00OOOO00O0OOOO00 =wiz .workingURL (SPEEDFILE )#line:912
	if not O00OOOO00O0OOOO00 ==True :#line:913
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:914
		addFile ('%s'%O00OOOO00O0OOOO00 ,'',themeit =THEME3 )#line:915
		return #line:916
	if wiz .checkBuild (OO0OO00OO0OO00000 ,'version')==False :#line:917
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:918
		addFile ('%s was not found in the builds list.'%OO0OO00OO0OO00000 ,'',themeit =THEME3 )#line:919
		return #line:920
	OOO000OO000O0OOOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:921
	OO000O00O0O00OO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0OO00OO0OO00000 ).findall (OOO000OO000O0OOOO )#line:922
	for O0OOO00OOO0O00OOO ,OOO0O0OO000OOO00O ,OO000OO0OOO00O00O ,O00OOO00O0O000OO0 ,OOOO0000O0OO0O000 ,OO0OOO00OOOO0OO00 ,OOO000O0O0O000OO0 ,OO0OO00OOOO000000 ,O00O0O0O0000O0O00 ,OOOOOOOO0OO00OOO0 in OO000O00O0O00OO00 :#line:923
		OO0OOO00OOOO0OO00 =OO0OOO00OOOO0OO00 if wiz .workingURL (OO0OOO00OOOO0OO00 )else ICON #line:924
		OOO000O0O0O000OO0 =OOO000O0O0O000OO0 if wiz .workingURL (OOO000O0O0O000OO0 )else FANART #line:925
		O00OO000OO00OOO00 ='%s (v%s)'%(OO0OO00OO0OO00000 ,O0OOO00OOO0O00OOO )#line:926
		if BUILDNAME ==OO0OO00OO0OO00000 and O0OOO00OOO0O00OOO >BUILDVERSION :#line:927
			O00OO000OO00OOO00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00OO000OO00OOO00 ,BUILDVERSION )#line:928
		OOOO0OOOOO00O0O0O =int (float (KODIV ));OOOOO00O0O0O0O0O0 =int (float (O00OOO00O0O000OO0 ))#line:937
		if not OOOO0OOOOO00O0O0O ==OOOOO00O0O0O0O0O0 :#line:938
			if OOOO0OOOOO00O0O0O ==16 and OOOOO00O0O0O0O0O0 <=15 :OOO0OO0OO0OOO0O00 =False #line:939
			else :OOO0OO0OO0OOO0O00 =True #line:940
		else :OOO0OO0OO0OOO0O00 =False #line:941
		addFile ('התקנה','install',OO0OO00OO0OO00000 ,'fresh',description =OOOOOOOO0OO00OOO0 ,fanart =OOO000O0O0O000OO0 ,icon =OO0OOO00OOOO0OO00 ,themeit =THEME1 )#line:945
		if not OOOO0000O0OO0O000 =='http://':#line:948
			if wiz .workingURL (OOOO0000O0OO0O000 )==True :#line:949
				addFile (wiz .sep ('THEMES'),'',fanart =OOO000O0O0O000OO0 ,icon =OO0OOO00OOOO0OO00 ,themeit =THEME3 )#line:950
				OOO000OO000O0OOOO =wiz .openURL (OOOO0000O0OO0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:951
				OO000O00O0O00OO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOO000OO000O0OOOO )#line:952
				for O0OOO0O000OOO00O0 ,O0OO000OO0O0OOOOO ,O0O0OO0O000OOO00O ,O00OO00O00OOOO0OO ,OO0O000OO0O0O00OO ,OOOOOOOO0OO00OOO0 in OO000O00O0O00OO00 :#line:953
					if not SHOWADULT =='true'and OO0O000OO0O0O00OO .lower ()=='yes':continue #line:954
					O0O0OO0O000OOO00O =O0O0OO0O000OOO00O if O0O0OO0O000OOO00O =='http://'else OO0OOO00OOOO0OO00 #line:955
					O00OO00O00OOOO0OO =O00OO00O00OOOO0OO if O00OO00O00OOOO0OO =='http://'else OOO000O0O0O000OO0 #line:956
					addFile (O0OOO0O000OOO00O0 if not O0OOO0O000OOO00O0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OOO0O000OOO00O0 ,'theme',OO0OO00OO0OO00000 ,O0OOO0O000OOO00O0 ,description =OOOOOOOO0OO00OOO0 ,fanart =O00OO00O00OOOO0OO ,icon =O0O0OO0O000OOO00O ,themeit =THEME3 )#line:957
	setView ('files','viewType')#line:958
def viewThirdList (OOO00OO0000O0O0O0 ):#line:960
	OO0000O00OOOOOO00 =eval ('THIRD%sNAME'%OOO00OO0000O0O0O0 )#line:961
	O0O00000OOOOOO000 =eval ('THIRD%sURL'%OOO00OO0000O0O0O0 )#line:962
	O0OO00O0OOOOO0O0O =wiz .workingURL (O0O00000OOOOOO000 )#line:963
	if not O0OO00O0OOOOO0O0O ==True :#line:964
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:965
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:966
	else :#line:967
		OO0OOO0O00000O00O ,OOO0O00O0OOOOO000 =wiz .thirdParty (O0O00000OOOOOO000 )#line:968
		addFile ("[B]%s[/B]"%OO0000O00OOOOOO00 ,'',themeit =THEME3 )#line:969
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:970
		if OO0OOO0O00000O00O :#line:971
			for OO0000O00OOOOOO00 ,OO0OO000O0000000O ,O0O00000OOOOOO000 ,OO0OOO0OOOOOO0O00 ,O0OO0O0O0O00O0000 ,OOO00OO0O0000OO00 ,OO000OO00OO00O0OO ,O000000O00O0O0O00 in OOO0O00O0OOOOO000 :#line:972
				if not SHOWADULT =='true'and OO000OO00OO00O0OO .lower ()=='yes':continue #line:973
				addFile ("[%s] %s v%s"%(OO0OOO0OOOOOO0O00 ,OO0000O00OOOOOO00 ,OO0OO000O0000000O ),'installthird',OO0000O00OOOOOO00 ,O0O00000OOOOOO000 ,icon =O0OO0O0O0O00O0000 ,fanart =OOO00OO0O0000OO00 ,description =O000000O00O0O0O00 ,themeit =THEME2 )#line:974
		else :#line:975
			for OO0000O00OOOOOO00 ,O0O00000OOOOOO000 ,O0OO0O0O0O00O0000 ,OOO00OO0O0000OO00 ,O000000O00O0O0O00 in OOO0O00O0OOOOO000 :#line:976
				addFile (OO0000O00OOOOOO00 ,'installthird',OO0000O00OOOOOO00 ,O0O00000OOOOOO000 ,icon =O0OO0O0O0O00O0000 ,fanart =OOO00OO0O0000OO00 ,description =O000000O00O0O0O00 ,themeit =THEME2 )#line:977
def editThirdParty (O00OO0O000OOO00OO ):#line:979
	OO00O00O0O00O0OOO =eval ('THIRD%sNAME'%O00OO0O000OOO00OO )#line:980
	O0O0O0O0OO0O0000O =eval ('THIRD%sURL'%O00OO0O000OOO00OO )#line:981
	OOOOO00OO000OO00O =wiz .getKeyboard (OO00O00O0O00O0OOO ,'Enter the Name of the Wizard')#line:982
	OO00O00000O000000 =wiz .getKeyboard (O0O0O0O0OO0O0000O ,'Enter the URL of the Wizard Text')#line:983
	wiz .setS ('wizard%sname'%O00OO0O000OOO00OO ,OOOOO00OO000OO00O )#line:985
	wiz .setS ('wizard%surl'%O00OO0O000OOO00OO ,OO00O00000O000000 )#line:986
def apkScraper (name =""):#line:988
	if name =='kodi':#line:989
		OO00000OO00OOO000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:990
		OOOOO00O0O0O0OOOO ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:991
		O00OOOOO00O00OO0O =wiz .openURL (OO00000OO00OOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:992
		OO00000O0OO00OO00 =wiz .openURL (OOOOO00O0O0O0OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:993
		O0O0OOOO000O00OO0 =0 #line:994
		OOO0OOO0OOOO000OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00OOOOO00O00OO0O )#line:995
		O0000000OO00OOOO0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00000O0OO00OO00 )#line:996
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:998
		O000O0OO0O00OO0O0 =False #line:999
		for OOO0O0OOOOOO0O000 ,name ,OO0OO000OOO0OOO0O ,O0OOO00O0O000OO00 in OOO0OOO0OOOO000OO :#line:1000
			if OOO0O0OOOOOO0O000 in ['../','old/']:continue #line:1001
			if not OOO0O0OOOOOO0O000 .endswith ('.apk'):continue #line:1002
			if not OOO0O0OOOOOO0O000 .find ('_')==-1 and O000O0OO0O00OO0O0 ==True :continue #line:1003
			try :#line:1004
				OO0O00000O000OO0O =name .split ('-')#line:1005
				if not OOO0O0OOOOOO0O000 .find ('_')==-1 :#line:1006
					O000O0OO0O00OO0O0 =True #line:1007
					OOO0O0000O000O0OO ,OOO0OOOOOOO0OO00O =OO0O00000O000OO0O [2 ].split ('_')#line:1008
				else :#line:1009
					OOO0O0000O000O0OO =OO0O00000O000OO0O [2 ]#line:1010
					OOO0OOOOOOO0OO00O =''#line:1011
				O0000OO00O00OOOOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00000O000OO0O [0 ].title (),OO0O00000O000OO0O [1 ],OOO0OOOOOOO0OO00O .upper (),OOO0O0000O000O0OO ,COLOR2 ,OO0OO000OOO0OOO0O .replace (' ',''),COLOR1 ,O0OOO00O0O000OO00 )#line:1012
				OOO000OOO000OO0OO =urljoin (OO00000OO00OOO000 ,OOO0O0OOOOOO0O000 )#line:1013
				addFile (O0000OO00O00OOOOO ,'apkinstall',"%s v%s%s %s"%(OO0O00000O000OO0O [0 ].title (),OO0O00000O000OO0O [1 ],OOO0OOOOOOO0OO00O .upper (),OOO0O0000O000O0OO ),OOO000OOO000OO0OO )#line:1014
				O0O0OOOO000O00OO0 +=1 #line:1015
			except :#line:1016
				wiz .log ("Error on: %s"%name )#line:1017
		for OOO0O0OOOOOO0O000 ,name ,OO0OO000OOO0OOO0O ,O0OOO00O0O000OO00 in O0000000OO00OOOO0 :#line:1019
			if OOO0O0OOOOOO0O000 in ['../','old/']:continue #line:1020
			if not OOO0O0OOOOOO0O000 .endswith ('.apk'):continue #line:1021
			if not OOO0O0OOOOOO0O000 .find ('_')==-1 :continue #line:1022
			try :#line:1023
				OO0O00000O000OO0O =name .split ('-')#line:1024
				O0000OO00O00OOOOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0O00000O000OO0O [0 ].title (),OO0O00000O000OO0O [1 ],OO0O00000O000OO0O [2 ],COLOR2 ,OO0OO000OOO0OOO0O .replace (' ',''),COLOR1 ,O0OOO00O0O000OO00 )#line:1025
				OOO000OOO000OO0OO =urljoin (OOOOO00O0O0O0OOOO ,OOO0O0OOOOOO0O000 )#line:1026
				addFile (O0000OO00O00OOOOO ,'apkinstall',"%s v%s %s"%(OO0O00000O000OO0O [0 ].title (),OO0O00000O000OO0O [1 ],OO0O00000O000OO0O [2 ]),OOO000OOO000OO0OO )#line:1027
				O0O0OOOO000O00OO0 +=1 #line:1028
			except :#line:1029
				wiz .log ("Error on: %s"%name )#line:1030
		if O0O0OOOO000O00OO0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:1031
	elif name =='spmc':#line:1032
		O0OO0OO00OOO00OO0 ='https://github.com/koying/SPMC/releases'#line:1033
		O00OOOOO00O00OO0O =wiz .openURL (O0OO0OO00OOO00OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1034
		O0O0OOOO000O00OO0 =0 #line:1035
		OOO0OOO0OOOO000OO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00OOOOO00O00OO0O )#line:1036
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:1038
		for name ,OOOOO000OOOOOO0O0 in OOO0OOO0OOOO000OO :#line:1040
			O000OOO00000OOOO0 =''#line:1041
			O0000000OO00OOOO0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OOOOO000OOOOOO0O0 )#line:1042
			for OO000O0000OOO0000 ,OO0OO0OOOOOOOOO00 ,OO0OOOOO0O0OO0O00 in O0000000OO00OOOO0 :#line:1043
				if OO0OOOOO0O0OO0O00 .find ('armeabi')==-1 :continue #line:1044
				if OO0OOOOO0O0OO0O00 .find ('launcher')>-1 :continue #line:1045
				O000OOO00000OOOO0 =urljoin ('https://github.com',OO000O0000OOO0000 )#line:1046
				break #line:1047
		if O0O0OOOO000O00OO0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:1049
def apkMenu (url =None ):#line:1051
	if url ==None :#line:1052
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1055
	if not APKFILE =='http://':#line:1056
		if url ==None :#line:1057
			O00O0O0OOO0O00O00 =wiz .workingURL (APKFILE )#line:1058
			O00OOOO000O000O00 =uservar .APKFILE #line:1059
		else :#line:1060
			O00O0O0OOO0O00O00 =wiz .workingURL (url )#line:1061
			O00OOOO000O000O00 =url #line:1062
		if O00O0O0OOO0O00O00 ==True :#line:1063
			OOOOO00O000O000OO =wiz .openURL (O00OOOO000O000O00 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1064
			OOOO00O000OO0O00O =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOOO00O000O000OO )#line:1065
			if len (OOOO00O000OO0O00O )>0 :#line:1066
				O00O0OO0O0O00OOOO =0 #line:1067
				for OOOO0O0O00OO00O0O ,OO0O00O0O0000OOO0 ,url ,OOOO000OOO00OOO00 ,OO00O00OOO00OO0OO ,OOOOOOO000O0OO00O ,O000O00000OO0OOO0 in OOOO00O000OO0O00O :#line:1068
					if not SHOWADULT =='true'and OOOOOOO000O0OO00O .lower ()=='yes':continue #line:1069
					if OO0O00O0O0000OOO0 .lower ()=='yes':#line:1070
						O00O0OO0O0O00OOOO +=1 #line:1071
						addDir ("[B]%s[/B]"%OOOO0O0O00OO00O0O ,'apk',url ,description =O000O00000OO0OOO0 ,icon =OOOO000OOO00OOO00 ,fanart =OO00O00OOO00OO0OO ,themeit =THEME3 )#line:1072
					else :#line:1073
						O00O0OO0O0O00OOOO +=1 #line:1074
						addFile (OOOO0O0O00OO00O0O ,'apkinstall',OOOO0O0O00OO00O0O ,url ,description =O000O00000OO0OOO0 ,icon =OOOO000OOO00OOO00 ,fanart =OO00O00OOO00OO0OO ,themeit =THEME2 )#line:1075
					if O00O0OO0O0O00OOOO <1 :#line:1076
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:1077
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:1078
		else :#line:1079
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:1080
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1081
			addFile ('%s'%O00O0O0OOO0O00O00 ,'',themeit =THEME3 )#line:1082
		return #line:1083
	else :wiz .log ("[APK Menu] No APK list added.")#line:1084
	setView ('files','viewType')#line:1085
def addonMenu (url =None ):#line:1087
	if not ADDONFILE =='http://':#line:1088
		if url ==None :#line:1089
			O0OO00O00OOO0OO0O =wiz .workingURL (ADDONFILE )#line:1090
			O00OO00OOOO0O0000 =uservar .ADDONFILE #line:1091
		else :#line:1092
			O0OO00O00OOO0OO0O =wiz .workingURL (url )#line:1093
			O00OO00OOOO0O0000 =url #line:1094
		if O0OO00O00OOO0OO0O ==True :#line:1095
			O00OO00OOO0O0O0O0 =wiz .openURL (O00OO00OOOO0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:1096
			OO0O0O000000OO000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O00OO00OOO0O0O0O0 )#line:1097
			if len (OO0O0O000000OO000 )>0 :#line:1098
				OOO00O0000000OOO0 =0 #line:1099
				for OO0O0OO0O0O0O00O0 ,OOOOOOO000OOOOO0O ,url ,O0000OOOO0OO0O0OO ,O0O0O0OOO000OOO0O ,OOO00000OOOO0O0OO ,OOOOO0000O0O0O000 ,O000O000OOOO00000 ,O0O000O0O00OO00OO ,OOOO000OO0OO00OO0 in OO0O0O000000OO000 :#line:1100
					if OOOOOOO000OOOOO0O .lower ()=='section':#line:1101
						OOO00O0000000OOO0 +=1 #line:1102
						addDir ("[B]%s[/B]"%OO0O0OO0O0O0O00O0 ,'addons',url ,description =OOOO000OO0OO00OO0 ,icon =OOOOO0000O0O0O000 ,fanart =O000O000OOOO00000 ,themeit =THEME3 )#line:1103
					else :#line:1104
						if not SHOWADULT =='true'and O0O000O0O00OO00OO .lower ()=='yes':continue #line:1105
						try :#line:1106
							O0OO0OOO00O0000O0 =xbmcaddon .Addon (id =OOOOOOO000OOOOO0O ).getAddonInfo ('path')#line:1107
							if os .path .exists (O0OO0OOO00O0000O0 ):#line:1108
								OO0O0OO0O0O0O00O0 ="[COLOR green][Installed][/COLOR] %s"%OO0O0OO0O0O0O00O0 #line:1109
						except :#line:1110
							pass #line:1111
						OOO00O0000000OOO0 +=1 #line:1112
						addFile (OO0O0OO0O0O0O00O0 ,'addoninstall',OOOOOOO000OOOOO0O ,O00OO00OOOO0O0000 ,description =OOOO000OO0OO00OO0 ,icon =OOOOO0000O0O0O000 ,fanart =O000O000OOOO00000 ,themeit =THEME2 )#line:1113
					if OOO00O0000000OOO0 <1 :#line:1114
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:1115
			else :#line:1116
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:1117
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:1118
		else :#line:1119
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:1120
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1121
			addFile ('%s'%O0OO00O00OOO0OO0O ,'',themeit =THEME3 )#line:1122
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:1123
	setView ('files','viewType')#line:1124
def addonInstaller (O00OO0O0OO00OOOO0 ,OOOOO000O0OOOOOO0 ):#line:1126
	if not ADDONFILE =='http://':#line:1127
		OOOO00O0OO0000OO0 =wiz .workingURL (OOOOO000O0OOOOOO0 )#line:1128
		if OOOO00O0OO0000OO0 ==True :#line:1129
			O000O0O00OOO00O00 =wiz .openURL (OOOOO000O0OOOOOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:1130
			OO0000O000O00000O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O00OO0O0OO00OOOO0 ).findall (O000O0O00OOO00O00 )#line:1131
			if len (OO0000O000O00000O )>0 :#line:1132
				for O0O000O0000OOOO00 ,OOOOO000O0OOOOOO0 ,OOOO00OO0OO000O0O ,OOOOO00OO0O0OO0OO ,O0O0O000OOO0O0000 ,OO000O0O0OOO00000 ,OO00OO00OO00OO0OO ,O00OO0O0OOO00OOO0 ,O00O0000O00000OO0 in OO0000O000O00000O :#line:1133
					if os .path .exists (os .path .join (ADDONS ,O00OO0O0OO00OOOO0 )):#line:1134
						O00OO0OOO0000OO0O =['Launch Addon','Remove Addon']#line:1135
						OOO0O0OOO00O0OO00 =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O00OO0OOO0000OO0O )#line:1136
						if OOO0O0OOO00O0OO00 ==0 :#line:1137
							wiz .ebi ('RunAddon(%s)'%O00OO0O0OO00OOOO0 )#line:1138
							xbmc .sleep (1000 )#line:1139
							return True #line:1140
						elif OOO0O0OOO00O0OO00 ==1 :#line:1141
							wiz .cleanHouse (os .path .join (ADDONS ,O00OO0O0OO00OOOO0 ))#line:1142
							try :wiz .removeFolder (os .path .join (ADDONS ,O00OO0O0OO00OOOO0 ))#line:1143
							except :pass #line:1144
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O00OO0O0OO00OOOO0 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1145
								removeAddonData (O00OO0O0OO00OOOO0 )#line:1146
							wiz .refresh ()#line:1147
							return True #line:1148
						else :#line:1149
							return False #line:1150
					O000OOOOO00O000O0 =os .path .join (ADDONS ,OOOO00OO0OO000O0O )#line:1151
					if not OOOO00OO0OO000O0O .lower ()=='none'and not os .path .exists (O000OOOOO00O000O0 ):#line:1152
						wiz .log ("Repository not installed, installing it")#line:1153
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O00OO0O0OO00OOOO0 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOO00OO0OO000O0O ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1154
							O000000OO00O0O000 =wiz .parseDOM (wiz .openURL (OOOOO00OO0O0OO0OO ),'addon',ret ='version',attrs ={'id':OOOO00OO0OO000O0O })#line:1155
							if len (O000000OO00O0O000 )>0 :#line:1156
								O00000O0O00O00000 ='%s%s-%s.zip'%(O0O0O000OOO0O0000 ,OOOO00OO0OO000O0O ,O000000OO00O0O000 [0 ])#line:1157
								wiz .log (O00000O0O00O00000 )#line:1158
								if KODIV >=17 :wiz .addonDatabase (OOOO00OO0OO000O0O ,1 )#line:1159
								installAddon (OOOO00OO0OO000O0O ,O00000O0O00O00000 )#line:1160
								wiz .ebi ('UpdateAddonRepos()')#line:1161
								wiz .log ("Installing Addon from Kodi")#line:1163
								OOOOOO0O00OOOOO00 =installFromKodi (O00OO0O0OO00OOOO0 )#line:1164
								wiz .log ("Install from Kodi: %s"%OOOOOO0O00OOOOO00 )#line:1165
								if OOOOOO0O00OOOOO00 :#line:1166
									wiz .refresh ()#line:1167
									return True #line:1168
							else :#line:1169
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOO00OO0OO000O0O )#line:1170
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O00OO0O0OO00OOOO0 ,OOOO00OO0OO000O0O ))#line:1171
					elif OOOO00OO0OO000O0O .lower ()=='none':#line:1172
						wiz .log ("No repository, installing addon")#line:1173
						O000OO000OO0OOO00 =O00OO0O0OO00OOOO0 #line:1174
						OOO0OO000O0OOOO00 =OOOOO000O0OOOOOO0 #line:1175
						installAddon (O00OO0O0OO00OOOO0 ,OOOOO000O0OOOOOO0 )#line:1176
						wiz .refresh ()#line:1177
						return True #line:1178
					else :#line:1179
						wiz .log ("Repository installed, installing addon")#line:1180
						OOOOOO0O00OOOOO00 =installFromKodi (O00OO0O0OO00OOOO0 ,False )#line:1181
						if OOOOOO0O00OOOOO00 :#line:1182
							wiz .refresh ()#line:1183
							return True #line:1184
					if os .path .exists (os .path .join (ADDONS ,O00OO0O0OO00OOOO0 )):return True #line:1185
					OOOO000000O000OO0 =wiz .parseDOM (wiz .openURL (OOOOO00OO0O0OO0OO ),'addon',ret ='version',attrs ={'id':O00OO0O0OO00OOOO0 })#line:1186
					if len (OOOO000000O000OO0 )>0 :#line:1187
						OOOOO000O0OOOOOO0 ="%s%s-%s.zip"%(OOOOO000O0OOOOOO0 ,O00OO0O0OO00OOOO0 ,OOOO000000O000OO0 [0 ])#line:1188
						wiz .log (str (OOOOO000O0OOOOOO0 ))#line:1189
						if KODIV >=17 :wiz .addonDatabase (O00OO0O0OO00OOOO0 ,1 )#line:1190
						installAddon (O00OO0O0OO00OOOO0 ,OOOOO000O0OOOOOO0 )#line:1191
						wiz .refresh ()#line:1192
					else :#line:1193
						wiz .log ("no match");return False #line:1194
			else :wiz .log ("[Addon Installer] Invalid Format")#line:1195
		else :wiz .log ("[Addon Installer] Text File: %s"%OOOO00O0OO0000OO0 )#line:1196
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:1197
def installFromKodi (O000O0OOOO00OOOOO ,over =True ):#line:1199
	if over ==True :#line:1200
		xbmc .sleep (2000 )#line:1201
	wiz .ebi ('RunPlugin(plugin://%s)'%O000O0OOOO00OOOOO )#line:1203
	if not wiz .whileWindow ('yesnodialog'):#line:1204
		return False #line:1205
	xbmc .sleep (1000 )#line:1206
	if wiz .whileWindow ('okdialog'):#line:1207
		return False #line:1208
	wiz .whileWindow ('progressdialog')#line:1209
	if os .path .exists (os .path .join (ADDONS ,O000O0OOOO00OOOOO )):return True #line:1210
	else :return False #line:1211
def installAddon (O0O00OO0OOOOOOO00 ,O0O00OOOO0O000O0O ):#line:1213
	if not wiz .workingURL (O0O00OOOO0O000O0O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,O0O00OO0OOOOOOO00 ,COLOR2 ));return #line:1214
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1215
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOOOOO00 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:1216
	OOOO0OOO0000OO0O0 =O0O00OOOO0O000O0O .split ('/')#line:1217
	O0000OO0OO0OOOO0O =os .path .join (PACKAGES ,OOOO0OOO0000OO0O0 [-1 ])#line:1218
	try :os .remove (O0000OO0OO0OOOO0O )#line:1219
	except :pass #line:1220
	downloader .download (O0O00OOOO0O000O0O ,O0000OO0OO0OOOO0O ,DP )#line:1221
	OO0O0OOO0OO00000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00OO0OOOOOOO00 )#line:1222
	DP .update (0 ,OO0O0OOO0OO00000O ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:1223
	O0000OOO00O0OO0O0 ,O00OO0OO00OOO0O00 ,O00000000OO00000O =extract .all (O0000OO0OO0OOOO0O ,ADDONS ,DP ,title =OO0O0OOO0OO00000O )#line:1224
	DP .update (0 ,OO0O0OOO0OO00000O ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:1225
	installed (O0O00OO0OOOOOOO00 )#line:1226
	installDep (O0O00OO0OOOOOOO00 ,DP )#line:1227
	DP .close ()#line:1228
	wiz .ebi ('UpdateAddonRepos()')#line:1229
	wiz .ebi ('UpdateLocalAddons()')#line:1230
	wiz .refresh ()#line:1231
def installDep (OOOOO0OO0O0O0O0OO ,DP =None ):#line:1233
	O00O000000OOO0000 =os .path .join (ADDONS ,OOOOO0OO0O0O0O0OO ,'addon.xml')#line:1234
	if os .path .exists (O00O000000OOO0000 ):#line:1235
		O0O0O00OOO0OOO0OO =open (O00O000000OOO0000 ,mode ='r');O00OO00OOOO0OOOO0 =O0O0O00OOO0OOO0OO .read ();O0O0O00OOO0OOO0OO .close ();#line:1236
		O00OO0O000OO0000O =wiz .parseDOM (O00OO00OOOO0OOOO0 ,'import',ret ='addon')#line:1237
		for O0OOOO0O0000000OO in O00OO0O000OO0000O :#line:1238
			if not 'xbmc.python'in O0OOOO0O0000000OO :#line:1239
				if not DP ==None :#line:1240
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOOO0O0000000OO ))#line:1241
				wiz .createTemp (O0OOOO0O0000000OO )#line:1242
def installed (O0O00O0O0O00OO000 ):#line:1269
	O0O0O0O0O0OOO0OOO =os .path .join (ADDONS ,O0O00O0O0O00OO000 ,'addon.xml')#line:1270
	if os .path .exists (O0O0O0O0O0OOO0OOO ):#line:1271
		try :#line:1272
			O0OOO00O0OO0OO0OO =open (O0O0O0O0O0OOO0OOO ,mode ='r');O000O00OO0O00O0O0 =O0OOO00O0OO0OO0OO .read ();O0OOO00O0OO0OO0OO .close ()#line:1273
			OOO0OO0OOO0O00000 =wiz .parseDOM (O000O00OO0O00O0O0 ,'addon',ret ='name',attrs ={'id':O0O00O0O0O00OO000 })#line:1274
			OO000OOO0OOOO00OO =os .path .join (ADDONS ,O0O00O0O0O00OO000 ,'icon.png')#line:1275
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0OO0OOO0O00000 [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',OO000OOO0OOOO00OO )#line:1276
		except :pass #line:1277
def youtubeMenu (url =None ):#line:1279
	if not YOUTUBEFILE =='http://':#line:1280
		if url ==None :#line:1281
			O0O0OOO0000O0O00O =wiz .workingURL (YOUTUBEFILE )#line:1282
			O000O0O00O0OOOOOO =uservar .YOUTUBEFILE #line:1283
		else :#line:1284
			O0O0OOO0000O0O00O =wiz .workingURL (url )#line:1285
			O000O0O00O0OOOOOO =url #line:1286
		if O0O0OOO0000O0O00O ==True :#line:1287
			OOO00000O0OO0O0O0 =wiz .openURL (O000O0O00O0OOOOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1288
			O0O000000O0OO0OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO00000O0OO0O0O0 )#line:1289
			if len (O0O000000O0OO0OOO )>0 :#line:1290
				for O0O0O0O00O0OO0O0O ,OOO0O00O00O0000OO ,url ,OOOOO00000000O0O0 ,OO0000O0O0000OOO0 ,O0O000O00O0O00OOO in O0O000000O0OO0OOO :#line:1291
					if OOO0O00O00O0000OO .lower ()=="yes":#line:1292
						addDir ("[B]%s[/B]"%O0O0O0O00O0OO0O0O ,'youtube',url ,description =O0O000O00O0O00OOO ,icon =OOOOO00000000O0O0 ,fanart =OO0000O0O0000OOO0 ,themeit =THEME3 )#line:1293
					else :#line:1294
						addFile (O0O0O0O00O0OO0O0O ,'viewVideo',url =url ,description =O0O000O00O0O00OOO ,icon =OOOOO00000000O0O0 ,fanart =OO0000O0O0000OOO0 ,themeit =THEME2 )#line:1295
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:1296
		else :#line:1297
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:1298
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1299
			addFile ('%s'%O0O0OOO0000O0O00O ,'',themeit =THEME3 )#line:1300
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:1301
	setView ('files','viewType')#line:1302
def STARTP ():#line:1303
	O000O00O0OOOO0OO0 =(ADDON .getSetting ("pass"))#line:1304
	if BUILDNAME =="":#line:1305
	 if not NOTIFY =='true':#line:1306
          OO0OO0O00OOOO0000 =wiz .workingURL (NOTIFICATION )#line:1307
	 if not NOTIFY2 =='true':#line:1308
          OO0OO0O00OOOO0000 =wiz .workingURL (NOTIFICATION2 )#line:1309
	 if not NOTIFY3 =='true':#line:1310
          OO0OO0O00OOOO0000 =wiz .workingURL (NOTIFICATION3 )#line:1311
	O0O0O00OO0OO0O00O =O000O00O0OOOO0OO0 #line:1312
	OO0OO0O00OOOO0000 =urllib2 .Request (SPEED )#line:1313
	O0O00OO00O0O00O00 =urllib2 .urlopen (OO0OO0O00OOOO0000 )#line:1314
	O0O0OOOO0OO00OO0O =O0O00OO00O0O00O00 .read ()#line:1315
	if O000O00O0OOOO0OO0 ==O0O0O00OO0OO0O00O :#line:1316
				OO0OO0O00OOOO0000 =list #line:1317
				if O0O0O00OO0OO0O00O !=O0O0OOOO0OO00OO0O :#line:1318
				   xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1319
				   sys .exit ()#line:1320
	else :#line:1321
	  xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1322
	  sys .exit ()#line:1323
	return 'ok'#line:1324
def passandpin ():#line:1325
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:1326
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:1327
def maintMenu (view =None ):#line:1328
	O000000O0OOO0000O ='[B][COLOR green]ON[/COLOR][/B]';OOOO0OOO00OO0O00O ='[B][COLOR red]OFF[/COLOR][/B]'#line:1330
	OOOOOO0000O000OO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:1331
	O000OOOO0O00O000O ='true'if AUTOCACHE =='true'else 'false'#line:1332
	O0O0OOOO0OO00OOOO ='true'if AUTOPACKAGES =='true'else 'false'#line:1333
	OO0OOO00000OO0OOO ='true'if AUTOTHUMBS =='true'else 'false'#line:1334
	OOOOOOO000O0O0OO0 ='true'if SHOWMAINT =='true'else 'false'#line:1335
	OOOOO0OOO00OOOO0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:1336
	OO0000000OO00OO00 ='true'if INCLUDEALL =='true'else 'false'#line:1337
	O000O0O000O0000OO ='true'if THIRDPARTY =='true'else 'false'#line:1338
	if wiz .Grab_Log (True )==False :OO0O000OOO00OOO00 =0 #line:1339
	else :OO0O000OOO00OOO00 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:1340
	if wiz .Grab_Log (True ,True )==False :O00O0OO00O000O00O =0 #line:1341
	else :O00O0OO00O000O00O =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:1342
	O0OOOO0O00O00OOOO =int (OO0O000OOO00OOO00 )+int (O00O0OO00O000O00O )#line:1343
	OO000OO00000O0O0O =str (O0OOOO0O00O00OOOO )+' Error(s) Found'if O0OOOO0O00O00OOOO >0 else 'None Found'#line:1344
	O0OOOO000O00O0OOO =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:1345
	if OO0000000OO00OO00 =='true':#line:1346
		OO0O0O00000O00O00 ='true'#line:1347
		OOOOOO0OOO00OOOOO ='true'#line:1348
		O00O0OOOOOOO0OO0O ='true'#line:1349
		O0O00OO0000O0OO00 ='true'#line:1350
		OO0O0OO00O00OOO0O ='true'#line:1351
		OOO0O0OOOOOOOO0OO ='true'#line:1352
		O000000OO0O000O0O ='true'#line:1353
		O0O0000OOO0OO00O0 ='true'#line:1354
	else :#line:1355
		OO0O0O00000O00O00 ='true'if INCLUDEBOB =='true'else 'false'#line:1356
		OOOOOO0OOO00OOOOO ='true'if INCLUDEPHOENIX =='true'else 'false'#line:1357
		O00O0OOOOOOO0OO0O ='true'if INCLUDESPECTO =='true'else 'false'#line:1358
		O0O00OO0000O0OO00 ='true'if INCLUDEGENESIS =='true'else 'false'#line:1359
		OO0O0OO00O00OOO0O ='true'if INCLUDEEXODUS =='true'else 'false'#line:1360
		OOO0O0OOOOOOOO0OO ='true'if INCLUDEONECHAN =='true'else 'false'#line:1361
		O000000OO0O000O0O ='true'if INCLUDESALTS =='true'else 'false'#line:1362
		O0O0000OOO0OO00O0 ='true'if INCLUDESALTSHD =='true'else 'false'#line:1363
	OO00OOO0000O0O000 =wiz .getSize (PACKAGES )#line:1364
	O00OO00OOO00000O0 =wiz .getSize (THUMBS )#line:1365
	OOO0O000000OOOO0O =wiz .getCacheSize ()#line:1366
	OOO000OOOO0OOO000 =OO00OOO0000O0O000 +O00OO00OOO00000O0 +OOO0O000000OOOO0O #line:1367
	O00OOO000OO00O0O0 =['Daily','Always','3 Days','Weekly']#line:1368
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:1369
	if view =="clean"or SHOWMAINT =='true':#line:1370
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO000OOOO0OOO000 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:1371
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O000000OOOO0O ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:1372
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO00OOO0000O0O000 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:1373
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OO00OOO00000O0 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:1374
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:1375
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:1376
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:1377
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:1378
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:1379
	if view =="addon"or SHOWMAINT =='false':#line:1380
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:1381
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:1382
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:1383
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:1384
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:1385
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:1386
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:1387
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:1388
	if view =="misc"or SHOWMAINT =='true':#line:1389
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:1390
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:1391
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:1392
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:1393
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:1394
		addFile ('View Errors in Log: %s'%(OO000OO00000O0O0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:1395
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:1396
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:1397
		addFile ('Clear Wizard Log File%s'%O0OOOO000O00O0OOO ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:1398
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:1399
	if view =="backup"or SHOWMAINT =='true':#line:1400
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:1401
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:1402
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:1403
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:1404
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:1405
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1406
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:1407
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:1408
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1409
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:1410
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:1411
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1412
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:1413
	if view =="tweaks"or SHOWMAINT =='true':#line:1414
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:1415
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:1416
		else :#line:1417
			if os .path .exists (ADVANCED ):#line:1418
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:1419
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1420
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1421
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:1422
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:1423
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:1424
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:1425
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:1426
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:1427
	addFile ('Show All Maintenance: %s'%OOOOOOO000O0O0OO0 .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:1428
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:1429
	addFile ('Third Party Wizards: %s'%O000O0O000O0000OO .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:1430
	if O000O0O000O0000OO =='true':#line:1431
		O0O0O0OO000OO000O =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:1432
		OO0OOOO000O00OOO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:1433
		O0OO00OOOO0OOOOOO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:1434
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0O0OO000OO000O ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:1435
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOOO000O00OOO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:1436
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO00OOOO0OOOOOO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:1437
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:1438
	addFile ('ניקוי אוטומטי בהפעלה: %s'%OOOOOO0000O000OO0 .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:1439
	if OOOOOO0000O000OO0 =='true':#line:1440
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00OOO000OO00O0O0 [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:1441
		addFile ('--- ניקוי קאש בהפעלה: %s'%O000OOOO0O00O000O .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:1442
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O0OOOO0OO00OOOO .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:1443
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OO0OOO00000OO0OOO .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:1444
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:1445
	addFile ('Include Video Cache in Clear Cache: %s'%OOOOO0OOO00OOOO0O .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:1446
	if OOOOO0OOO00OOOO0O =='true':#line:1447
		addFile ('--- Include All Video Addons: %s'%OO0000000OO00OO00 .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:1448
		addFile ('--- Include Bob: %s'%OO0O0O00000O00O00 .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:1449
		addFile ('--- Include Phoenix: %s'%OOOOOO0OOO00OOOOO .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:1450
		addFile ('--- Include Specto: %s'%O00O0OOOOOOO0OO0O .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:1451
		addFile ('--- Include Exodus: %s'%OO0O0OO00O00OOO0O .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:1452
		addFile ('--- Include Salts: %s'%O000000OO0O000O0O .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:1453
		addFile ('--- Include Salts HD Lite: %s'%O0O0000OOO0OO00O0 .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:1454
		addFile ('--- Include One Channel: %s'%OOO0O0OOOOOOOO0OO .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:1455
		addFile ('--- Include Genesis: %s'%O0O00OO0000O0OO00 .replace ('true',O000000O0OOO0000O ).replace ('false',OOOO0OOO00OO0O00O ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:1456
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:1457
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:1458
	setView ('files','viewType')#line:1459
def advancedWindow (url =None ):#line:1461
	if not ADVANCEDFILE =='http://':#line:1462
		if url ==None :#line:1463
			O0O00OOO0OO00O0OO =wiz .workingURL (ADVANCEDFILE )#line:1464
			OOOO0O000OO000000 =uservar .ADVANCEDFILE #line:1465
		else :#line:1466
			O0O00OOO0OO00O0OO =wiz .workingURL (url )#line:1467
			OOOO0O000OO000000 =url #line:1468
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1469
		if os .path .exists (ADVANCED ):#line:1470
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:1471
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1472
		if O0O00OOO0OO00O0OO ==True :#line:1473
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:1474
			O0O00O00OOO000OO0 =wiz .openURL (OOOO0O000OO000000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:1475
			OO000O0OO0OOO00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0O00O00OOO000OO0 )#line:1476
			if len (OO000O0OO0OOO00OO )>0 :#line:1477
				for OO0OO000O0OOOOOOO ,O0000O00O000OO000 ,url ,O0O0O0O000OO00O00 ,OOO000OO00000OOO0 ,O0000OO0000OO0000 in OO000O0OO0OOO00OO :#line:1478
					if O0000O00O000OO000 .lower ()=="yes":#line:1479
						addDir ("[B]%s[/B]"%OO0OO000O0OOOOOOO ,'advancedsetting',url ,description =O0000OO0000OO0000 ,icon =O0O0O0O000OO00O00 ,fanart =OOO000OO00000OOO0 ,themeit =THEME3 )#line:1480
					else :#line:1481
						addFile (OO0OO000O0OOOOOOO ,'writeadvanced',OO0OO000O0OOOOOOO ,url ,description =O0000OO0000OO0000 ,icon =O0O0O0O000OO00O00 ,fanart =OOO000OO00000OOO0 ,themeit =THEME2 )#line:1482
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:1483
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O00OOO0OO00O0OO )#line:1484
	else :wiz .log ("[Advanced Settings] not Enabled")#line:1485
def writeAdvanced (O0O00000000O0O0O0 ,O0O0O0O0OOO0000O0 ):#line:1487
	O0000OOO0O00OOOOO =wiz .workingURL (O0O0O0O0OOO0000O0 )#line:1488
	if O0000OOO0O00OOOOO ==True :#line:1489
		if os .path .exists (ADVANCED ):O0O0OO0OOOOO0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00000000O0O0O0 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:1490
		else :O0O0OO0OOOOO0OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0O00000000O0O0O0 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:1491
		if O0O0OO0OOOOO0OO00 ==1 :#line:1493
			O00O0OO0000OOOOO0 =wiz .openURL (O0O0O0O0OOO0000O0 )#line:1494
			OOOO0OO000OO00000 =open (ADVANCED ,'w');#line:1495
			OOOO0OO000OO00000 .write (O00O0OO0000OOOOO0 )#line:1496
			OOOO0OO000OO00000 .close ()#line:1497
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:1498
			wiz .killxbmc (True )#line:1499
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:1500
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0000OOO0O00OOOOO );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:1501
def viewAdvanced ():#line:1503
	OO0OOO0OO0OOO0OO0 =open (ADVANCED )#line:1504
	OO000OOOO0O0OO00O =OO0OOO0OO0OOO0OO0 .read ().replace ('\t','    ')#line:1505
	wiz .TextBox (ADDONTITLE ,OO000OOOO0O0OO00O )#line:1506
	OO0OOO0OO0OOO0OO0 .close ()#line:1507
def removeAdvanced ():#line:1509
	if os .path .exists (ADVANCED ):#line:1510
		wiz .removeFile (ADVANCED )#line:1511
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:1512
def showAutoAdvanced ():#line:1514
	notify .autoConfig ()#line:1515
def getIP ():#line:1517
	O0O0000O0000O0OO0 ='http://whatismyipaddress.com/'#line:1518
	if not wiz .workingURL (O0O0000O0000O0OO0 ):return 'Unknown','Unknown','Unknown'#line:1519
	OO000OOOO0O0O0OO0 =wiz .openURL (O0O0000O0000O0OO0 ).replace ('\n','').replace ('\r','')#line:1520
	if not 'Access Denied'in OO000OOOO0O0O0OO0 :#line:1521
		OOOOOOO0OOOOO0O0O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO000OOOO0O0O0OO0 )#line:1522
		O0OOO0O00OO00O00O =OOOOOOO0OOOOO0O0O [0 ]if (len (OOOOOOO0OOOOO0O0O )>0 )else 'Unknown'#line:1523
		OO0O00OOO00000000 =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO000OOOO0O0O0OO0 )#line:1524
		OO0OO00OOOO0O00OO =OO0O00OOO00000000 [0 ]if (len (OO0O00OOO00000000 )>0 )else 'Unknown'#line:1525
		O0O00OO000OO00OOO =OO0O00OOO00000000 [1 ]+', '+OO0O00OOO00000000 [2 ]+', '+OO0O00OOO00000000 [3 ]if (len (OO0O00OOO00000000 )>2 )else 'Unknown'#line:1526
		return O0OOO0O00OO00O00O ,OO0OO00OOOO0O00OO ,O0O00OO000OO00OOO #line:1527
	else :return 'Unknown','Unknown','Unknown'#line:1528
def systemInfo ():#line:1530
	OO0OOOOO00000O000 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1544
	OOO00O0O00OOOOOO0 =[];O00O0OOO0OOO0O00O =0 #line:1545
	for O0O0OO0OO00000O0O in OO0OOOOO00000O000 :#line:1546
		O0000OO0OO000O000 =wiz .getInfo (O0O0OO0OO00000O0O )#line:1547
		O0O0O0OO00O0000O0 =0 #line:1548
		while O0000OO0OO000O000 =="Busy"and O0O0O0OO00O0000O0 <10 :#line:1549
			O0000OO0OO000O000 =wiz .getInfo (O0O0OO0OO00000O0O );O0O0O0OO00O0000O0 +=1 ;wiz .log ("%s sleep %s"%(O0O0OO0OO00000O0O ,str (O0O0O0OO00O0000O0 )));xbmc .sleep (1000 )#line:1550
		OOO00O0O00OOOOOO0 .append (O0000OO0OO000O000 )#line:1551
		O00O0OOO0OOO0O00O +=1 #line:1552
	OOO0OOOOO0O0OOO00 =OOO00O0O00OOOOOO0 [8 ]if 'Una'in OOO00O0O00OOOOOO0 [8 ]else wiz .convertSize (int (float (OOO00O0O00OOOOOO0 [8 ][:-8 ]))*1024 *1024 )#line:1553
	O000OOOOO00O00OOO =OOO00O0O00OOOOOO0 [9 ]if 'Una'in OOO00O0O00OOOOOO0 [9 ]else wiz .convertSize (int (float (OOO00O0O00OOOOOO0 [9 ][:-8 ]))*1024 *1024 )#line:1554
	O0O0OO0OO0000000O =OOO00O0O00OOOOOO0 [10 ]if 'Una'in OOO00O0O00OOOOOO0 [10 ]else wiz .convertSize (int (float (OOO00O0O00OOOOOO0 [10 ][:-8 ]))*1024 *1024 )#line:1555
	O000O0OOO000O000O =wiz .convertSize (int (float (OOO00O0O00OOOOOO0 [11 ][:-2 ]))*1024 *1024 )#line:1556
	OO0O00O0O0OOO0O0O =wiz .convertSize (int (float (OOO00O0O00OOOOOO0 [12 ][:-2 ]))*1024 *1024 )#line:1557
	OOO0O00OO0OO0000O =wiz .convertSize (int (float (OOO00O0O00OOOOOO0 [13 ][:-2 ]))*1024 *1024 )#line:1558
	OOOOO0O000O0O0O0O ,O0000O0OOO000O00O ,OOOOOOOOO00OO0000 =getIP ()#line:1559
	O0O00O0OOO000O0O0 =[];OOO00O000O000OO00 =[];OOO0O0OO0OO00OOOO =[];OOOO0OO00O00O0OOO =[];OOO000O0O0OOO0O0O =[];O00O0000O000O0000 =[];OOOO0O0OOO0OO000O =[]#line:1561
	O0OO0O0O0O0O00O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:1563
	for O00O0O0O0O0O0OO00 in sorted (O0OO0O0O0O0O00O00 ,key =lambda O0000OOO0O00OOO0O :O0000OOO0O00OOO0O ):#line:1564
		O0OOO0000O0O0O00O =os .path .split (O00O0O0O0O0O0OO00 [:-1 ])[1 ]#line:1565
		if O0OOO0000O0O0O00O =='packages':continue #line:1566
		O0000OO0OOO0OO0OO =os .path .join (O00O0O0O0O0O0OO00 ,'addon.xml')#line:1567
		if os .path .exists (O0000OO0OOO0OO0OO ):#line:1568
			OO00O000O000OO0O0 =open (O0000OO0OOO0OO0OO )#line:1569
			OOO0OOOOOOO0OOO0O =OO00O000O000OO0O0 .read ()#line:1570
			O00OO00O0O000OOO0 =re .compile ("<provides>(.+?)</provides>").findall (OOO0OOOOOOO0OOO0O )#line:1571
			if len (O00OO00O0O000OOO0 )==0 :#line:1572
				if O0OOO0000O0O0O00O .startswith ('skin'):OOOO0O0OOO0OO000O .append (O0OOO0000O0O0O00O )#line:1573
				if O0OOO0000O0O0O00O .startswith ('repo'):OOO000O0O0OOO0O0O .append (O0OOO0000O0O0O00O )#line:1574
				else :O00O0000O000O0000 .append (O0OOO0000O0O0O00O )#line:1575
			elif not (O00OO00O0O000OOO0 [0 ]).find ('executable')==-1 :OOOO0OO00O00O0OOO .append (O0OOO0000O0O0O00O )#line:1576
			elif not (O00OO00O0O000OOO0 [0 ]).find ('video')==-1 :OOO0O0OO0OO00OOOO .append (O0OOO0000O0O0O00O )#line:1577
			elif not (O00OO00O0O000OOO0 [0 ]).find ('audio')==-1 :OOO00O000O000OO00 .append (O0OOO0000O0O0O00O )#line:1578
			elif not (O00OO00O0O000OOO0 [0 ]).find ('image')==-1 :O0O00O0OOO000O0O0 .append (O0OOO0000O0O0O00O )#line:1579
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1581
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1582
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1583
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:1584
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1585
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1586
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1588
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1589
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1590
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1592
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOOO0O0OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1593
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOOOO00O00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1594
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0OO0000000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1595
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1597
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000O0OOO000O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1598
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00O0O0OOO0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1599
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O00OO0OO0000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1600
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1602
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1603
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOO0O000O0O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1604
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000O0OOO000O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1605
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOOOOOOO00OO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1606
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0O00OOOOOO0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1607
	O0OO0O0O0OO0O00OO =len (O0O00O0OOO000O0O0 )+len (OOO00O000O000OO00 )+len (OOO0O0OO0OO00OOOO )+len (OOOO0OO00O00O0OOO )+len (O00O0000O000O0000 )+len (OOOO0O0OOO0OO000O )+len (OOO000O0O0OOO0O0O )#line:1609
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0OO0O0O0OO0O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1610
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0O0OO0OO00OOOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1611
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0OO00O00O0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1612
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO00O000O000OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1613
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00O0OOO000O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1614
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO000O0O0OOO0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1615
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO0O0OOO0OO000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1616
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O0000O000O0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1617
def saveMenu ():#line:1619
	O000OOOOO0O0000O0 ='[COLOR green]מופעל[/COLOR]';OOO0OOOO00000OOO0 ='[COLOR red]מבוטל[/COLOR]'#line:1620
	O0OOO000OO0O00O0O ='true'if KEEPMOVIEWALL =='true'else 'false'#line:1621
	O0O000OO000OO0000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:1622
	O0000O00O00OO00O0 ='true'if KEEPINFO =='true'else 'false'#line:1623
	O000000O0O0000OOO ='true'if KEEPSOUND =='true'else 'false'#line:1625
	OO0OOOOOOO00000OO ='true'if KEEPVIEW =='true'else 'false'#line:1626
	OOOOO0OO0OO00OOOO ='true'if KEEPSKIN =='true'else 'false'#line:1627
	O0O0OOO00OO00OO0O ='true'if KEEPSKIN2 =='true'else 'false'#line:1628
	OO0O0O0O0OO00OOOO ='true'if KEEPSKIN3 =='true'else 'false'#line:1629
	O0OO00000OO0OO0OO ='true'if KEEPADDONS =='true'else 'false'#line:1630
	OO00O00OOOOOO0000 ='true'if KEEPPVR =='true'else 'false'#line:1631
	OO0000O00O00OOOOO ='true'if KEEPTVLIST =='true'else 'false'#line:1632
	O0OOOO000OOO0O000 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:1633
	OO00OO0OO0O00OOOO ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:1634
	O00OO0O0O0OOO00O0 ='true'if KEEPHUBTV =='true'else 'false'#line:1635
	O0O0OO0O0O0OOO00O ='true'if KEEPHUBVOD =='true'else 'false'#line:1636
	O00O00OOO0OOOO0O0 ='true'if KEEPHUBKIDS =='true'else 'false'#line:1637
	OO0000OOOOOO00000 ='true'if KEEPHUBMUSIC =='true'else 'false'#line:1638
	O0OOOOO0OOOO0OOOO ='true'if KEEPHUBMENU =='true'else 'false'#line:1639
	OOOOOO0OO0O000O0O ='true'if KEEPPLAYLIST =='true'else 'false'#line:1640
	OO00O000O000O0O00 ='true'if KEEPTRAKT =='true'else 'false'#line:1641
	OO000O00O00OO00O0 ='true'if KEEPREAL =='true'else 'false'#line:1642
	OOO00O000OO00O0OO ='true'if KEEPRD2 =='true'else 'false'#line:1643
	OO0O00O0OOO0O00O0 ='true'if KEEPTORNET =='true'else 'true'#line:1644
	OOO00O000O0OOOOOO ='true'if KEEPLOGIN =='true'else 'false'#line:1645
	O0OOOOO00000O00OO ='true'if KEEPSOURCES =='true'else 'false'#line:1646
	OOO000OOO0O0000OO ='true'if KEEPADVANCED =='true'else 'false'#line:1647
	OOO00OOO00O0OO000 ='true'if KEEPPROFILES =='true'else 'false'#line:1648
	O00000OO000OO00O0 ='true'if KEEPFAVS =='true'else 'false'#line:1649
	OO0O00O0OOOO00OOO ='true'if KEEPREPOS =='true'else 'false'#line:1650
	OO0OO0OO0OOOOO0OO ='true'if KEEPSUPER =='true'else 'false'#line:1651
	OOO0O0OO0O0O0OOOO ='true'if KEEPWHITELIST =='true'else 'false'#line:1652
	addFile ('אפשרויות שמירה קודי אנונימוס','',themeit =THEME3 )#line:1656
	if OOO0O0OO0O0O0OOOO =='true':#line:1657
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:1658
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:1659
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:1660
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:1661
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:1662
	addFile ('%s התקנת קיר סרטים: '%O0OOO000OO0O00O0O .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:1664
	addFile ('%s שמירת חשבון RD: '%OO000O00O00OO00O0 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:1665
	addFile ('%s שמירת חשבון RD להרחבה גאיה וסרן: '%OOO00O000OO00O0OO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeprd2',icon =ICONREAL ,themeit =THEME1 )#line:1666
	addFile ('%s שמירת מועדפים: '%O00000OO000OO00O0 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:1667
	addFile ('%s שמירת לקוח טלוויזיה: '%OO00O00OOOOOO0000 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:1668
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OO0000O00O00OOOOO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:1669
	addFile ('%s שמירת אריח סרטים: '%O0OOOO000OOO0O000 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:1670
	addFile ('%s שמירת אריח סדרות: '%OO00OO0OO0O00OOOO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:1671
	addFile ('%s שמירת אריח טלויזיה: '%O00OO0O0O0OOO00O0 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:1672
	addFile ('%s שמירת אריח תוכן ישראלי: '%O0O0OO0O0O0OOO00O .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:1673
	addFile ('%s שמירת אריח ילדים: '%O00O00OOO0OOOO0O0 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:1674
	addFile ('%s שמירת אריח מוסיקה: '%OO0000OOOOOO00000 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:1675
	addFile ('%s שמירת תפריט אריחים ראשי: '%O0OOOOO0OOOO0OOOO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:1676
	addFile ('%s שמירת כל האריחים בסקין: '%OOOOO0OO0OO00OOOO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:1677
	addFile ('%s שמירת הרחבות שהתקנתי: '%O0OO00000OO0OO0OO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:1684
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%O0000O00O00OO00O0 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:1685
	addFile ('%s שמירת ספריית סרטים וסדרות: '%O0O000OO000OO0000 .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:1688
	addFile ('%s שמירת מקורות וידאו: '%O0OOOOO00000O00OO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:1689
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%O000000O0O0000OOO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:1690
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%OO0OOOOOOO00000OO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:1692
	addFile ('%s שמירת פליליסט לאודר: '%OOOOOO0OO0O000O0O .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:1693
	addFile ('%s שמירת הרחבות ידנית: '%OOO0O0OO0O0O0OOOO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:1694
	addFile ('%s שמירת הגדרות באפר: '%OOO000OOO0O0000OO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:1698
	addFile ('%s שמירת סופר מועדפים: '%OO0OO0OO0OOOOO0OO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:1699
	addFile ('%s שמירת רשימות ריפו: '%OO0O00O0OOOO00OOO .replace ('true',O000OOOOO0O0000O0 ).replace ('false',OOO0OOOO00000OOO0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:1700
	setView ('files','viewType')#line:1702
def traktMenu ():#line:1704
	OOOOO000OO000O00O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:1705
	OOOO000OOOO0OO0O0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:1706
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:1707
	addFile ('Save Trakt Data: %s'%OOOOO000OO000O00O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:1708
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOOO000OOOO0OO0O0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1709
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1710
	for OOOOO000OO000O00O in traktit .ORDER :#line:1712
		OO0OOOOO000OOOOO0 =TRAKTID [OOOOO000OO000O00O ]['name']#line:1713
		OOOOOO00O000000O0 =TRAKTID [OOOOO000OO000O00O ]['path']#line:1714
		O000OOOOOO0OOO0OO =TRAKTID [OOOOO000OO000O00O ]['saved']#line:1715
		OO00OOOO00OOO0000 =TRAKTID [OOOOO000OO000O00O ]['file']#line:1716
		OOO0O0000OO0OOOOO =wiz .getS (O000OOOOOO0OOO0OO )#line:1717
		OOO0O0O0O00OO0O0O =traktit .traktUser (OOOOO000OO000O00O )#line:1718
		OOOOOOOOOOO00O000 =TRAKTID [OOOOO000OO000O00O ]['icon']if os .path .exists (OOOOOO00O000000O0 )else ICONTRAKT #line:1719
		O0OOOOOOOOO0OOO0O =TRAKTID [OOOOO000OO000O00O ]['fanart']if os .path .exists (OOOOOO00O000000O0 )else FANART #line:1720
		OO0OO0O0OOOOO0OOO =createMenu ('saveaddon','Trakt',OOOOO000OO000O00O )#line:1721
		O0000OO000OO0000O =createMenu ('save','Trakt',OOOOO000OO000O00O )#line:1722
		OO0OO0O0OOOOO0OOO .append ((THEME2 %'%s Settings'%OO0OOOOO000OOOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,OOOOO000OO000O00O )))#line:1723
		addFile ('[+]-> %s'%OO0OOOOO000OOOOO0 ,'',icon =OOOOOOOOOOO00O000 ,fanart =O0OOOOOOOOO0OOO0O ,themeit =THEME3 )#line:1725
		if not os .path .exists (OOOOOO00O000000O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOOOOOOO00O000 ,fanart =O0OOOOOOOOO0OOO0O ,menu =OO0OO0O0OOOOO0OOO )#line:1726
		elif not OOO0O0O0O00OO0O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',OOOOO000OO000O00O ,icon =OOOOOOOOOOO00O000 ,fanart =O0OOOOOOOOO0OOO0O ,menu =OO0OO0O0OOOOO0OOO )#line:1727
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0O0O0O00OO0O0O ,'authtrakt',OOOOO000OO000O00O ,icon =OOOOOOOOOOO00O000 ,fanart =O0OOOOOOOOO0OOO0O ,menu =OO0OO0O0OOOOO0OOO )#line:1728
		if OOO0O0000OO0OOOOO =="":#line:1729
			if os .path .exists (OO00OOOO00OOO0000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',OOOOO000OO000O00O ,icon =OOOOOOOOOOO00O000 ,fanart =O0OOOOOOOOO0OOO0O ,menu =O0000OO000OO0000O )#line:1730
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',OOOOO000OO000O00O ,icon =OOOOOOOOOOO00O000 ,fanart =O0OOOOOOOOO0OOO0O ,menu =O0000OO000OO0000O )#line:1731
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOO0O0000OO0OOOOO ,'',icon =OOOOOOOOOOO00O000 ,fanart =O0OOOOOOOOO0OOO0O ,menu =O0000OO000OO0000O )#line:1732
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1734
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1735
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1736
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1737
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1738
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1739
	setView ('files','viewType')#line:1740
def realMenu ():#line:1742
	OO0OO0O00OO0000O0 ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:1743
	O000OO0O0OO0000O0 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:1744
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:1745
	addFile ('Save Real Debrid Data: %s'%OO0OO0O00OO0000O0 ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:1746
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O000OO0O0OO0000O0 ),'',icon =ICONREAL ,themeit =THEME3 )#line:1747
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:1748
	for OO0O0O0000000OO0O in debridit .ORDER :#line:1750
		O00OOO000O00OOO0O =DEBRIDID [OO0O0O0000000OO0O ]['name']#line:1751
		O0O0O0000OO0O00O0 =DEBRIDID [OO0O0O0000000OO0O ]['path']#line:1752
		O0000OO0000O00O0O =DEBRIDID [OO0O0O0000000OO0O ]['saved']#line:1753
		OO00O0O0O0OOOOO00 =DEBRIDID [OO0O0O0000000OO0O ]['file']#line:1754
		O000O0OO0OO0OO00O =wiz .getS (O0000OO0000O00O0O )#line:1755
		O0O0OO0O0OO00O00O =debridit .debridUser (OO0O0O0000000OO0O )#line:1756
		O0O000000O00000O0 =DEBRIDID [OO0O0O0000000OO0O ]['icon']if os .path .exists (O0O0O0000OO0O00O0 )else ICONREAL #line:1757
		O000OOOOOO0000OO0 =DEBRIDID [OO0O0O0000000OO0O ]['fanart']if os .path .exists (O0O0O0000OO0O00O0 )else FANART #line:1758
		O000OO000O0OO00OO =createMenu ('saveaddon','Debrid',OO0O0O0000000OO0O )#line:1759
		OOO00O000O0OO0OOO =createMenu ('save','Debrid',OO0O0O0000000OO0O )#line:1760
		O000OO000O0OO00OO .append ((THEME2 %'%s Settings'%O00OOO000O00OOO0O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OO0O0O0000000OO0O )))#line:1761
		addFile ('[+]-> %s'%O00OOO000O00OOO0O ,'',icon =O0O000000O00000O0 ,fanart =O000OOOOOO0000OO0 ,themeit =THEME3 )#line:1763
		if not os .path .exists (O0O0O0000OO0O00O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O000000O00000O0 ,fanart =O000OOOOOO0000OO0 ,menu =O000OO000O0OO00OO )#line:1764
		elif not O0O0OO0O0OO00O00O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OO0O0O0000000OO0O ,icon =O0O000000O00000O0 ,fanart =O000OOOOOO0000OO0 ,menu =O000OO000O0OO00OO )#line:1765
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0OO0O0OO00O00O ,'authdebrid',OO0O0O0000000OO0O ,icon =O0O000000O00000O0 ,fanart =O000OOOOOO0000OO0 ,menu =O000OO000O0OO00OO )#line:1766
		if O000O0OO0OO0OO00O =="":#line:1767
			if os .path .exists (OO00O0O0O0OOOOO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OO0O0O0000000OO0O ,icon =O0O000000O00000O0 ,fanart =O000OOOOOO0000OO0 ,menu =OOO00O000O0OO0OOO )#line:1768
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OO0O0O0000000OO0O ,icon =O0O000000O00000O0 ,fanart =O000OOOOOO0000OO0 ,menu =OOO00O000O0OO0OOO )#line:1769
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O000O0OO0OO0OO00O ,'',icon =O0O000000O00000O0 ,fanart =O000OOOOOO0000OO0 ,menu =OOO00O000O0OO0OOO )#line:1770
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1772
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1773
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1774
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1775
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1776
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1777
	setView ('files','viewType')#line:1778
def loginMenu ():#line:1780
	O00O0000OO0O0O000 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:1781
	OOOOO0O0O0O000OO0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:1782
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:1783
	addFile ('Save Login Data: %s'%O00O0000OO0O0O000 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:1784
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOOO0O0O0O000OO0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1785
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1786
	for O00O0000OO0O0O000 in loginit .ORDER :#line:1788
		OOO00000OOO0OOOO0 =LOGINID [O00O0000OO0O0O000 ]['name']#line:1789
		O0OOO0OO0000O0OO0 =LOGINID [O00O0000OO0O0O000 ]['path']#line:1790
		OO0OO000OO00OOOOO =LOGINID [O00O0000OO0O0O000 ]['saved']#line:1791
		O0000OO0O0O0OOOO0 =LOGINID [O00O0000OO0O0O000 ]['file']#line:1792
		OO0000O0OOOO00OO0 =wiz .getS (OO0OO000OO00OOOOO )#line:1793
		O0O000OOO00O0OO00 =loginit .loginUser (O00O0000OO0O0O000 )#line:1794
		O0O00O00OOOO0OOOO =LOGINID [O00O0000OO0O0O000 ]['icon']if os .path .exists (O0OOO0OO0000O0OO0 )else ICONLOGIN #line:1795
		OOO000O0O0OO0OO0O =LOGINID [O00O0000OO0O0O000 ]['fanart']if os .path .exists (O0OOO0OO0000O0OO0 )else FANART #line:1796
		OOOOO000OOOO0O00O =createMenu ('saveaddon','Login',O00O0000OO0O0O000 )#line:1797
		OO00O00O00O0OOOO0 =createMenu ('save','Login',O00O0000OO0O0O000 )#line:1798
		OOOOO000OOOO0O00O .append ((THEME2 %'%s Settings'%OOO00000OOO0OOOO0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,O00O0000OO0O0O000 )))#line:1799
		addFile ('[+]-> %s'%OOO00000OOO0OOOO0 ,'',icon =O0O00O00OOOO0OOOO ,fanart =OOO000O0O0OO0OO0O ,themeit =THEME3 )#line:1801
		if not os .path .exists (O0OOO0OO0000O0OO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O00O00OOOO0OOOO ,fanart =OOO000O0O0OO0OO0O ,menu =OOOOO000OOOO0O00O )#line:1802
		elif not O0O000OOO00O0OO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',O00O0000OO0O0O000 ,icon =O0O00O00OOOO0OOOO ,fanart =OOO000O0O0OO0OO0O ,menu =OOOOO000OOOO0O00O )#line:1803
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O000OOO00O0OO00 ,'authlogin',O00O0000OO0O0O000 ,icon =O0O00O00OOOO0OOOO ,fanart =OOO000O0O0OO0OO0O ,menu =OOOOO000OOOO0O00O )#line:1804
		if OO0000O0OOOO00OO0 =="":#line:1805
			if os .path .exists (O0000OO0O0O0OOOO0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',O00O0000OO0O0O000 ,icon =O0O00O00OOOO0OOOO ,fanart =OOO000O0O0OO0OO0O ,menu =OO00O00O00O0OOOO0 )#line:1806
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',O00O0000OO0O0O000 ,icon =O0O00O00OOOO0OOOO ,fanart =OOO000O0O0OO0OO0O ,menu =OO00O00O00O0OOOO0 )#line:1807
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0000O0OOOO00OO0 ,'',icon =O0O00O00OOOO0OOOO ,fanart =OOO000O0O0OO0OO0O ,menu =OO00O00O00O0OOOO0 )#line:1808
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1810
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1811
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1812
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1813
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1814
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1815
	setView ('files','viewType')#line:1816
def fixUpdate ():#line:1818
	if KODIV <17 :#line:1819
		OO000OO00OO00OOOO =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:1820
		try :#line:1821
			os .remove (OO000OO00OO00OOOO )#line:1822
		except Exception as OO000000000OO0OOO :#line:1823
			wiz .log ("Unable to remove %s, Purging DB"%OO000OO00OO00OOOO )#line:1824
			wiz .purgeDb (OO000OO00OO00OOOO )#line:1825
	else :#line:1826
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:1827
def removeAddonMenu ():#line:1829
	OOOO000O0OO000OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:1830
	O0O0000O00O0OOO00 =[];OO0O0000O000O0000 =[]#line:1831
	for OO0000000OOO00OO0 in sorted (OOOO000O0OO000OOO ,key =lambda OOO0OO00O00OO00OO :OOO0OO00O00OO00OO ):#line:1832
		OO0OO00OOO000OOO0 =os .path .split (OO0000000OOO00OO0 [:-1 ])[1 ]#line:1833
		if OO0OO00OOO000OOO0 in EXCLUDES :continue #line:1834
		elif OO0OO00OOO000OOO0 in DEFAULTPLUGINS :continue #line:1835
		elif OO0OO00OOO000OOO0 =='packages':continue #line:1836
		O00O000O0O0OOO0OO =os .path .join (OO0000000OOO00OO0 ,'addon.xml')#line:1837
		if os .path .exists (O00O000O0O0OOO0OO ):#line:1838
			O0O000OO00OO00OO0 =open (O00O000O0O0OOO0OO )#line:1839
			O00O0O0OOOO00000O =O0O000OO00OO00OO0 .read ()#line:1840
			O0OOO000O000O0OO0 =wiz .parseDOM (O00O0O0OOOO00000O ,'addon',ret ='id')#line:1841
			O00O00OO0O0OO0OOO =OO0OO00OOO000OOO0 if len (O0OOO000O000O0OO0 )==0 else O0OOO000O000O0OO0 [0 ]#line:1843
			try :#line:1844
				OO0O0OO00OO00OO00 =xbmcaddon .Addon (id =O00O00OO0O0OO0OOO )#line:1845
				O0O0000O00O0OOO00 .append (OO0O0OO00OO00OO00 .getAddonInfo ('name'))#line:1846
				OO0O0000O000O0000 .append (O00O00OO0O0OO0OOO )#line:1847
			except :#line:1848
				pass #line:1849
	if len (O0O0000O00O0OOO00 )==0 :#line:1850
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:1851
		return #line:1852
	if KODIV >16 :#line:1853
		O0OOO0O0O000OOOO0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O0000O00O0OOO00 )#line:1854
	else :#line:1855
		O0OOO0O0O000OOOO0 =[];O0OOO00OOOO0OOOOO =0 #line:1856
		O0O00OOOOO0O00OO0 =["-- Click here to Continue --"]+O0O0000O00O0OOO00 #line:1857
		while not O0OOO00OOOO0OOOOO ==-1 :#line:1858
			O0OOO00OOOO0OOOOO =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,O0O00OOOOO0O00OO0 )#line:1859
			if O0OOO00OOOO0OOOOO ==-1 :break #line:1860
			elif O0OOO00OOOO0OOOOO ==0 :break #line:1861
			else :#line:1862
				OO0O0O0OOO00O0O00 =(O0OOO00OOOO0OOOOO -1 )#line:1863
				if OO0O0O0OOO00O0O00 in O0OOO0O0O000OOOO0 :#line:1864
					O0OOO0O0O000OOOO0 .remove (OO0O0O0OOO00O0O00 )#line:1865
					O0O00OOOOO0O00OO0 [O0OOO00OOOO0OOOOO ]=O0O0000O00O0OOO00 [OO0O0O0OOO00O0O00 ]#line:1866
				else :#line:1867
					O0OOO0O0O000OOOO0 .append (OO0O0O0OOO00O0O00 )#line:1868
					O0O00OOOOO0O00OO0 [O0OOO00OOOO0OOOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O0O0000O00O0OOO00 [OO0O0O0OOO00O0O00 ])#line:1869
	if O0OOO0O0O000OOOO0 ==None :return #line:1870
	if len (O0OOO0O0O000OOOO0 )>0 :#line:1871
		wiz .addonUpdates ('set')#line:1872
		for OO0OO00OO0OOOOOO0 in O0OOO0O0O000OOOO0 :#line:1873
			removeAddon (OO0O0000O000O0000 [OO0OO00OO0OOOOOO0 ],O0O0000O00O0OOO00 [OO0OO00OO0OOOOOO0 ],True )#line:1874
		xbmc .sleep (1000 )#line:1876
		if INSTALLMETHOD ==1 :O0OO00OOOOO00O00O =1 #line:1878
		elif INSTALLMETHOD ==2 :O0OO00OOOOO00O00O =0 #line:1879
		else :O0OO00OOOOO00O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:1880
		if O0OO00OOOOO00O00O ==1 :wiz .reloadFix ('remove addon')#line:1881
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:1882
def removeAddonDataMenu ():#line:1884
	if os .path .exists (ADDOND ):#line:1885
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:1886
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:1887
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:1888
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:1889
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1890
		OO000000O0OO0OO00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:1891
		for O0O00OOOOO0O00O00 in sorted (OO000000O0OO0OO00 ,key =lambda O0O0OOO0OOO00O000 :O0O0OOO0OOO00O000 ):#line:1892
			OO0OOO0O0000O0O00 =O0O00OOOOO0O00O00 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:1893
			OO0O0OO0OOO00O000 =os .path .join (O0O00OOOOO0O00O00 .replace (ADDOND ,ADDONS ),'icon.png')#line:1894
			O00OO00OOO0OOOO0O =os .path .join (O0O00OOOOO0O00O00 .replace (ADDOND ,ADDONS ),'fanart.png')#line:1895
			O00OO00O00OO00O0O =OO0OOO0O0000O0O00 #line:1896
			OO0000OOO0OOOOO00 ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:1897
			for O00O00OOO0O0O0000 in OO0000OOO0OOOOO00 :#line:1898
				O00OO00O00OO00O0O =O00OO00O00OO00O0O .replace (O00O00OOO0O0O0000 ,OO0000OOO0OOOOO00 [O00O00OOO0O0O0000 ])#line:1899
			if OO0OOO0O0000O0O00 in EXCLUDES :O00OO00O00OO00O0O ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O00OO00O00OO00O0O #line:1900
			else :O00OO00O00OO00O0O ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O00OO00O00OO00O0O #line:1901
			addFile (' %s'%O00OO00O00OO00O0O ,'removedata',OO0OOO0O0000O0O00 ,icon =OO0O0OO0OOO00O000 ,fanart =O00OO00OOO0OOOO0O ,themeit =THEME2 )#line:1902
	else :#line:1903
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:1904
	setView ('files','viewType')#line:1905
def enableAddons ():#line:1907
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:1908
	O0O00O0000O000O00 =glob .glob (os .path .join (ADDONS ,'*/'))#line:1909
	OOOOO0000O0O00O0O =0 #line:1910
	for OOO0OO000OO0O0000 in sorted (O0O00O0000O000O00 ,key =lambda O0O000000O00OO0OO :O0O000000O00OO0OO ):#line:1911
		O0OO00000OOO000OO =os .path .split (OOO0OO000OO0O0000 [:-1 ])[1 ]#line:1912
		if O0OO00000OOO000OO in EXCLUDES :continue #line:1913
		if O0OO00000OOO000OO in DEFAULTPLUGINS :continue #line:1914
		O000OO000O0000000 =os .path .join (OOO0OO000OO0O0000 ,'addon.xml')#line:1915
		if os .path .exists (O000OO000O0000000 ):#line:1916
			OOOOO0000O0O00O0O +=1 #line:1917
			O0O00O0000O000O00 =OOO0OO000OO0O0000 .replace (ADDONS ,'')[1 :-1 ]#line:1918
			OOOOO0OO00000O0OO =open (O000OO000O0000000 )#line:1919
			OOO00OO000OO0O0O0 =OOOOO0OO00000O0OO .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:1920
			OO000OOOOO0O0O0OO =wiz .parseDOM (OOO00OO000OO0O0O0 ,'addon',ret ='id')#line:1921
			OOO0O0OO00OOOO00O =wiz .parseDOM (OOO00OO000OO0O0O0 ,'addon',ret ='name')#line:1922
			try :#line:1923
				OOOOOO0OOO000OOO0 =OO000OOOOO0O0O0OO [0 ]#line:1924
				OOOOO0OOO0OO0OOO0 =OOO0O0OO00OOOO00O [0 ]#line:1925
			except :#line:1926
				continue #line:1927
			try :#line:1928
				OO0OOOOOOOOOO0OO0 =xbmcaddon .Addon (id =OOOOOO0OOO000OOO0 )#line:1929
				O0O0OO0OO0OO0O000 ="[COLOR green][Enabled][/COLOR]"#line:1930
				OO0O00O000O00OO00 ="false"#line:1931
			except :#line:1932
				O0O0OO0OO0OO0O000 ="[COLOR red][Disabled][/COLOR]"#line:1933
				OO0O00O000O00OO00 ="true"#line:1934
				pass #line:1935
			OOO0O0OOO0O00OOO0 =os .path .join (OOO0OO000OO0O0000 ,'icon.png')if os .path .exists (os .path .join (OOO0OO000OO0O0000 ,'icon.png'))else ICON #line:1936
			OO0000O0OO0OO0OO0 =os .path .join (OOO0OO000OO0O0000 ,'fanart.jpg')if os .path .exists (os .path .join (OOO0OO000OO0O0000 ,'fanart.jpg'))else FANART #line:1937
			addFile ("%s %s"%(O0O0OO0OO0OO0O000 ,OOOOO0OOO0OO0OOO0 ),'toggleaddon',O0O00O0000O000O00 ,OO0O00O000O00OO00 ,icon =OOO0O0OOO0O00OOO0 ,fanart =OO0000O0OO0OO0OO0 )#line:1938
			OOOOO0OO00000O0OO .close ()#line:1939
	if OOOOO0000O0O00O0O ==0 :#line:1940
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:1941
	setView ('files','viewType')#line:1942
def changeFeq ():#line:1944
	O0OO00OO0OOOOO000 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:1945
	OOO0OO0OOOO00O0OO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O0OO00OO0OOOOO000 )#line:1946
	if not OOO0OO0OOOO00O0OO ==-1 :#line:1947
		wiz .setS ('autocleanfeq',str (OOO0OO0OOOO00O0OO ))#line:1948
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O0OO00OO0OOOOO000 [OOO0OO0OOOO00O0OO ]))#line:1949
def developer ():#line:1951
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:1952
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:1953
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:1954
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:1955
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:1956
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:1957
	addFile ('Test APk','testapk',themeit =THEME1 )#line:1958
	setView ('files','viewType')#line:1960
def download (OOO0OO000000O00OO ,OOOOOOOO0OO0OOOO0 ):#line:1965
  OOOOOO0O00OO0O000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:1966
  O0OO00OO00OOO000O =xbmcgui .DialogProgress ()#line:1967
  O0OO00OO00OOO000O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:1968
  OOOO00OO000O0O0OO =os .path .join (OOOOOO0O00OO0O000 ,'isr.zip')#line:1969
  OO00OO0000O0OO0O0 =urllib2 .Request (OOO0OO000000O00OO )#line:1970
  O00OOOOOO00OOOOO0 =urllib2 .urlopen (OO00OO0000O0OO0O0 )#line:1971
  O0O0O00O0OO0OOOOO =xbmcgui .DialogProgress ()#line:1973
  O0O0O00O0OO0OOOOO .create ("Downloading","Downloading "+name )#line:1974
  O0O0O00O0OO0OOOOO .update (0 )#line:1975
  O0OO0000O0O00OOOO =OOOOOOOO0OO0OOOO0 #line:1976
  O000O0O0O0OOOOO00 =open (OOOO00OO000O0O0OO ,'wb')#line:1977
  try :#line:1979
    OOOOO00OOO00OOO00 =O00OOOOOO00OOOOO0 .info ().getheader ('Content-Length').strip ()#line:1980
    OO0OOOOO00OOO000O =True #line:1981
  except AttributeError :#line:1982
        OO0OOOOO00OOO000O =False #line:1983
  if OO0OOOOO00OOO000O :#line:1985
        OOOOO00OOO00OOO00 =int (OOOOO00OOO00OOO00 )#line:1986
  OO00OOO0O0OOOOO0O =0 #line:1988
  OO0O0O000OO00OO0O =time .time ()#line:1989
  while True :#line:1990
        O0000OOO0OO0OO00O =O00OOOOOO00OOOOO0 .read (8192 )#line:1991
        if not O0000OOO0OO0OO00O :#line:1992
            sys .stdout .write ('\n')#line:1993
            break #line:1994
        OO00OOO0O0OOOOO0O +=len (O0000OOO0OO0OO00O )#line:1996
        O000O0O0O0OOOOO00 .write (O0000OOO0OO0OO00O )#line:1997
        if not OO0OOOOO00OOO000O :#line:1999
            OOOOO00OOO00OOO00 =OO00OOO0O0OOOOO0O #line:2000
        if O0O0O00O0OO0OOOOO .iscanceled ():#line:2001
           O0O0O00O0OO0OOOOO .close ()#line:2002
           try :#line:2003
            os .remove (OOOO00OO000O0O0OO )#line:2004
           except :#line:2005
            pass #line:2006
           break #line:2007
        O0OOOOOO00O0O0OO0 =float (OO00OOO0O0OOOOO0O )/OOOOO00OOO00OOO00 #line:2008
        O0OOOOOO00O0O0OO0 =round (O0OOOOOO00O0O0OO0 *100 ,2 )#line:2009
        O000O0O0OO00OO000 =OO00OOO0O0OOOOO0O /(1024 *1024 )#line:2010
        O00OOO00OOOO0OOO0 =OOOOO00OOO00OOO00 /(1024 *1024 )#line:2011
        O00O00000O0OOO000 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O000O0O0OO00OO000 ,'teal',O00OOO00OOOO0OOO0 )#line:2012
        if (time .time ()-OO0O0O000OO00OO0O )>0 :#line:2013
          OO00OO0OOO0O00O0O =OO00OOO0O0OOOOO0O /(time .time ()-OO0O0O000OO00OO0O )#line:2014
          OO00OO0OOO0O00O0O =OO00OO0OOO0O00O0O /1024 #line:2015
        else :#line:2016
         OO00OO0OOO0O00O0O =0 #line:2017
        OO0O0O00OO0OO00OO ='KB'#line:2018
        if OO00OO0OOO0O00O0O >=1024 :#line:2019
           OO00OO0OOO0O00O0O =OO00OO0OOO0O00O0O /1024 #line:2020
           OO0O0O00OO0OO00OO ='MB'#line:2021
        if OO00OO0OOO0O00O0O >0 and not O0OOOOOO00O0O0OO0 ==100 :#line:2022
            OOO00OO00O0OO0OO0 =(OOOOO00OOO00OOO00 -OO00OOO0O0OOOOO0O )/OO00OO0OOO0O00O0O #line:2023
        else :#line:2024
            OOO00OO00O0OO0OO0 =0 #line:2025
        OO0000O0OO0OOOO0O ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OO00OO0OOO0O00O0O ,OO0O0O00OO0OO00OO )#line:2026
        O0O0O00O0OO0OOOOO .update (int (O0OOOOOO00O0O0OO0 ),"Downloading "+name ,O00O00000O0OOO000 ,OO0000O0OO0OOOO0O )#line:2028
  O00OOOO000O0O00O0 =xbmc .translatePath (os .path .join ('special://home','addons'))#line:2031
  O000O0O0O0OOOOO00 .close ()#line:2033
  extract (OOOO00OO000O0O0OO ,O00OOOO000O0O00O0 ,O0O0O00O0OO0OOOOO )#line:2035
  if os .path .exists (O00OOOO000O0O00O0 +'/scakemyer-script.quasar.burst'):#line:2036
    if os .path .exists (O00OOOO000O0O00O0 +'/script.quasar.burst'):#line:2037
     shutil .rmtree (O00OOOO000O0O00O0 +'/script.quasar.burst',ignore_errors =False )#line:2038
    os .rename (O00OOOO000O0O00O0 +'/scakemyer-script.quasar.burst',O00OOOO000O0O00O0 +'/script.quasar.burst')#line:2039
  if os .path .exists (O00OOOO000O0O00O0 +'/plugin.video.kmediatorrent-master'):#line:2041
    if os .path .exists (O00OOOO000O0O00O0 +'/plugin.video.kmediatorrent'):#line:2042
     shutil .rmtree (O00OOOO000O0O00O0 +'/plugin.video.kmediatorrent',ignore_errors =False )#line:2043
    os .rename (O00OOOO000O0O00O0 +'/plugin.video.kmediatorrent-master',O00OOOO000O0O00O0 +'/plugin.video.kmediatorrent')#line:2044
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:2045
  xbmc .executebuiltin ("UpdateAddonRepos")#line:2046
  try :#line:2047
    os .remove (OOOO00OO000O0O0OO )#line:2048
  except :#line:2049
    pass #line:2050
  O0O0O00O0OO0OOOOO .close ()#line:2051
def dis_or_enable_addon (OO0O000O0OO0O0O00 ,OOO0OO0OO000O0000 ,enable ="true"):#line:2052
    import json #line:2053
    OOO0000OO00OO00OO ='"%s"'%OO0O000O0OO0O0O00 #line:2054
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O000O0OO0O0O00 )and enable =="true":#line:2055
        logging .warning ('already Enabled')#line:2056
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO0O000O0OO0O0O00 )#line:2057
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO0O000O0OO0O0O00 )and enable =="false":#line:2058
        return xbmc .log ("### Skipped %s, reason = not installed"%OO0O000O0OO0O0O00 )#line:2059
    else :#line:2060
        O00O0OOOO00OO0000 ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOO0000OO00OO00OO ,enable )#line:2061
        O0OOOOOOOOOO0OO00 =xbmc .executeJSONRPC (O00O0OOOO00OO0000 )#line:2062
        O00O0000OOO00OOOO =json .loads (O0OOOOOOOOOO0OO00 )#line:2063
        if enable =="true":#line:2064
            xbmc .log ("### Enabled %s, response = %s"%(OO0O000O0OO0O0O00 ,O00O0000OOO00OOOO ))#line:2065
        else :#line:2066
            xbmc .log ("### Disabled %s, response = %s"%(OO0O000O0OO0O0O00 ,O00O0000OOO00OOOO ))#line:2067
    if OOO0OO0OO000O0000 =='auto':#line:2068
     return True #line:2069
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:2070
def chunk_report (OO000O0O00OOO000O ,O0OO00000OOO0OO00 ,O00000O0OO0000O0O ):#line:2071
   OO0OO00OO00OOO0OO =float (OO000O0O00OOO000O )/O00000O0OO0000O0O #line:2072
   OO0OO00OO00OOO0OO =round (OO0OO00OO00OOO0OO *100 ,2 )#line:2073
   if OO000O0O00OOO000O >=O00000O0OO0000O0O :#line:2075
      sys .stdout .write ('\n')#line:2076
def chunk_read (OOO00OOO0O00O0OO0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:2078
   import time #line:2079
   O00OO0OO00O0000OO =int (filesize )*1000000 #line:2080
   O00OO00OOOOOOOOO0 =0 #line:2082
   O0O0000OO0O0OOO0O =time .time ()#line:2083
   O00000OOOO00O00O0 =0 #line:2084
   logging .warning ('Downloading')#line:2086
   with open (destination ,"wb")as OOO0OO00OOOOOO000 :#line:2087
    while 1 :#line:2088
      OO000O00000O00O0O =time .time ()-O0O0000OO0O0OOO0O #line:2089
      OO0000O000OO0OOOO =int (O00000OOOO00O00O0 *chunk_size )#line:2090
      OOO0OOOOOO0O0O0O0 =OOO00OOO0O00O0OO0 .read (chunk_size )#line:2091
      OOO0OO00OOOOOO000 .write (OOO0OOOOOO0O0O0O0 )#line:2092
      OOO0OO00OOOOOO000 .flush ()#line:2093
      O00OO00OOOOOOOOO0 +=len (OOO0OOOOOO0O0O0O0 )#line:2094
      OO0000OO0O0OOO0OO =float (O00OO00OOOOOOOOO0 )/O00OO0OO00O0000OO #line:2095
      OO0000OO0O0OOO0OO =round (OO0000OO0O0OOO0OO *100 ,2 )#line:2096
      if int (OO000O00000O00O0O )>0 :#line:2097
        OO00OO000O0O0OOOO =int (OO0000O000OO0OOOO /(1024 *OO000O00000O00O0O ))#line:2098
      else :#line:2099
         OO00OO000O0O0OOOO =0 #line:2100
      if OO00OO000O0O0OOOO >1024 and not OO0000OO0O0OOO0OO ==100 :#line:2101
          OOO0OO00O00OO0O00 =int (((O00OO0OO00O0000OO -OO0000O000OO0OOOO )/1024 )/(OO00OO000O0O0OOOO ))#line:2102
      else :#line:2103
          OOO0OO00O00OO0O00 =0 #line:2104
      if OOO0OO00O00OO0O00 <0 :#line:2105
        OOO0OO00O00OO0O00 =0 #line:2106
      dp .update (int (OO0000OO0O0OOO0OO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0000OO0O0OOO0OO ,OO0000O000OO0OOOO /(1024 *1024 ),O00OO0OO00O0000OO /(1000 *1000 ),OO00OO000O0O0OOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOO0OO00O00OO0O00 ,60 ))#line:2107
      if dp .iscanceled ():#line:2108
         dp .close ()#line:2109
         break #line:2110
      if not OOO0OOOOOO0O0O0O0 :#line:2111
         break #line:2112
      if report_hook :#line:2114
         report_hook (O00OO00OOOOOOOOO0 ,chunk_size ,O00OO0OO00O0000OO )#line:2115
      O00000OOOO00O00O0 +=1 #line:2116
   logging .warning ('END Downloading')#line:2117
   return O00OO00OOOOOOOOO0 #line:2118
def googledrive_download (O0OOO0OOOOO00OOO0 ,O0O00OOO0OOOOO00O ,O0OOOOO0OO0OOO0OO ,O0OO00O0O0000O00O ):#line:2120
    O000OO000O00OO00O =[]#line:2124
    OO0OOOOOO0OO0OOOO =O0OOO0OOOOO00OOO0 .split ('=')#line:2125
    O0OOO0OOOOO00OOO0 =OO0OOOOOO0OO0OOOO [len (OO0OOOOOO0OO0OOOO )-1 ]#line:2126
    def OO0000OO00O0OO0OO (O0O0O0O0O00O00000 ):#line:2128
        for O0OO0OO00OOOOO0OO in O0O0O0O0O00O00000 :#line:2130
            logging .warning ('cookie.name')#line:2131
            logging .warning (O0OO0OO00OOOOO0OO .name )#line:2132
            O0OO0O0OO00000OOO =O0OO0OO00OOOOO0OO .value #line:2133
            if 'download_warning'in O0OO0OO00OOOOO0OO .name :#line:2134
                logging .warning (O0OO0OO00OOOOO0OO .value )#line:2135
                logging .warning ('cookie.value')#line:2136
                return O0OO0OO00OOOOO0OO .value #line:2137
            return O0OO0O0OO00000OOO #line:2138
        return None #line:2140
    def O0O0OOO0O0OO0O00O (O000000OO0OO0O0O0 ,O0OO0O00OO000O000 ):#line:2142
        OO000000000OOOOO0 =32768 #line:2144
        OO00OOO0OOOO0OOOO =time .time ()#line:2145
        with open (O0OO0O00OO000O000 ,"wb")as O00OOO000OOO00OOO :#line:2147
            OO0OOOOO0O0O0OOOO =1 #line:2148
            OO0OO0O00OO00OO0O =32768 #line:2149
            try :#line:2150
                O0O0OOO000000OOOO =int (O000000OO0OO0O0O0 .headers .get ('content-length'))#line:2151
                print ('file total size :',O0O0OOO000000OOOO )#line:2152
            except TypeError :#line:2153
                print ('using dummy length !!!')#line:2154
                O0O0OOO000000OOOO =int (O0OO00O0O0000O00O )*1000000 #line:2155
            for O0000O000OOOOOOO0 in O000000OO0OO0O0O0 .iter_content (OO000000000OOOOO0 ):#line:2156
                if O0000O000OOOOOOO0 :#line:2157
                    O00OOO000OOO00OOO .write (O0000O000OOOOOOO0 )#line:2158
                    O00OOO000OOO00OOO .flush ()#line:2159
                    O0O00OOO00OO00O00 =time .time ()-OO00OOO0OOOO0OOOO #line:2160
                    O00O0OO00OO00OOO0 =int (OO0OOOOO0O0O0OOOO *OO0OO0O00OO00OO0O )#line:2161
                    if O0O00OOO00OO00O00 ==0 :#line:2162
                        O0O00OOO00OO00O00 =0.1 #line:2163
                    O0OO0OO00OO0000O0 =int (O00O0OO00OO00OOO0 /(1024 *O0O00OOO00OO00O00 ))#line:2164
                    OOOOO0OO0O0OOOOOO =int (OO0OOOOO0O0O0OOOO *OO0OO0O00OO00OO0O *100 /O0O0OOO000000OOOO )#line:2165
                    if O0OO0OO00OO0000O0 >1024 and not OOOOO0OO0O0OOOOOO ==100 :#line:2166
                      O0O00OOO000OO000O =int (((O0O0OOO000000OOOO -O00O0OO00OO00OOO0 )/1024 )/(O0OO0OO00OO0000O0 ))#line:2167
                    else :#line:2168
                      O0O00OOO000OO000O =0 #line:2169
                    O0OOOOO0OO0OOO0OO .update (int (OOOOO0OO0O0OOOOOO ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOOO0OO0O0OOOOOO ,O00O0OO00OO00OOO0 /(1024 *1024 ),O0O0OOO000000OOOO /(1000 *1000 ),O0OO0OO00OO0000O0 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0O00OOO000OO000O ,60 ))#line:2171
                    OO0OOOOO0O0O0OOOO +=1 #line:2172
                    if O0OOOOO0OO0OOO0OO .iscanceled ():#line:2173
                     O0OOOOO0OO0OOO0OO .close ()#line:2174
                     break #line:2175
    O0OOO0OO0OO0OO00O ="https://docs.google.com/uc?export=download"#line:2176
    import urllib2 #line:2181
    import cookielib #line:2182
    from cookielib import CookieJar #line:2184
    OOOOOOOO0O00OOO00 =CookieJar ()#line:2186
    OOOOO0OO0OO0O0O0O =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OOOOOOOO0O00OOO00 ))#line:2187
    OO00O0O0O0O000OO0 ={'id':O0OOO0OOOOO00OOO0 }#line:2189
    O0OO0O00OOO0O0OO0 =urllib .urlencode (OO00O0O0O0O000OO0 )#line:2190
    logging .warning (O0OOO0OO0OO0OO00O +'&'+O0OO0O00OOO0O0OO0 )#line:2191
    OO000OOOO0OO000OO =OOOOO0OO0OO0O0O0O .open (O0OOO0OO0OO0OO00O +'&'+O0OO0O00OOO0O0OO0 )#line:2192
    OOOO0OO0OOO0O0O00 =OO000OOOO0OO000OO .read ()#line:2193
    for OO0OOOO00OOO00OO0 in OOOOOOOO0O00OOO00 :#line:2195
         logging .warning (OO0OOOO00OOO00OO0 )#line:2196
    O00O00OOO0000000O =OO0000OO00O0OO0OO (OOOOOOOO0O00OOO00 )#line:2197
    logging .warning (O00O00OOO0000000O )#line:2198
    if O00O00OOO0000000O :#line:2199
        OOO00O0OOO00O0O0O ={'id':O0OOO0OOOOO00OOO0 ,'confirm':O00O00OOO0000000O }#line:2200
        O0OO00OO0O00O0O0O ={'Access-Control-Allow-Headers':'Content-Length'}#line:2201
        O0OO0O00OOO0O0OO0 =urllib .urlencode (OOO00O0OOO00O0O0O )#line:2202
        OO000OOOO0OO000OO =OOOOO0OO0OO0O0O0O .open (O0OOO0OO0OO0OO00O +'&'+O0OO0O00OOO0O0OO0 )#line:2203
        chunk_read (OO000OOOO0OO000OO ,report_hook =chunk_report ,dp =O0OOOOO0OO0OOO0OO ,destination =O0O00OOO0OOOOO00O ,filesize =O0OO00O0O0000O00O )#line:2204
    return (O000OO000O00OO00O )#line:2208
def kodi17Fix ():#line:2209
	O0O0O0OO0O00OO00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:2210
	OOOOOO00O0O0O0OOO =[]#line:2211
	for O0OO0OO000OOO0OO0 in sorted (O0O0O0OO0O00OO00O ,key =lambda O0O0O00O0O000O00O :O0O0O00O0O000O00O ):#line:2212
		O0O00OOO000O0O0OO =os .path .join (O0OO0OO000OOO0OO0 ,'addon.xml')#line:2213
		if os .path .exists (O0O00OOO000O0O0OO ):#line:2214
			O00O00OOO0O0O000O =O0OO0OO000OOO0OO0 .replace (ADDONS ,'')[1 :-1 ]#line:2215
			O0O0OO0O000O0OOOO =open (O0O00OOO000O0O0OO )#line:2216
			O0O00OO000OOO00O0 =O0O0OO0O000O0OOOO .read ()#line:2217
			O0OOOOOOOOOOOOO00 =parseDOM (O0O00OO000OOO00O0 ,'addon',ret ='id')#line:2218
			O0O0OO0O000O0OOOO .close ()#line:2219
			try :#line:2220
				OOOOO00O0OO00OOO0 =xbmcaddon .Addon (id =O0OOOOOOOOOOOOO00 [0 ])#line:2221
			except :#line:2222
				try :#line:2223
					log ("%s was disabled"%O0OOOOOOOOOOOOO00 [0 ],xbmc .LOGDEBUG )#line:2224
					OOOOOO00O0O0O0OOO .append (O0OOOOOOOOOOOOO00 [0 ])#line:2225
				except :#line:2226
					try :#line:2227
						log ("%s was disabled"%O00O00OOO0O0O000O ,xbmc .LOGDEBUG )#line:2228
						OOOOOO00O0O0O0OOO .append (O00O00OOO0O0O000O )#line:2229
					except :#line:2230
						if len (O0OOOOOOOOOOOOO00 )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O00O00OOO0O0O000O ,xbmc .LOGERROR )#line:2231
						else :log ("Unabled to enable: %s"%O0OO0OO000OOO0OO0 ,xbmc .LOGERROR )#line:2232
	if len (OOOOOO00O0O0O0OOO )>0 :#line:2233
		OOOOO0O0O0O0OO00O =0 #line:2234
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:2235
		for OOO00000000000OO0 in OOOOOO00O0O0O0OOO :#line:2236
			OOOOO0O0O0O0OO00O +=1 #line:2237
			OO0000OOO0O000O00 =int (percentage (OOOOO0O0O0O0OO00O ,len (OOOOOO00O0O0O0OOO )))#line:2238
			DP .update (OO0000OOO0O000O00 ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,OOO00000000000OO0 ))#line:2239
			addonDatabase (OOO00000000000OO0 ,1 )#line:2240
			if DP .iscanceled ():break #line:2241
		if DP .iscanceled ():#line:2242
			DP .close ()#line:2243
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:2244
			sys .exit ()#line:2245
		DP .close ()#line:2246
	forceUpdate ()#line:2247
def indicator ():#line:2248
       try :#line:2249
          import json #line:2250
          wiz .log ('FRESH MESSAGE')#line:2251
          O0O00O00OO0OO0000 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDc1MDEwMDI1NjpBQUVJVnpTSndOM2t6T25EV0F3Yi1LTkk3VUREY2N6aEx6VS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxNDE1ODcxNzk3JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:2253
          OOO0O00OOOOO00O00 =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:2254
          OOOOOOOOOOOO0O00O =str (json .loads (OOO0O00OOOOO00O00 )['ip'])#line:2255
          import socket #line:2256
          OOO0O00OOOOO00O00 =urllib2 .urlopen (O0O00O00OO0OO0000 .decode ('base64')+(socket .gethostbyaddr (socket .gethostname ())[0 ])+'-'+OOOOOOOOOOOO0O00O ).readlines ()#line:2257
       except :pass #line:2258
def skinfix18 ():#line:2259
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:2260
		OO00O0O0O0O0OOO0O =wiz .workingURL (SKINID18DDONXML )#line:2261
		if OO00O0O0O0O0OOO0O ==True :#line:2262
			O000OO00OO0O000O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:2263
			if len (O000OO00OO0O000O0 )>0 :#line:2264
				OO00OO0000O0O0O00 ='%s-%s.zip'%(SKINID18 ,O000OO00OO0O000O0 [0 ])#line:2265
				O0000O0000OOO0OO0 =wiz .workingURL (SKIN18ZIPURL +OO00OO0000O0O0O00 )#line:2266
				if O0000O0000OOO0OO0 ==True :#line:2267
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:2268
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2269
					O0O0O0OO0OOOOOO00 =os .path .join (PACKAGES ,OO00OO0000O0O0O00 )#line:2270
					try :os .remove (O0O0O0OO0OOOOOO00 )#line:2271
					except :pass #line:2272
					downloader .download (SKIN18ZIPURL +OO00OO0000O0O0O00 ,O0O0O0OO0OOOOOO00 ,DP )#line:2273
					extract .all (O0O0O0OO0OOOOOO00 ,HOME ,DP )#line:2274
					try :#line:2275
						O00OO0O0O0O0O0OOO =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O0000OO00000O00OO =O00OO0O0O0O0O0OOO .read ();O00OO0O0O0O0O0OOO .close ()#line:2276
						O0OOO0OOOO0OO0000 =wiz .parseDOM (O0000OO00000O00OO ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:2277
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OOO0OOOO0OO0000 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:2278
					except :#line:2279
						pass #line:2280
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:2281
					DP .close ()#line:2282
					xbmc .sleep (500 )#line:2283
					wiz .forceUpdate (True )#line:2284
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:2285
				else :#line:2286
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:2287
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0000O0000OOO0OO0 ,xbmc .LOGERROR )#line:2288
			else :#line:2289
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:2290
		else :#line:2291
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:2292
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:2293
def skinfix17 ():#line:2294
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:2295
		O000000O00O00O0O0 =wiz .workingURL (SKINID17DDONXML )#line:2296
		if O000000O00O00O0O0 ==True :#line:2297
			OO00OOOO0000O0000 =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:2298
			if len (OO00OOOO0000O0000 )>0 :#line:2299
				OOOO0OOO0O0O0O000 ='%s-%s.zip'%(SKINID17 ,OO00OOOO0000O0000 [0 ])#line:2300
				O0OOOO0O0OOO0O0OO =wiz .workingURL (SKIN17ZIPURL +OOOO0OOO0O0O0O000 )#line:2301
				if O0OOOO0O0OOO0O0OO ==True :#line:2302
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:2303
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2304
					OOOOOO00000O00OOO =os .path .join (PACKAGES ,OOOO0OOO0O0O0O000 )#line:2305
					try :os .remove (OOOOOO00000O00OOO )#line:2306
					except :pass #line:2307
					downloader .download (SKIN17ZIPURL +OOOO0OOO0O0O0O000 ,OOOOOO00000O00OOO ,DP )#line:2308
					extract .all (OOOOOO00000O00OOO ,HOME ,DP )#line:2309
					try :#line:2310
						O0O0OOO0O0O0000O0 =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00OOO00O0OOO0OO0 =O0O0OOO0O0O0000O0 .read ();O0O0OOO0O0O0000O0 .close ()#line:2311
						O0O000OOO000OO0O0 =wiz .parseDOM (O00OOO00O0OOO0OO0 ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:2312
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000OOO000OO0O0 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:2313
					except :#line:2314
						pass #line:2315
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:2316
					DP .close ()#line:2317
					xbmc .sleep (500 )#line:2318
					wiz .forceUpdate (True )#line:2319
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:2320
				else :#line:2321
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:2322
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0OOOO0O0OOO0O0OO ,xbmc .LOGERROR )#line:2323
			else :#line:2324
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:2325
		else :#line:2326
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:2327
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:2328
def fix17update ():#line:2329
	if KODIV >=17 and KODIV <18 :#line:2330
		wiz .kodi17Fix ()#line:2331
		xbmc .sleep (4000 )#line:2332
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:2333
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:2334
		fixfont ()#line:2335
		O0OOO0000O0000O00 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:2336
		try :#line:2338
			OOO0OOOO00OO0O00O =open (O0OOO0000O0000O00 ,'r')#line:2339
			OOOO0O0000O0OO00O =OOO0OOOO00OO0O00O .read ()#line:2340
			OOO0OOOO00OO0O00O .close ()#line:2341
			O00000OO0O00O00O0 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:2342
			OO0O0O000O00O00OO =re .compile (O00000OO0O00O00O0 ).findall (OOOO0O0000O0OO00O )[0 ]#line:2343
			OOO0OOOO00OO0O00O =open (O0OOO0000O0000O00 ,'w')#line:2344
			OOO0OOOO00OO0O00O .write (OOOO0O0000O0OO00O .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%OO0O0O000O00O00OO ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:2345
			OOO0OOOO00OO0O00O .close ()#line:2346
		except :#line:2347
				pass #line:2348
		wiz .kodi17Fix ()#line:2349
		O0OOO0000O0000O00 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:2350
		try :#line:2351
			OOO0OOOO00OO0O00O =open (O0OOO0000O0000O00 ,'r')#line:2352
			OOOO0O0000O0OO00O =OOO0OOOO00OO0O00O .read ()#line:2353
			OOO0OOOO00OO0O00O .close ()#line:2354
			O00000OO0O00O00O0 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:2355
			OO0O0O000O00O00OO =re .compile (O00000OO0O00O00O0 ).findall (OOOO0O0000O0OO00O )[0 ]#line:2356
			OOO0OOOO00OO0O00O =open (O0OOO0000O0000O00 ,'w')#line:2357
			OOO0OOOO00OO0O00O .write (OOOO0O0000O0OO00O .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%OO0O0O000O00O00OO ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:2358
			OOO0OOOO00OO0O00O .close ()#line:2359
		except :#line:2360
				pass #line:2361
		swapSkins ('skin.Premium.mod')#line:2362
def fix18update ():#line:2364
	if KODIV >=18 :#line:2365
		xbmc .sleep (4000 )#line:2366
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:2367
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:2368
		fixfont ()#line:2369
		OO00000OO000O000O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:2370
		try :#line:2371
			O0OOO00O0OOO0O000 =open (OO00000OO000O000O ,'r')#line:2372
			OO0OO00O0O000000O =O0OOO00O0OOO0O000 .read ()#line:2373
			O0OOO00O0OOO0O000 .close ()#line:2374
			O00000OOO0OO0O000 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:2375
			O0O0OO0OO00OOOOO0 =re .compile (O00000OOO0OO0O000 ).findall (OO0OO00O0O000000O )[0 ]#line:2376
			O0OOO00O0OOO0O000 =open (OO00000OO000O000O ,'w')#line:2377
			O0OOO00O0OOO0O000 .write (OO0OO00O0O000000O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O0O0OO0OO00OOOOO0 ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:2378
			O0OOO00O0OOO0O000 .close ()#line:2379
		except :#line:2380
				pass #line:2381
		wiz .kodi17Fix ()#line:2382
		OO00000OO000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:2383
		try :#line:2384
			O0OOO00O0OOO0O000 =open (OO00000OO000O000O ,'r')#line:2385
			OO0OO00O0O000000O =O0OOO00O0OOO0O000 .read ()#line:2386
			O0OOO00O0OOO0O000 .close ()#line:2387
			O00000OOO0OO0O000 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:2388
			O0O0OO0OO00OOOOO0 =re .compile (O00000OOO0OO0O000 ).findall (OO0OO00O0O000000O )[0 ]#line:2389
			O0OOO00O0OOO0O000 =open (OO00000OO000O000O ,'w')#line:2390
			O0OOO00O0OOO0O000 .write (OO0OO00O0O000000O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O0O0OO0OO00OOOOO0 ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:2391
			O0OOO00O0OOO0O000 .close ()#line:2392
		except :#line:2393
				pass #line:2394
		swapSkins ('skin.Premium.mod')#line:2395
def buildWizard (O000O00O0000O00OO ,O000O00OO0000O000 ,theme =None ,over =False ):#line:2398
	if over ==False :#line:2399
		O00O0O000O0OO0OOO =wiz .checkBuild (O000O00O0000O00OO ,'url')#line:2400
		if O00O0O000O0OO0OOO ==False :#line:2402
			O00O0O00O00000O0O ="[COLOR %s]בעיה בעדכון המהיר - באפשרותכם לעשות עדכון מהיר ידני בכפתור למטה או להתקין את הבילד מחדש.[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O000O00O0000O00OO )#line:2403
			wiz .ForceFastUpDate (ADDONTITLE ,O00O0O00O00000O0O )#line:2404
			return #line:2405
		O0OO0O00000O0OOO0 =wiz .workingURL (O00O0O000O0OO0OOO )#line:2406
		if O0OO0O00000O0OOO0 ==False :#line:2407
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,O0OO0O00000O0OOO0 ))#line:2408
			return #line:2409
	if O000O00OO0000O000 =='gui':#line:2410
		if O000O00O0000O00OO ==BUILDNAME :#line:2411
			if over ==True :OO0OO000OOO00OOOO =1 #line:2412
			else :OO0OO000OOO00OOOO =1 #line:2413
		else :#line:2414
			OO0OO000OOO00OOOO =1 #line:2415
		if OO0OO000OOO00OOOO :#line:2416
			remove_addons ()#line:2417
			remove_addons2 ()#line:2418
			O0OO00O0OOO00OO0O =wiz .checkBuild (O000O00O0000O00OO ,'gui')#line:2419
			O00OO0OO00OOOOOOO =O000O00O0000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2420
			if not wiz .workingURL (O0OO00O0OOO00OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:2421
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2422
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0000O00OO ),'','אנא המתן')#line:2423
			OO0O00O0OOO0OOOO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%O00OO0OO00OOOOOOO )#line:2424
			try :os .remove (OO0O00O0OOO0OOOO0 )#line:2425
			except :pass #line:2426
			logging .warning (O0OO00O0OOO00OO0O )#line:2427
			if 'google'in O0OO00O0OOO00OO0O :#line:2428
			   O0O0000O00O000O00 =googledrive_download (O0OO00O0OOO00OO0O ,OO0O00O0OOO0OOOO0 ,DP ,wiz .checkBuild (O000O00O0000O00OO ,'filesize'))#line:2429
			else :#line:2432
			  downloader .download (O0OO00O0OOO00OO0O ,OO0O00O0OOO0OOOO0 ,DP )#line:2433
			xbmc .sleep (100 )#line:2434
			OO0OOO00OOO00O0OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0000O00OO )#line:2435
			DP .update (0 ,OO0OOO00OOO00O0OO ,'','אנא המתן')#line:2436
			extract .all (OO0O00O0OOO0OOOO0 ,HOME ,DP ,title =OO0OOO00OOO00O0OO )#line:2437
			DP .close ()#line:2438
			wiz .defaultSkin ()#line:2439
			wiz .lookandFeelData ('save')#line:2440
			wiz .kodi17Fix ()#line:2441
			if INSTALLMETHOD ==1 :O0O0OO0000OO00O0O =1 #line:2443
			elif INSTALLMETHOD ==2 :O0O0OO0000OO00O0O =0 #line:2444
			else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]עדכון מהיר עבר בהצלחה, הקודי ייסגר כעת.[/COLOR]"%COLOR2 );wiz .killxbmc ()#line:2446
		else :#line:2447
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:2448
	elif O000O00OO0000O000 =='fresh':#line:2449
		freshStart (O000O00O0000O00OO )#line:2450
	elif O000O00OO0000O000 =='normal':#line:2451
		if url =='normal':#line:2452
			if KEEPTRAKT =='true':#line:2453
				traktit .autoUpdate ('all')#line:2454
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:2455
			if KEEPREAL =='true':#line:2456
				debridit .autoUpdate ('all')#line:2457
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:2458
			if KEEPLOGIN =='true':#line:2459
				loginit .autoUpdate ('all')#line:2460
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:2461
		O0OOO00O000O00O0O =int (KODIV );O00O000OO00O00O0O =int (float (wiz .checkBuild (O000O00O0000O00OO ,'kodi')))#line:2462
		if not O0OOO00O000O00O0O ==O00O000OO00O00O0O :#line:2463
			if O0OOO00O000O00O0O ==16 and O00O000OO00O00O0O <=15 :OOO000000OO0O0OO0 =False #line:2464
			else :OOO000000OO0O0OO0 =True #line:2465
		else :OOO000000OO0O0OO0 =False #line:2466
		if OOO000000OO0O0OO0 ==True :#line:2467
			O0O0O0O00000000OO =1 #line:2468
		else :#line:2469
			if not over ==False :O0O0O0O00000000OO =1 #line:2470
			else :O0O0O0O00000000OO =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:2471
		if O0O0O0O00000000OO :#line:2472
			wiz .clearS ('build')#line:2473
			O0OO00O0OOO00OO0O =wiz .checkBuild (O000O00O0000O00OO ,'url')#line:2474
			O00OO0OO00OOOOOOO =O000O00O0000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2475
			if not wiz .workingURL (O0OO00O0OOO00OO0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:2476
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2477
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0000O00OO ,wiz .checkBuild (O000O00O0000O00OO ,'version')),'','אנא המתן')#line:2478
			OO0O00O0OOO0OOOO0 =os .path .join (PACKAGES ,'%s.zip'%O00OO0OO00OOOOOOO )#line:2479
			try :os .remove (OO0O00O0OOO0OOOO0 )#line:2480
			except :pass #line:2481
			logging .warning (O0OO00O0OOO00OO0O )#line:2482
			if 'google'in O0OO00O0OOO00OO0O :#line:2483
			   O0O0000O00O000O00 =googledrive_download (O0OO00O0OOO00OO0O ,OO0O00O0OOO0OOOO0 ,DP ,wiz .checkBuild (O000O00O0000O00OO ,'filesize'))#line:2484
			else :#line:2487
			  downloader .download (O0OO00O0OOO00OO0O ,OO0O00O0OOO0OOOO0 ,DP )#line:2488
			xbmc .sleep (1000 )#line:2489
			OO0OOO00OOO00O0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0000O00OO ,wiz .checkBuild (O000O00O0000O00OO ,'version'))#line:2490
			DP .update (0 ,OO0OOO00OOO00O0OO ,'','Please Wait')#line:2491
			OO00O00O00OOOO00O ,OOO000O00OO0OO00O ,O00O0O0000OO0O00O =extract .all (OO0O00O0OOO0OOOO0 ,HOME ,DP ,title =OO0OOO00OOO00O0OO )#line:2492
			if int (float (OO00O00O00OOOO00O ))>0 :#line:2493
				wiz .fixmetas ()#line:2494
				wiz .lookandFeelData ('save')#line:2495
				wiz .defaultSkin ()#line:2496
				wiz .setS ('buildname',O000O00O0000O00OO )#line:2498
				wiz .setS ('buildversion',wiz .checkBuild (O000O00O0000O00OO ,'version'))#line:2499
				wiz .setS ('buildtheme','')#line:2500
				wiz .setS ('latestversion',wiz .checkBuild (O000O00O0000O00OO ,'version'))#line:2501
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:2502
				wiz .setS ('installed','true')#line:2503
				wiz .setS ('extract',str (OO00O00O00OOOO00O ))#line:2504
				wiz .setS ('errors',str (OOO000O00OO0OO00O ))#line:2505
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00O00O00OOOO00O ,OOO000O00OO0OO00O ))#line:2506
				wiz .kodi17Fix ()#line:2507
				skin_homeselect ()#line:2508
				skinfix18 ()#line:2509
				skinfix17 ()#line:2510
				try :os .remove (OO0O00O0OOO0OOOO0 )#line:2511
				except :pass #line:2512
				if KODIV >=17 :wiz .kodi17Fix ()#line:2513
				if int (float (OOO000O00OO0OO00O ))>0 :#line:2514
					OO0OO000OOO00OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O00O0000O00OO ,wiz .checkBuild (O000O00O0000O00OO ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO00O00O00OOOO00O ,'%',COLOR1 ,OOO000O00OO0OO00O ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:2515
					if OO0OO000OOO00OOOO :#line:2516
						if isinstance (OOO000O00OO0OO00O ,unicode ):#line:2517
							O00O0O0000OO0O00O =O00O0O0000OO0O00O .encode ('utf-8')#line:2518
						wiz .TextBox (ADDONTITLE ,O00O0O0000OO0O00O )#line:2519
				DP .close ()#line:2520
				OOO000O0O0O0O000O =wiz .themeCount (O000O00O0000O00OO )#line:2521
				indicator ()#line:2522
				if not OOO000O0O0O0O000O ==False :#line:2523
					buildWizard (O000O00O0000O00OO ,'theme')#line:2524
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:2525
				if INSTALLMETHOD ==1 :O0O0OO0000OO00O0O =1 #line:2526
				elif INSTALLMETHOD ==2 :O0O0OO0000OO00O0O =0 #line:2527
				else :DIALOG .ok (ADDONTITLE ,"[COLOR %s]ההתקנה הסתיימה בהצלחה, ברוכים הבאים לקודי אנונימוס![/COLOR]"%COLOR2 );wiz .killxbmc ('true')#line:2529
				if O0O0OO0000OO00O0O ==1 :wiz .reloadFix ()#line:2530
				else :wiz .killxbmc (True )#line:2531
			else :#line:2532
				if isinstance (OOO000O00OO0OO00O ,unicode ):#line:2533
					O00O0O0000OO0O00O =O00O0O0000OO0O00O .encode ('utf-8')#line:2534
				O0O0OO0O00OO0OOOO =open (OO0O00O0OOO0OOOO0 ,'r')#line:2535
				OO00OOO00O0O0OO0O =O0O0OO0O00OO0OOOO .read ()#line:2536
				OOO000O0OOO0OO0O0 =''#line:2537
				for O0OOOOOOOO00O0OOO in O0O0000O00O000O00 :#line:2538
				  OOO000O0OOO0OO0O0 ='key: '+OOO000O0OOO0OO0O0 +'\n'+O0OOOOOOOO00O0OOO #line:2539
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,O00O0O0000OO0O00O +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+OOO000O0OOO0OO0O0 )#line:2540
		else :#line:2541
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:2542
	elif O000O00OO0000O000 =='theme':#line:2543
		if theme ==None :#line:2544
			OOO000O0O0O0O000O =wiz .checkBuild (O000O00O0000O00OO ,'theme')#line:2545
			O0OO0O000O0O0O00O =[]#line:2546
			if not OOO000O0O0O0O000O =='http://'and wiz .workingURL (OOO000O0O0O0O000O )==True :#line:2547
				O0OO0O000O0O0O00O =wiz .themeCount (O000O00O0000O00OO ,False )#line:2548
				if len (O0OO0O000O0O0O00O )>0 :#line:2549
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O000O00O0000O00OO ,COLOR1 ,len (O0OO0O000O0O0O00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:2550
						wiz .log ("Theme List: %s "%str (O0OO0O000O0O0O00O ))#line:2551
						OO0000OOOOO0OOOOO =DIALOG .select (ADDONTITLE ,O0OO0O000O0O0O00O )#line:2552
						wiz .log ("Theme install selected: %s"%OO0000OOOOO0OOOOO )#line:2553
						if not OO0000OOOOO0OOOOO ==-1 :theme =O0OO0O000O0O0O00O [OO0000OOOOO0OOOOO ];O00OOOOO0OO00OOO0 =True #line:2554
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:2555
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:2556
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:2557
		else :O00OOOOO0OO00OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O000O00O0000O00OO ,wiz .checkBuild (O000O00O0000O00OO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:2558
		if O00OOOOO0OO00OOO0 :#line:2559
			O0O00O000OO00O0O0 =wiz .checkTheme (O000O00O0000O00OO ,theme ,'url')#line:2560
			O00OO0OO00OOOOOOO =O000O00O0000O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2561
			if not wiz .workingURL (O0O00O000OO00O0O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:2562
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2563
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:2564
			OO0O00O0OOO0OOOO0 =os .path .join (PACKAGES ,'%s.zip'%O00OO0OO00OOOOOOO )#line:2565
			try :os .remove (OO0O00O0OOO0OOOO0 )#line:2566
			except :pass #line:2567
			downloader .download (O0O00O000OO00O0O0 ,OO0O00O0OOO0OOOO0 ,DP )#line:2568
			xbmc .sleep (1000 )#line:2569
			DP .update (0 ,"","Installing %s "%O000O00O0000O00OO )#line:2570
			O0000O0OO0O0O0O0O =False #line:2571
			if url not in ["fresh","normal"]:#line:2572
				O0000O0OO0O0O0O0O =testTheme (OO0O00O0OOO0OOOO0 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:2573
				OO0O0O0O0O0OOO000 =testGui (OO0O00O0OOO0OOOO0 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']else False #line:2574
				if O0000O0OO0O0O0O0O ==True :#line:2575
					wiz .lookandFeelData ('save')#line:2576
					O0OO0O0O0000OO000 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:2577
					OOOO0OO0000000000 =xbmc .getSkinDir ()#line:2578
					skinSwitch .swapSkins (O0OO0O0O0000OO000 )#line:2580
					O000OOOOOOOO0OO0O =0 #line:2581
					xbmc .sleep (1000 )#line:2582
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OOOOOOOO0OO0O <150 :#line:2583
						O000OOOOOOOO0OO0O +=1 #line:2584
						xbmc .sleep (1000 )#line:2585
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2586
						wiz .ebi ('SendClick(11)')#line:2587
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:2588
					xbmc .sleep (1000 )#line:2589
			OO0OOO00OOO00O0OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:2590
			DP .update (0 ,OO0OOO00OOO00O0OO ,'','אנא המתן')#line:2591
			OO00O00O00OOOO00O ,OOO000O00OO0OO00O ,O00O0O0000OO0O00O =extract .all (OO0O00O0OOO0OOOO0 ,HOME ,DP ,title =OO0OOO00OOO00O0OO )#line:2592
			wiz .setS ('buildtheme',theme )#line:2593
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OO00O00O00OOOO00O ,OOO000O00OO0OO00O ))#line:2594
			DP .close ()#line:2595
			if url not in ["fresh","normal"]:#line:2596
				wiz .forceUpdate ()#line:2597
				if KODIV >=17 :wiz .kodi17Fix ()#line:2598
				if OO0O0O0O0O0OOO000 ==True :#line:2599
					wiz .lookandFeelData ('save')#line:2600
					wiz .defaultSkin ()#line:2601
					OOOO0OO0000000000 =wiz .getS ('defaultskin')#line:2602
					skinSwitch .swapSkins (OOOO0OO0000000000 )#line:2603
					O000OOOOOOOO0OO0O =0 #line:2604
					xbmc .sleep (1000 )#line:2605
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OOOOOOOO0OO0O <150 :#line:2606
						O000OOOOOOOO0OO0O +=1 #line:2607
						xbmc .sleep (1000 )#line:2608
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2610
						wiz .ebi ('SendClick(11)')#line:2611
					wiz .lookandFeelData ('restore')#line:2612
				elif O0000O0OO0O0O0O0O ==True :#line:2613
					skinSwitch .swapSkins (OOOO0OO0000000000 )#line:2614
					O000OOOOOOOO0OO0O =0 #line:2615
					xbmc .sleep (1000 )#line:2616
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O000OOOOOOOO0OO0O <150 :#line:2617
						O000OOOOOOOO0OO0O +=1 #line:2618
						xbmc .sleep (1000 )#line:2619
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2621
						wiz .ebi ('SendClick(11)')#line:2622
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:2623
					wiz .lookandFeelData ('restore')#line:2624
				else :#line:2625
					wiz .ebi ("ReloadSkin()")#line:2626
					xbmc .sleep (1000 )#line:2627
					wiz .ebi ("Container.Refresh")#line:2628
		else :#line:2629
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:2630
def skin_homeselect ():#line:2634
	O0O0OO0O00OO0OOO0 =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:2635
	OO000OO00O0O00O0O =open (O0O0OO0O00OO0OOO0 ,'r')#line:2637
	OOOOO0OO0OO0OOO00 =OO000OO00O0O00O0O .read ()#line:2638
	OO000OO00O0O00O0O .close ()#line:2639
	O000O0O00OO000O00 ='<setting id="HomeS" type="string(.+?)/setting>'#line:2640
	O00OO0OOO00000O0O =re .compile (O000O0O00OO000O00 ).findall (OOOOO0OO0OO0OOO00 )[0 ]#line:2641
	OO000OO00O0O00O0O =open (O0O0OO0O00OO0OOO0 ,'w')#line:2642
	OO000OO00O0O00O0O .write (OOOOO0OO0OO0OOO00 .replace ('<setting id="HomeS" type="string%s/setting>'%O00OO0OOO00000O0O ,'<setting id="HomeS" type="string"></setting>'))#line:2643
	OO000OO00O0O00O0O .close ()#line:2644
def thirdPartyInstall (O00000O000OO0000O ,OOOO0O0O00O00O000 ):#line:2649
	if not wiz .workingURL (OOOO0O0O00O00O000 ):#line:2650
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:2651
	O0OO000OO0O0O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00000O000OO0000O ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:2652
	if O0OO000OO0O0O00O0 ==1 :#line:2653
		freshStart ('third',True )#line:2654
	wiz .clearS ('build')#line:2655
	OO0OOOOO000000000 =O00000O000OO0000O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2656
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2657
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O000OO0000O ),'','אנא המתן')#line:2658
	O0OOO00OO00OOO0O0 =os .path .join (PACKAGES ,'%s.zip'%OO0OOOOO000000000 )#line:2659
	try :os .remove (O0OOO00OO00OOO0O0 )#line:2660
	except :pass #line:2661
	downloader .download (OOOO0O0O00O00O000 ,O0OOO00OO00OOO0O0 ,DP )#line:2662
	xbmc .sleep (1000 )#line:2663
	O0O00OOOO00O00O0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O000OO0000O )#line:2664
	DP .update (0 ,O0O00OOOO00O00O0O ,'','אנא המתן')#line:2665
	OO0000O000O000O00 ,O000O00OO0O00OOO0 ,OOO0OOOOO0O0OO0O0 =extract .all (O0OOO00OO00OOO0O0 ,HOME ,DP ,title =O0O00OOOO00O00O0O )#line:2666
	if int (float (OO0000O000O000O00 ))>0 :#line:2667
		wiz .fixmetas ()#line:2668
		wiz .lookandFeelData ('save')#line:2669
		wiz .defaultSkin ()#line:2670
		wiz .setS ('installed','true')#line:2672
		wiz .setS ('extract',str (OO0000O000O000O00 ))#line:2673
		wiz .setS ('errors',str (O000O00OO0O00OOO0 ))#line:2674
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO0000O000O000O00 ,O000O00OO0O00OOO0 ))#line:2675
		try :os .remove (O0OOO00OO00OOO0O0 )#line:2676
		except :pass #line:2677
		if int (float (O000O00OO0O00OOO0 ))>0 :#line:2678
			O00OO00OO0OOO0O00 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00000O000OO0000O ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OO0000O000O000O00 ,'%',COLOR1 ,O000O00OO0O00OOO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:2679
			if O00OO00OO0OOO0O00 :#line:2680
				if isinstance (O000O00OO0O00OOO0 ,unicode ):#line:2681
					OOO0OOOOO0O0OO0O0 =OOO0OOOOO0O0OO0O0 .encode ('utf-8')#line:2682
				wiz .TextBox (ADDONTITLE ,OOO0OOOOO0O0OO0O0 )#line:2683
	DP .close ()#line:2684
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:2685
	if INSTALLMETHOD ==1 :O0O0000O000OOO000 =1 #line:2686
	elif INSTALLMETHOD ==2 :O0O0000O000OOO000 =0 #line:2687
	else :O0O0000O000OOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:2688
	if O0O0000O000OOO000 ==1 :wiz .reloadFix ()#line:2689
	else :wiz .killxbmc (True )#line:2690
def testTheme (O00O0OO0O0OO0O00O ):#line:2692
	O00OO0000OOOO00OO =zipfile .ZipFile (O00O0OO0O0OO0O00O )#line:2693
	for O0O0O0OOOO0000O00 in O00OO0000OOOO00OO .infolist ():#line:2694
		if '/settings.xml'in O0O0O0OOOO0000O00 .filename :#line:2695
			return True #line:2696
	return False #line:2697
def testGui (O00O00OO0O00000O0 ):#line:2699
	OOO00OOO0000OOO00 =zipfile .ZipFile (O00O00OO0O00000O0 )#line:2700
	for O0O0OO000OO0OOO0O in OOO00OOO0000OOO00 .infolist ():#line:2701
		if '/guisettings.xml'in O0O0OO000OO0OOO0O .filename :#line:2702
			return True #line:2703
	return False #line:2704
def apkInstaller (OOOOOOOOOO0O0OO0O ,OOOO0O0OOOO0O00O0 ):#line:2706
	wiz .log (OOOOOOOOOO0O0OO0O )#line:2707
	wiz .log (OOOO0O0OOOO0O00O0 )#line:2708
	if wiz .platform ()=='android':#line:2709
		O00O00OOOOOO000OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOOOOO0O0OO0O ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2710
		if not O00O00OOOOOO000OO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:2711
		O0O0O0O0OOOO000O0 =OOOOOOOOOO0O0OO0O #line:2712
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2713
		if not wiz .workingURL (OOOO0O0OOOO0O00O0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:2714
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0O0O0OOOO000O0 ),'','אנא המתן')#line:2715
		O0OOO0O00O0O0O0OO =os .path .join (PACKAGES ,"%s.apk"%OOOOOOOOOO0O0OO0O .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:2716
		try :os .remove (O0OOO0O00O0O0O0OO )#line:2717
		except :pass #line:2718
		downloader .download (OOOO0O0OOOO0O00O0 ,O0OOO0O00O0O0O0OO ,DP )#line:2719
		xbmc .sleep (100 )#line:2720
		DP .close ()#line:2721
		notify .apkInstaller (OOOOOOOOOO0O0OO0O )#line:2722
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0OOO0O00O0O0O0OO +'")')#line:2723
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:2724
def createMenu (OO0O00O000OOO00OO ,O0O0000OOO00OO00O ,O0O00OO000O0O0OOO ):#line:2730
	if OO0O00O000OOO00OO =='saveaddon':#line:2731
		O000OO0O0O0OO0OOO =[]#line:2732
		O0OOO00OOOOO0OO0O =urllib .quote_plus (O0O0000OOO00OO00O .lower ().replace (' ',''))#line:2733
		O00OO0O0OOO0O0000 =O0O0000OOO00OO00O .replace ('Debrid','Real Debrid')#line:2734
		O0OO0O0O000OOOOOO =urllib .quote_plus (O0O00OO000O0O0OOO .lower ().replace (' ',''))#line:2735
		O0O00OO000O0O0OOO =O0O00OO000O0O0OOO .replace ('url','URL Resolver')#line:2736
		O000OO0O0O0OO0OOO .append ((THEME2 %O0O00OO000O0O0OOO .title (),' '))#line:2737
		O000OO0O0O0OO0OOO .append ((THEME3 %'Save %s Data'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2738
		O000OO0O0O0OO0OOO .append ((THEME3 %'Restore %s Data'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2739
		O000OO0O0O0OO0OOO .append ((THEME3 %'Clear %s Data'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2740
	elif OO0O00O000OOO00OO =='save':#line:2741
		O000OO0O0O0OO0OOO =[]#line:2742
		O0OOO00OOOOO0OO0O =urllib .quote_plus (O0O0000OOO00OO00O .lower ().replace (' ',''))#line:2743
		O00OO0O0OOO0O0000 =O0O0000OOO00OO00O .replace ('Debrid','Real Debrid')#line:2744
		O0OO0O0O000OOOOOO =urllib .quote_plus (O0O00OO000O0O0OOO .lower ().replace (' ',''))#line:2745
		O0O00OO000O0O0OOO =O0O00OO000O0O0OOO .replace ('url','URL Resolver')#line:2746
		O000OO0O0O0OO0OOO .append ((THEME2 %O0O00OO000O0O0OOO .title (),' '))#line:2747
		O000OO0O0O0OO0OOO .append ((THEME3 %'Register %s'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2748
		O000OO0O0O0OO0OOO .append ((THEME3 %'Save %s Data'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2749
		O000OO0O0O0OO0OOO .append ((THEME3 %'Restore %s Data'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2750
		O000OO0O0O0OO0OOO .append ((THEME3 %'Import %s Data'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2751
		O000OO0O0O0OO0OOO .append ((THEME3 %'Clear Addon %s Data'%O00OO0O0OOO0O0000 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O0OOO00OOOOO0OO0O ,O0OO0O0O000OOOOOO )))#line:2752
	elif OO0O00O000OOO00OO =='install':#line:2753
		O000OO0O0O0OO0OOO =[]#line:2754
		O0OO0O0O000OOOOOO =urllib .quote_plus (O0O00OO000O0O0OOO )#line:2755
		O000OO0O0O0OO0OOO .append ((THEME2 %O0O00OO000O0O0OOO ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O0OO0O0O000OOOOOO )))#line:2756
		O000OO0O0O0OO0OOO .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O0OO0O0O000OOOOOO )))#line:2757
		O000OO0O0O0OO0OOO .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O0OO0O0O000OOOOOO )))#line:2758
		O000OO0O0O0OO0OOO .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O0OO0O0O000OOOOOO )))#line:2759
		O000OO0O0O0OO0OOO .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O0OO0O0O000OOOOOO )))#line:2760
	O000OO0O0O0OO0OOO .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:2761
	return O000OO0O0O0OO0OOO #line:2762
def toggleCache (O0OOO0O00OO00O0O0 ):#line:2764
	OOOOO0O00OO0O0000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:2765
	O0OO0O0OOO0O0OOOO =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:2766
	if O0OOO0O00OO00O0O0 in ['true','false']:#line:2767
		for O00OO00OOOO00000O in OOOOO0O00OO0O0000 :#line:2768
			wiz .setS (O00OO00OOOO00000O ,O0OOO0O00OO00O0O0 )#line:2769
	else :#line:2770
		if not O0OOO0O00OO00O0O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:2771
			try :#line:2772
				O00OO00OOOO00000O =O0OO0O0OOO0O0OOOO [OOOOO0O00OO0O0000 .index (O0OOO0O00OO00O0O0 )]#line:2773
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O00OO00OOOO00000O ))#line:2774
			except :#line:2775
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0OOO0O00OO00O0O0 ))#line:2776
		else :#line:2777
			O0O0000OOOO00OOOO ='true'if wiz .getS (O0OOO0O00OO00O0O0 )=='false'else 'false'#line:2778
			wiz .setS (O0OOO0O00OO00O0O0 ,O0O0000OOOO00OOOO )#line:2779
def playVideo (OO0OOO000OOOOOO0O ):#line:2781
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%OO0OOO000OOOOOO0O )#line:2782
	if 'watch?v='in OO0OOO000OOOOOO0O :#line:2783
		OO00000OOOOO0O0O0 ,O0OO0000000000OOO =OO0OOO000OOOOOO0O .split ('?')#line:2784
		O00O0O0OO0OOOO000 =O0OO0000000000OOO .split ('&')#line:2785
		for O0O0OO0O0000O000O in O00O0O0OO0OOOO000 :#line:2786
			if O0O0OO0O0000O000O .startswith ('v='):#line:2787
				OO0OOO000OOOOOO0O =O0O0OO0O0000O000O [2 :]#line:2788
				break #line:2789
			else :continue #line:2790
	elif 'embed'in OO0OOO000OOOOOO0O or 'youtu.be'in OO0OOO000OOOOOO0O :#line:2791
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%OO0OOO000OOOOOO0O )#line:2792
		OO00000OOOOO0O0O0 =OO0OOO000OOOOOO0O .split ('/')#line:2793
		if len (OO00000OOOOO0O0O0 [-1 ])>5 :#line:2794
			OO0OOO000OOOOOO0O =OO00000OOOOO0O0O0 [-1 ]#line:2795
		elif len (OO00000OOOOO0O0O0 [-2 ])>5 :#line:2796
			OO0OOO000OOOOOO0O =OO00000OOOOO0O0O0 [-2 ]#line:2797
	wiz .log ("YouTube URL: %s"%OO0OOO000OOOOOO0O )#line:2798
	yt .PlayVideo (OO0OOO000OOOOOO0O )#line:2799
def viewLogFile ():#line:2801
	O0O00O00O0O0O0O00 =wiz .Grab_Log (True )#line:2802
	OO0000000O0000OO0 =wiz .Grab_Log (True ,True )#line:2803
	O0000OO0O000000O0 =0 ;OOO00O0000O0OO000 =O0O00O00O0O0O0O00 #line:2804
	if not OO0000000O0000OO0 ==False and not O0O00O00O0O0O0O00 ==False :#line:2805
		O0000OO0O000000O0 =DIALOG .select (ADDONTITLE ,["View %s"%O0O00O00O0O0O0O00 .replace (LOG ,""),"View %s"%OO0000000O0000OO0 .replace (LOG ,"")])#line:2806
		if O0000OO0O000000O0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:2807
	elif O0O00O00O0O0O0O00 ==False and OO0000000O0000OO0 ==False :#line:2808
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:2809
		return #line:2810
	elif not O0O00O00O0O0O0O00 ==False :O0000OO0O000000O0 =0 #line:2811
	elif not OO0000000O0000OO0 ==False :O0000OO0O000000O0 =1 #line:2812
	OOO00O0000O0OO000 =O0O00O00O0O0O0O00 if O0000OO0O000000O0 ==0 else OO0000000O0000OO0 #line:2814
	OOOOOO00000O0O000 =wiz .Grab_Log (False )if O0000OO0O000000O0 ==0 else wiz .Grab_Log (False ,True )#line:2815
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OOO00O0000O0OO000 ),OOOOOO00000O0O000 )#line:2817
def errorChecking (log =None ,count =None ,all =None ):#line:2819
	if log ==None :#line:2820
		O00OO0O00O000OOOO =wiz .Grab_Log (True )#line:2821
		OOO0OOO0OO00OO000 =wiz .Grab_Log (True ,True )#line:2822
		if not OOO0OOO0OO00OO000 ==False and not O00OO0O00O000OOOO ==False :#line:2823
			O0O0OOO0O0O0OOO00 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O00OO0O00O000OOOO .replace (LOG ,""),errorChecking (O00OO0O00O000OOOO ,True ,True )),"View %s: %s error(s)"%(OOO0OOO0OO00OO000 .replace (LOG ,""),errorChecking (OOO0OOO0OO00OO000 ,True ,True ))])#line:2824
			if O0O0OOO0O0O0OOO00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:2825
		elif O00OO0O00O000OOOO ==False and OOO0OOO0OO00OO000 ==False :#line:2826
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:2827
			return #line:2828
		elif not O00OO0O00O000OOOO ==False :O0O0OOO0O0O0OOO00 =0 #line:2829
		elif not OOO0OOO0OO00OO000 ==False :O0O0OOO0O0O0OOO00 =1 #line:2830
		log =O00OO0O00O000OOOO if O0O0OOO0O0O0OOO00 ==0 else OOO0OOO0OO00OO000 #line:2831
	if log ==False :#line:2832
		if count ==None :#line:2833
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:2834
			return False #line:2835
		else :#line:2836
			return 0 #line:2837
	else :#line:2838
		if os .path .exists (log ):#line:2839
			O00O0000OO0000O00 =open (log ,mode ='r');OOOOOO0OOO0O00000 =O00O0000OO0000O00 .read ().replace ('\n','').replace ('\r','');O00O0000OO0000O00 .close ()#line:2840
			OOO00O00000O0OO0O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOOOOO0OOO0O00000 )#line:2841
			if not count ==None :#line:2842
				if all ==None :#line:2843
					O0OO0OO0OOOO00OO0 =0 #line:2844
					for O000OO0O0OOOOOOOO in OOO00O00000O0OO0O :#line:2845
						if ADDON_ID in O000OO0O0OOOOOOOO :O0OO0OO0OOOO00OO0 +=1 #line:2846
					return O0OO0OO0OOOO00OO0 #line:2847
				else :return len (OOO00O00000O0OO0O )#line:2848
			if len (OOO00O00000O0OO0O )>0 :#line:2849
				O0OO0OO0OOOO00OO0 =0 ;OOO0OOOOOO0O00000 =""#line:2850
				for O000OO0O0OOOOOOOO in OOO00O00000O0OO0O :#line:2851
					if all ==None and not ADDON_ID in O000OO0O0OOOOOOOO :continue #line:2852
					else :#line:2853
						O0OO0OO0OOOO00OO0 +=1 #line:2854
						OOO0OOOOOO0O00000 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O0OO0OO0OOOO00OO0 ,O000OO0O0OOOOOOOO .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:2855
				if O0OO0OO0OOOO00OO0 >0 :#line:2856
					wiz .TextBox (ADDONTITLE ,OOO0OOOOOO0O00000 )#line:2857
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:2858
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:2859
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:2860
ACTION_PREVIOUS_MENU =10 #line:2862
ACTION_NAV_BACK =92 #line:2863
ACTION_MOVE_LEFT =1 #line:2864
ACTION_MOVE_RIGHT =2 #line:2865
ACTION_MOVE_UP =3 #line:2866
ACTION_MOVE_DOWN =4 #line:2867
ACTION_MOUSE_WHEEL_UP =104 #line:2868
ACTION_MOUSE_WHEEL_DOWN =105 #line:2869
ACTION_MOVE_MOUSE =107 #line:2870
ACTION_SELECT_ITEM =7 #line:2871
ACTION_BACKSPACE =110 #line:2872
ACTION_MOUSE_LEFT_CLICK =100 #line:2873
ACTION_MOUSE_LONG_CLICK =108 #line:2874
def LogViewer (default =None ):#line:2876
	class OOO0O0OO00OO00O0O (xbmcgui .WindowXMLDialog ):#line:2877
		def __init__ (O00000OOOO00OO00O ,*O0OOO00OO0O000OOO ,**OO000O000000O00O0 ):#line:2878
			O00000OOOO00OO00O .default =OO000O000000O00O0 ['default']#line:2879
		def onInit (OO0OO0O0OO0OO0OO0 ):#line:2881
			OO0OO0O0OO0OO0OO0 .title =101 #line:2882
			OO0OO0O0OO0OO0OO0 .msg =102 #line:2883
			OO0OO0O0OO0OO0OO0 .scrollbar =103 #line:2884
			OO0OO0O0OO0OO0OO0 .upload =201 #line:2885
			OO0OO0O0OO0OO0OO0 .kodi =202 #line:2886
			OO0OO0O0OO0OO0OO0 .kodiold =203 #line:2887
			OO0OO0O0OO0OO0OO0 .wizard =204 #line:2888
			OO0OO0O0OO0OO0OO0 .okbutton =205 #line:2889
			O000O0O0000000O0O =open (OO0OO0O0OO0OO0OO0 .default ,'r')#line:2890
			OO0OO0O0OO0OO0OO0 .logmsg =O000O0O0000000O0O .read ()#line:2891
			O000O0O0000000O0O .close ()#line:2892
			OO0OO0O0OO0OO0OO0 .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OO0O0OO0OO0OO0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:2893
			OO0OO0O0OO0OO0OO0 .showdialog ()#line:2894
		def showdialog (OO0000O0OOOO0O0O0 ):#line:2896
			OO0000O0OOOO0O0O0 .getControl (OO0000O0OOOO0O0O0 .title ).setLabel (OO0000O0OOOO0O0O0 .titlemsg )#line:2897
			OO0000O0OOOO0O0O0 .getControl (OO0000O0OOOO0O0O0 .msg ).setText (wiz .highlightText (OO0000O0OOOO0O0O0 .logmsg ))#line:2898
			OO0000O0OOOO0O0O0 .setFocusId (OO0000O0OOOO0O0O0 .scrollbar )#line:2899
		def onClick (O0O000O0O0OO0O000 ,OO00O0OOO0O000000 ):#line:2901
			if OO00O0OOO0O000000 ==O0O000O0O0OO0O000 .okbutton :O0O000O0O0OO0O000 .close ()#line:2902
			elif OO00O0OOO0O000000 ==O0O000O0O0OO0O000 .upload :O0O000O0O0OO0O000 .close ();uploadLog .Main ()#line:2903
			elif OO00O0OOO0O000000 ==O0O000O0O0OO0O000 .kodi :#line:2904
				O00OOO000O0O0O000 =wiz .Grab_Log (False )#line:2905
				OOO000OO0O0OO000O =wiz .Grab_Log (True )#line:2906
				if O00OOO000O0O0O000 ==False :#line:2907
					O0O000O0O0OO0O000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2908
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .msg ).setText ("Log File Does Not Exists!")#line:2909
				else :#line:2910
					O0O000O0O0OO0O000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000OO0O0OO000O .replace (LOG ,''))#line:2911
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .title ).setLabel (O0O000O0O0OO0O000 .titlemsg )#line:2912
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .msg ).setText (wiz .highlightText (O00OOO000O0O0O000 ))#line:2913
					O0O000O0O0OO0O000 .setFocusId (O0O000O0O0OO0O000 .scrollbar )#line:2914
			elif OO00O0OOO0O000000 ==O0O000O0O0OO0O000 .kodiold :#line:2915
				O00OOO000O0O0O000 =wiz .Grab_Log (False ,True )#line:2916
				OOO000OO0O0OO000O =wiz .Grab_Log (True ,True )#line:2917
				if O00OOO000O0O0O000 ==False :#line:2918
					O0O000O0O0OO0O000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2919
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .msg ).setText ("Log File Does Not Exists!")#line:2920
				else :#line:2921
					O0O000O0O0OO0O000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000OO0O0OO000O .replace (LOG ,''))#line:2922
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .title ).setLabel (O0O000O0O0OO0O000 .titlemsg )#line:2923
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .msg ).setText (wiz .highlightText (O00OOO000O0O0O000 ))#line:2924
					O0O000O0O0OO0O000 .setFocusId (O0O000O0O0OO0O000 .scrollbar )#line:2925
			elif OO00O0OOO0O000000 ==O0O000O0O0OO0O000 .wizard :#line:2926
				O00OOO000O0O0O000 =wiz .Grab_Log (False ,False ,True )#line:2927
				OOO000OO0O0OO000O =wiz .Grab_Log (True ,False ,True )#line:2928
				if O00OOO000O0O0O000 ==False :#line:2929
					O0O000O0O0OO0O000 .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2930
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .msg ).setText ("Log File Does Not Exists!")#line:2931
				else :#line:2932
					O0O000O0O0OO0O000 .titlemsg ="%s: %s"%(ADDONTITLE ,OOO000OO0O0OO000O .replace (ADDONDATA ,''))#line:2933
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .title ).setLabel (O0O000O0O0OO0O000 .titlemsg )#line:2934
					O0O000O0O0OO0O000 .getControl (O0O000O0O0OO0O000 .msg ).setText (wiz .highlightText (O00OOO000O0O0O000 ))#line:2935
					O0O000O0O0OO0O000 .setFocusId (O0O000O0O0OO0O000 .scrollbar )#line:2936
		def onAction (O000O000O00O000O0 ,OO0OOOOOOOO0OO0O0 ):#line:2938
			if OO0OOOOOOOO0OO0O0 ==ACTION_PREVIOUS_MENU :O000O000O00O000O0 .close ()#line:2939
			elif OO0OOOOOOOO0OO0O0 ==ACTION_NAV_BACK :O000O000O00O000O0 .close ()#line:2940
	if default ==None :default =wiz .Grab_Log (True )#line:2941
	O0000O0O00OO00O0O =OOO0O0OO00OO00O0O ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:2942
	O0000O0O00OO00O0O .doModal ()#line:2943
	del O0000O0O00OO00O0O #line:2944
def removeAddon (O0O0000O0O00OO0O0 ,O0000OOO00O00O0O0 ,over =False ):#line:2946
	if not over ==False :#line:2947
		OOOOOOO0O00OOO00O =1 #line:2948
	else :#line:2949
		OOOOOOO0O00OOO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0000OOO00O00O0O0 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0O0000O0O00OO0O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:2950
	if OOOOOOO0O00OOO00O ==1 :#line:2951
		OOO000OO00OOO0O0O =os .path .join (ADDONS ,O0O0000O0O00OO0O0 )#line:2952
		wiz .log ("Removing Addon %s"%O0O0000O0O00OO0O0 )#line:2953
		wiz .cleanHouse (OOO000OO00OOO0O0O )#line:2954
		xbmc .sleep (1000 )#line:2955
		try :shutil .rmtree (OOO000OO00OOO0O0O )#line:2956
		except Exception as O00O0O0O00O00OO0O :wiz .log ("Error removing %s"%O0O0000O0O00OO0O0 ,xbmc .LOGNOTICE )#line:2957
		removeAddonData (O0O0000O0O00OO0O0 ,O0000OOO00O00O0O0 ,over )#line:2958
	if over ==False :#line:2959
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,O0000OOO00O00O0O0 ))#line:2960
def removeAddonData (O000O0O0O00O0OOO0 ,name =None ,over =False ):#line:2962
	if O000O0O0O00O0OOO0 =='all':#line:2963
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:2964
			wiz .cleanHouse (ADDOND )#line:2965
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:2966
	elif O000O0O0O00O0OOO0 =='uninstalled':#line:2967
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:2968
			O00O0OOOOO000000O =0 #line:2969
			for O0O0OOO00O000O0O0 in glob .glob (os .path .join (ADDOND ,'*')):#line:2970
				O000O0OOOOOO0O000 =O0O0OOO00O000O0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:2971
				if O000O0OOOOOO0O000 in EXCLUDES :pass #line:2972
				elif os .path .exists (os .path .join (ADDONS ,O000O0OOOOOO0O000 )):pass #line:2973
				else :wiz .cleanHouse (O0O0OOO00O000O0O0 );O00O0OOOOO000000O +=1 ;wiz .log (O0O0OOO00O000O0O0 );shutil .rmtree (O0O0OOO00O000O0O0 )#line:2974
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0OOOOO000000O ))#line:2975
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:2976
	elif O000O0O0O00O0OOO0 =='empty':#line:2977
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:2978
			O00O0OOOOO000000O =wiz .emptyfolder (ADDOND )#line:2979
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0OOOOO000000O ))#line:2980
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:2981
	else :#line:2982
		O0O00O0O0O00OO0OO =os .path .join (USERDATA ,'addon_data',O000O0O0O00O0OOO0 )#line:2983
		if O000O0O0O00O0OOO0 in EXCLUDES :#line:2984
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:2985
		elif os .path .exists (O0O00O0O0O00OO0OO ):#line:2986
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O000O0O0O00O0OOO0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:2987
				wiz .cleanHouse (O0O00O0O0O00OO0OO )#line:2988
				try :#line:2989
					shutil .rmtree (O0O00O0O0O00OO0OO )#line:2990
				except :#line:2991
					wiz .log ("Error deleting: %s"%O0O00O0O0O00OO0OO )#line:2992
			else :#line:2993
				wiz .log ('Addon data for %s was not removed'%O000O0O0O00O0OOO0 )#line:2994
	wiz .refresh ()#line:2995
def restoreit (O000000O0OO00OO0O ):#line:2997
	if O000000O0OO00OO0O =='build':#line:2998
		OO00O0O0OO00O00O0 =freshStart ('restore')#line:2999
		if OO00O0O0OO00O00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:3000
	if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:3001
		wiz .skinToDefault ()#line:3002
	wiz .restoreLocal (O000000O0OO00OO0O )#line:3003
def restoreextit (O0OO000OO0O0OO0O0 ):#line:3005
	if O0OO000OO0O0OO0O0 =='build':#line:3006
		O00O00O00O00000O0 =freshStart ('restore')#line:3007
		if O00O00O00O00000O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:3008
	wiz .restoreExternal (O0OO000OO0O0OO0O0 )#line:3009
def buildInfo (O0OO0O00OO00OOO0O ):#line:3011
	if wiz .workingURL (SPEEDFILE )==True :#line:3012
		if wiz .checkBuild (O0OO0O00OO00OOO0O ,'url'):#line:3013
			O0OO0O00OO00OOO0O ,O00O0OOO00OO000OO ,O00OOO0OO000O0O00 ,O0000O0OOOOOOOO00 ,O00OOO000000OO0O0 ,OO00000OOO000OOO0 ,O0000O00O0000O0OO ,OO00OOO0O0OOO0O0O ,O00OO0O00OO000000 ,OO0OO0O0O0OO000OO ,O0OO0OOOOOOOOO0O0 =wiz .checkBuild (O0OO0O00OO00OOO0O ,'all')#line:3014
			OO0OO0O0O0OO000OO ='Yes'if OO0OO0O0O0OO000OO .lower ()=='yes'else 'No'#line:3015
			O0O00OO00O0O00000 ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0O00OO00OOO0O )#line:3016
			O0O00OO00O0O00000 +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00O0OOO00OO000OO )#line:3017
			if not OO00000OOO000OOO0 =="http://":#line:3018
				OO000000OOO0OOO00 =wiz .themeCount (O0OO0O00OO00OOO0O ,False )#line:3019
				O0O00OO00O0O00000 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO000000OOO0OOO00 ))#line:3020
			O0O00OO00O0O00000 +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOO000000OO0O0 )#line:3021
			O0O00OO00O0O00000 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OO0O0O0OO000OO )#line:3022
			O0O00OO00O0O00000 +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0OOOOOOOOO0O0 )#line:3023
			wiz .TextBox (ADDONTITLE ,O0O00OO00O0O00000 )#line:3024
		else :wiz .log ("Invalid Build Name!")#line:3025
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:3026
def buildVideo (OO00O000O0OOOO00O ):#line:3028
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:3029
	if wiz .workingURL (SPEEDFILE )==True :#line:3030
		O0O0OOO0O000O0OOO =wiz .checkBuild (OO00O000O0OOOO00O ,'preview')#line:3031
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OO00O000O0OOOO00O )#line:3032
		if O0O0OOO0O000O0OOO and not O0O0OOO0O000O0OOO =='http://':playVideo (O0O0OOO0O000O0OOO )#line:3033
		else :wiz .log ("[%s]Unable to find url for video preview"%OO00O000O0OOOO00O )#line:3034
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:3035
def dependsList (OO0OO000OO000OO0O ):#line:3037
	O000O000O0OOO00OO =os .path .join (ADDONS ,OO0OO000OO000OO0O ,'addon.xml')#line:3038
	if os .path .exists (O000O000O0OOO00OO ):#line:3039
		OOO00O0OO000OO000 =open (O000O000O0OOO00OO ,mode ='r');OOOO000O00OO0OOOO =OOO00O0OO000OO000 .read ();OOO00O0OO000OO000 .close ();#line:3040
		OO00O0OOOO00000O0 =wiz .parseDOM (OOOO000O00OO0OOOO ,'import',ret ='addon')#line:3041
		OO0O0O000OO0O0OO0 =[]#line:3042
		for O0OOO00000O00O000 in OO00O0OOOO00000O0 :#line:3043
			if not 'xbmc.python'in O0OOO00000O00O000 :#line:3044
				OO0O0O000OO0O0OO0 .append (O0OOO00000O00O000 )#line:3045
		return OO0O0O000OO0O0OO0 #line:3046
	return []#line:3047
def manageSaveData (O0O0OO00OOOO000OO ):#line:3049
	if O0O0OO00OOOO000OO =='import':#line:3050
		OO0000O0O000O0000 =os .path .join (ADDONDATA ,'temp')#line:3051
		if not os .path .exists (OO0000O0O000O0000 ):os .makedirs (OO0000O0O000O0000 )#line:3052
		OOO00OO0OOO0OOOOO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:3053
		if not OOO00OO0OOO0OOOOO .endswith ('.zip'):#line:3054
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:3055
			return #line:3056
		OOOOO0OO0OO0OO000 =os .path .join (MYBUILDS ,'SaveData.zip')#line:3057
		O000O0OOOOOOOO0O0 =xbmcvfs .copy (OOO00OO0OOO0OOOOO ,OOOOO0OO0OO0OO000 )#line:3058
		wiz .log ("%s"%str (O000O0OOOOOOOO0O0 ))#line:3059
		extract .all (xbmc .translatePath (OOOOO0OO0OO0OO000 ),OO0000O0O000O0000 )#line:3060
		OO0O0000OOO0OO000 =os .path .join (OO0000O0O000O0000 ,'trakt')#line:3061
		OOO0O0OOO0OO0OOO0 =os .path .join (OO0000O0O000O0000 ,'login')#line:3062
		OO0O0OO0OOO0OOO0O =os .path .join (OO0000O0O000O0000 ,'debrid')#line:3063
		OOO00O0O0OOOO000O =0 #line:3064
		if os .path .exists (OO0O0000OOO0OO000 ):#line:3065
			OOO00O0O0OOOO000O +=1 #line:3066
			O0OOO00OOO000O000 =os .listdir (OO0O0000OOO0OO000 )#line:3067
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:3068
			for OO0OO0O00000OOOOO in O0OOO00OOO000O000 :#line:3069
				O0OO00000O0O00OO0 =os .path .join (traktit .TRAKTFOLD ,OO0OO0O00000OOOOO )#line:3070
				O0OOO0O0OOOOO0OO0 =os .path .join (OO0O0000OOO0OO000 ,OO0OO0O00000OOOOO )#line:3071
				if os .path .exists (O0OO00000O0O00OO0 ):#line:3072
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0OO0O00000OOOOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:3073
					else :os .remove (O0OO00000O0O00OO0 )#line:3074
				shutil .copy (O0OOO0O0OOOOO0OO0 ,O0OO00000O0O00OO0 )#line:3075
			traktit .importlist ('all')#line:3076
			traktit .traktIt ('restore','all')#line:3077
		if os .path .exists (OOO0O0OOO0OO0OOO0 ):#line:3078
			OOO00O0O0OOOO000O +=1 #line:3079
			O0OOO00OOO000O000 =os .listdir (OOO0O0OOO0OO0OOO0 )#line:3080
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:3081
			for OO0OO0O00000OOOOO in O0OOO00OOO000O000 :#line:3082
				O0OO00000O0O00OO0 =os .path .join (loginit .LOGINFOLD ,OO0OO0O00000OOOOO )#line:3083
				O0OOO0O0OOOOO0OO0 =os .path .join (OOO0O0OOO0OO0OOO0 ,OO0OO0O00000OOOOO )#line:3084
				if os .path .exists (O0OO00000O0O00OO0 ):#line:3085
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0OO0O00000OOOOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:3086
					else :os .remove (O0OO00000O0O00OO0 )#line:3087
				shutil .copy (O0OOO0O0OOOOO0OO0 ,O0OO00000O0O00OO0 )#line:3088
			loginit .importlist ('all')#line:3089
			loginit .loginIt ('restore','all')#line:3090
		if os .path .exists (OO0O0OO0OOO0OOO0O ):#line:3091
			OOO00O0O0OOOO000O +=1 #line:3092
			O0OOO00OOO000O000 =os .listdir (OO0O0OO0OOO0OOO0O )#line:3093
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:3094
			for OO0OO0O00000OOOOO in O0OOO00OOO000O000 :#line:3095
				O0OO00000O0O00OO0 =os .path .join (debridit .REALFOLD ,OO0OO0O00000OOOOO )#line:3096
				O0OOO0O0OOOOO0OO0 =os .path .join (OO0O0OO0OOO0OOO0O ,OO0OO0O00000OOOOO )#line:3097
				if os .path .exists (O0OO00000O0O00OO0 ):#line:3098
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0OO0O00000OOOOO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:3099
					else :os .remove (O0OO00000O0O00OO0 )#line:3100
				shutil .copy (O0OOO0O0OOOOO0OO0 ,O0OO00000O0O00OO0 )#line:3101
			debridit .importlist ('all')#line:3102
			debridit .debridIt ('restore','all')#line:3103
		wiz .cleanHouse (OO0000O0O000O0000 )#line:3104
		wiz .removeFolder (OO0000O0O000O0000 )#line:3105
		os .remove (OOOOO0OO0OO0OO000 )#line:3106
		if OOO00O0O0OOOO000O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:3107
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:3108
	elif O0O0OO00OOOO000OO =='export':#line:3109
		O0OO0OO00OOOOO0O0 =xbmc .translatePath (MYBUILDS )#line:3110
		OO000OOOOOOO0OO00 =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:3111
		traktit .traktIt ('update','all')#line:3112
		loginit .loginIt ('update','all')#line:3113
		debridit .debridIt ('update','all')#line:3114
		OOO00OO0OOO0OOOOO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:3115
		OOO00OO0OOO0OOOOO =xbmc .translatePath (OOO00OO0OOO0OOOOO )#line:3116
		OO0000O0OOO00O0OO =os .path .join (O0OO0OO00OOOOO0O0 ,'SaveData.zip')#line:3117
		OOOOO00O00OO00OOO =zipfile .ZipFile (OO0000O0OOO00O0OO ,mode ='w')#line:3118
		for O00O00O000OOOOO0O in OO000OOOOOOO0OO00 :#line:3119
			if os .path .exists (O00O00O000OOOOO0O ):#line:3120
				O0OOO00OOO000O000 =os .listdir (O00O00O000OOOOO0O )#line:3121
				for OOO00OOOOOO000O0O in O0OOO00OOO000O000 :#line:3122
					OOOOO00O00OO00OOO .write (os .path .join (O00O00O000OOOOO0O ,OOO00OOOOOO000O0O ),os .path .join (O00O00O000OOOOO0O ,OOO00OOOOOO000O0O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:3123
		OOOOO00O00OO00OOO .close ()#line:3124
		if OOO00OO0OOO0OOOOO ==O0OO0OO00OOOOO0O0 :#line:3125
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0000O0OOO00O0OO ))#line:3126
		else :#line:3127
			try :#line:3128
				xbmcvfs .copy (OO0000O0OOO00O0OO ,os .path .join (OOO00OO0OOO0OOOOO ,'SaveData.zip'))#line:3129
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (OOO00OO0OOO0OOOOO ,'SaveData.zip')))#line:3130
			except :#line:3131
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0000O0OOO00O0OO ))#line:3132
def freshStart (install =None ,over =False ):#line:3137
	O0000OO0OO000OOOO =u_list (SPEEDFILE )#line:3138
	(O0000OO0OO000OOOO )#line:3139
	O0O00OOOOO0O0O00O =(wiz .workingURL (O0000OO0OO000OOOO ))#line:3140
	(O0O00OOOOO0O0O00O )#line:3141
	if KEEPTRAKT =='true':#line:3142
		traktit .autoUpdate ('all')#line:3143
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3144
	if KEEPREAL =='true':#line:3145
		debridit .autoUpdate ('all')#line:3146
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3147
	if KEEPLOGIN =='true':#line:3148
		loginit .autoUpdate ('all')#line:3149
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3150
	if over ==True :O00000OO0OOOOO000 =1 #line:3151
	elif install =='restore':O00000OO0OOOOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנה נקיה מוחקת הכל"%COLOR2 ,"נתונים ישמרו רק אם סימנתם בהגדרות","האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3152
	elif install :O00000OO0OOOOO000 =1 #line:3153
	else :O00000OO0OOOOO000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"קודי אנונימוס?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3154
	if O00000OO0OOOOO000 :#line:3155
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:3156
			OO0O000O0O0OOO00O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.anonymous.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.anonymous.nox'if KODIV <17 else 'skin.Premium.mod'#line:3157
			skinSwitch .swapSkins (OO0O000O0O0OOO00O )#line:3160
			OO0OO0O0OO000000O =0 #line:3161
			xbmc .sleep (1000 )#line:3162
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO0O0OO000000O <150 :#line:3163
				OO0OO0O0OO000000O +=1 #line:3164
				xbmc .sleep (1000 )#line:3165
				wiz .ebi ('SendAction(Select)')#line:3166
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3167
				wiz .ebi ('SendClick(11)')#line:3168
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:3169
			xbmc .sleep (1000 )#line:3170
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.anonymous.mod','skin.anonymous.nox','skin.phenomenal','skin.Premium.mod']:#line:3171
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:3172
			return #line:3173
		wiz .addonUpdates ('set')#line:3174
		O00OOOOO00OOO0000 =os .path .abspath (HOME )#line:3175
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:3176
		O0OO00OO000000OOO =sum ([len (O0O00000O0O0000OO )for O0000OOOOOO0O0000 ,OOO00O000000O00O0 ,O0O00000O0O0000OO in os .walk (O00OOOOO00OOO0000 )]);O000O00OO00O0000O =0 #line:3177
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:3178
		EXCLUDES .append ('My_Builds')#line:3179
		EXCLUDES .append ('archive_cache')#line:3180
		EXCLUDES .append ('script.module.requests')#line:3181
		if KEEPREPOS =='true':#line:3182
			O00O0OOOO0OO0O000 =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:3183
			for O0OOOOOO0O0OOO0OO in O00O0OOOO0OO0O000 :#line:3184
				O0OOOO000O00O00O0 =os .path .split (O0OOOOOO0O0OOO0OO [:-1 ])[1 ]#line:3185
				if not O0OOOO000O00O00O0 ==EXCLUDES :#line:3186
					EXCLUDES .append (O0OOOO000O00O00O0 )#line:3187
		if KEEPSUPER =='true':#line:3188
			EXCLUDES .append ('plugin.program.super.favourites')#line:3189
		if KEEPMOVIELIST =='true':#line:3190
			EXCLUDES .append ('plugin.video.metalliq')#line:3191
		if KEEPMOVIELIST =='true':#line:3192
			EXCLUDES .append ('plugin.video.anonymous.wall')#line:3193
		if KEEPADDONS =='true':#line:3194
			EXCLUDES .append ('addons')#line:3195
		if KEEPADDONS =='true':#line:3196
			EXCLUDES .append ('addon_data')#line:3197
		if KEEPREAL =='true':#line:3198
			EXCLUDES .append ('script.module.resolveurl')#line:3199
		EXCLUDES .append ('plugin.video.elementum')#line:3200
		EXCLUDES .append ('script.elementum.burst')#line:3201
		EXCLUDES .append ('script.elementum.burst-master')#line:3202
		EXCLUDES .append ('plugin.video.quasar')#line:3203
		EXCLUDES .append ('script.quasar.burst')#line:3204
		EXCLUDES .append ('skin.estuary')#line:3205
		if KEEPWHITELIST =='true':#line:3208
			O0OOO0O0O0000O000 =''#line:3209
			OO000O00O0O0OOOO0 =wiz .whiteList ('read')#line:3210
			if len (OO000O00O0O0OOOO0 )>0 :#line:3211
				for O0OOOOOO0O0OOO0OO in OO000O00O0O0OOOO0 :#line:3212
					try :OOO000000O0OOO0O0 ,OOOOOOO00O0O0O0OO ,OO0O00OO0O0OO0OO0 =O0OOOOOO0O0OOO0OO #line:3213
					except :pass #line:3214
					if OO0O00OO0O0OO0OO0 .startswith ('pvr'):O0OOO0O0O0000O000 =OOOOOOO00O0O0O0OO #line:3215
					O00O000OOOO00000O =dependsList (OO0O00OO0O0OO0OO0 )#line:3216
					for O0000000O0O00O00O in O00O000OOOO00000O :#line:3217
						if not O0000000O0O00O00O in EXCLUDES :#line:3218
							EXCLUDES .append (O0000000O0O00O00O )#line:3219
						OO0O0OO0OOO0O0OOO =dependsList (O0000000O0O00O00O )#line:3220
						for OO0O0OOOO0000O00O in OO0O0OO0OOO0O0OOO :#line:3221
							if not OO0O0OOOO0000O00O in EXCLUDES :#line:3222
								EXCLUDES .append (OO0O0OOOO0000O00O )#line:3223
					if not OO0O00OO0O0OO0OO0 in EXCLUDES :#line:3224
						EXCLUDES .append (OO0O00OO0O0OO0OO0 )#line:3225
				if not O0OOO0O0O0000O000 =='':wiz .setS ('pvrclient',OO0O00OO0O0OO0OO0 )#line:3226
		if wiz .getS ('pvrclient')=='':#line:3227
			for O0OOOOOO0O0OOO0OO in EXCLUDES :#line:3228
				if O0OOOOOO0O0OOO0OO .startswith ('pvr'):#line:3229
					wiz .setS ('pvrclient',O0OOOOOO0O0OOO0OO )#line:3230
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:3231
		O0OO0O00O0O00OO00 =wiz .latestDB ('Addons')#line:3232
		for OOO00O000O000OOOO ,O0OO0O00OOOOO0OO0 ,OO0O0O0OOO00000O0 in os .walk (O00OOOOO00OOO0000 ,topdown =True ):#line:3233
			O0OO0O00OOOOO0OO0 [:]=[OOOO0OO000O0O00OO for OOOO0OO000O0O00OO in O0OO0O00OOOOO0OO0 if OOOO0OO000O0O00OO not in EXCLUDES ]#line:3234
			for OOO000000O0OOO0O0 in OO0O0O0OOO00000O0 :#line:3235
				O000O00OO00O0000O +=1 #line:3236
				OO0O00OO0O0OO0OO0 =OOO00O000O000OOOO .replace ('/','\\').split ('\\')#line:3237
				OO0OO0O0OO000000O =len (OO0O00OO0O0OO0OO0 )-1 #line:3239
				if OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3240
				elif OOO000000O0OOO0O0 =='MyVideos99.db'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3241
				elif OOO000000O0OOO0O0 =='MyVideos107.db'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3242
				elif OOO000000O0OOO0O0 =='MyVideos110.db'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3243
				elif OOO000000O0OOO0O0 =='MyVideos99.db'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3244
				elif OOO000000O0OOO0O0 =='MyVideos107.db'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3245
				elif OOO000000O0OOO0O0 =='MyVideos110.db'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3246
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.anonymous.wall'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3247
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'skin.anonymous.mod'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3248
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'skin.Premium.mod'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3249
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'skin.anonymous.nox'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3250
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'skin.phenomenal'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3251
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3252
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'skin.titan'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3254
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3255
				elif OOO000000O0OOO0O0 =='sources.xml'and OO0O00OO0O0OO0OO0 [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3257
				elif OOO000000O0OOO0O0 =='quicknav.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3260
				elif OOO000000O0OOO0O0 =='x1101.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3261
				elif OOO000000O0OOO0O0 =='b-srtym-b.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3262
				elif OOO000000O0OOO0O0 =='x1102.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3263
				elif OOO000000O0OOO0O0 =='b-sdrvt-b.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3264
				elif OOO000000O0OOO0O0 =='x1112.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3265
				elif OOO000000O0OOO0O0 =='b-tlvvyzyh-b.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3266
				elif OOO000000O0OOO0O0 =='x1111.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3267
				elif OOO000000O0OOO0O0 =='b-tvknyshrly-b.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3268
				elif OOO000000O0OOO0O0 =='x1110.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3269
				elif OOO000000O0OOO0O0 =='b-yldym-b.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3270
				elif OOO000000O0OOO0O0 =='x1114.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3271
				elif OOO000000O0OOO0O0 =='b-mvzyqh-b.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3272
				elif OOO000000O0OOO0O0 =='mainmenu.DATA.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3273
				elif OOO000000O0OOO0O0 =='skin.Premium.mod.properties'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'script.skinshortcuts'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3274
				elif OOO000000O0OOO0O0 =='favourites.xml'and OO0O00OO0O0OO0OO0 [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3278
				elif OOO000000O0OOO0O0 =='guisettings.xml'and OO0O00OO0O0OO0OO0 [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3280
				elif OOO000000O0OOO0O0 =='profiles.xml'and OO0O00OO0O0OO0OO0 [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3281
				elif OOO000000O0OOO0O0 =='advancedsettings.xml'and OO0O00OO0O0OO0OO0 [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3282
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3283
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'program.apollo'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3284
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3285
				elif OOO000000O0OOO0O0 =='settings.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.gaia'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPRD2 =='true':wiz .log ("Keep Rd 2: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3286
				elif OOO000000O0OOO0O0 =='settings.xml'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.seren'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPRD2 =='true':wiz .log ("Keep Rd 2: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3287
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.elementum'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3288
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3289
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3290
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.quasar'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3292
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'program.apollo'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3293
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3294
				elif OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -2 ]=='userdata'and OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0O00OO0O0OO0OO0 [OO0OO0O0OO000000O ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3295
				elif OOO000000O0OOO0O0 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO000000O0OOO0O0 ,xbmc .LOGNOTICE )#line:3296
				elif OOO000000O0OOO0O0 .endswith ('.db'):#line:3297
					try :#line:3298
						if OOO000000O0OOO0O0 ==O0OO0O00O0O00OO00 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO000000O0OOO0O0 ,KODIV ),xbmc .LOGNOTICE )#line:3299
						else :os .remove (os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ))#line:3300
					except Exception as O0000OO00OOO0O000 :#line:3301
						if not OOO000000O0OOO0O0 .startswith ('Textures13'):#line:3302
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:3303
							wiz .log ("-> %s"%(str (O0000OO00OOO0O000 )),xbmc .LOGNOTICE )#line:3304
							wiz .purgeDb (os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ))#line:3305
				else :#line:3306
					DP .update (int (wiz .percentage (O000O00OO00O0000O ,O0OO00OO000000OOO )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO000000O0OOO0O0 ),'')#line:3307
					try :os .remove (os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ))#line:3308
					except Exception as O0000OO00OOO0O000 :#line:3309
						wiz .log ("Error removing %s"%os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),xbmc .LOGNOTICE )#line:3310
						wiz .log ("-> / %s"%(str (O0000OO00OOO0O000 )),xbmc .LOGNOTICE )#line:3311
			if DP .iscanceled ():#line:3312
				DP .close ()#line:3313
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:3314
				return False #line:3315
		for OOO00O000O000OOOO ,O0OO0O00OOOOO0OO0 ,OO0O0O0OOO00000O0 in os .walk (O00OOOOO00OOO0000 ,topdown =True ):#line:3316
			O0OO0O00OOOOO0OO0 [:]=[OOOO0000OO00OO0O0 for OOOO0000OO00OO0O0 in O0OO0O00OOOOO0OO0 if OOOO0000OO00OO0O0 not in EXCLUDES ]#line:3317
			for OOO000000O0OOO0O0 in O0OO0O00OOOOO0OO0 :#line:3318
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO000000O0OOO0O0 ),'')#line:3319
			  if OOO000000O0OOO0O0 not in ["Database","userdata","temp","addons","addon_data"]:#line:3320
			   if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPSKIN =='true'):#line:3321
			    if not (OOO000000O0OOO0O0 =='skin.titan'and KEEPSKIN3 =='true'):#line:3323
			      if not (OOO000000O0OOO0O0 =='pvr.iptvsimple'and KEEPPVR =='true'):#line:3324
			       if not (OOO000000O0OOO0O0 =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:3325
			        if not (OOO000000O0OOO0O0 =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:3326
			         if not (OOO000000O0OOO0O0 =='program.apollo'and KEEPINFO =='true'):#line:3327
			          if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:3328
			           if not (OOO000000O0OOO0O0 =='plugin.video.gaia'and KEEPRD2 =='true'):#line:3329
			            if not (OOO000000O0OOO0O0 =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:3330
			             if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:3331
			              if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:3332
			               if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:3333
			                if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:3334
			                 if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:3335
			                  if not (OOO000000O0OOO0O0 =='plugin.video.neptune'and KEEPINFO =='true'):#line:3336
			                   if not (OOO000000O0OOO0O0 =='plugin.video.youtube'and KEEPINFO =='true'):#line:3337
			                    if not (OOO000000O0OOO0O0 =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:3338
			                     if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:3339
			                      if not (OOO000000O0OOO0O0 =='plugin.video.seren'and KEEPRD2 =='true'):#line:3340
			                       if not (OOO000000O0OOO0O0 =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:3341
			                           if not (OOO000000O0OOO0O0 =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:3345
			                            if not (OOO000000O0OOO0O0 =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:3346
			                             if not (OOO000000O0OOO0O0 =='plugin.video.torrenter'and KEEPINFO =='true'):#line:3347
			                              if not (OOO000000O0OOO0O0 =='plugin.video.quasar'and KEEPINFO =='true'):#line:3348
			                               if not (OOO000000O0OOO0O0 =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:3349
			                                  shutil .rmtree (os .path .join (OOO00O000O000OOOO ,OOO000000O0OOO0O0 ),ignore_errors =True ,onerror =None )#line:3351
			if DP .iscanceled ():#line:3352
				DP .close ()#line:3353
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:3354
				return False #line:3355
		DP .close ()#line:3356
		wiz .clearS ('build')#line:3357
		if over ==True :#line:3358
			return True #line:3359
		elif install =='restore':#line:3360
			return True #line:3361
		elif install :#line:3362
			buildWizard (install ,'normal',over =True )#line:3363
		else :#line:3364
			if INSTALLMETHOD ==1 :O000O00O0O0OOO0OO =1 #line:3365
			elif INSTALLMETHOD ==2 :O000O00O0O0OOO0OO =0 #line:3366
			else :O000O00O0O0OOO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:3367
			if O000O00O0O0OOO0OO ==1 :wiz .reloadFix ('fresh')#line:3368
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3369
	else :#line:3370
		if not install =='restore':#line:3371
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:3372
			wiz .refresh ()#line:3373
def clearCache ():#line:3378
		wiz .clearCache ()#line:3379
def fixwizard ():#line:3383
		wiz .fixwizard ()#line:3384
def totalClean ():#line:3386
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to clear cache, packages and thumbnails?[/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]Cancel Process[/COLOR][/B]',yeslabel ='[B][COLOR green]Clean All[/COLOR][/B]'):#line:3387
		wiz .clearCache ()#line:3388
		wiz .clearPackages ('total')#line:3389
		clearThumb ('total')#line:3390
def clearThumb (type =None ):#line:3392
	O00O0000O0OO0O000 =wiz .latestDB ('Textures')#line:3393
	if not type ==None :O00OO00000O00O0O0 =1 #line:3394
	else :O00OO00000O00O0O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O00O0000O0OO0O000 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:3395
	if O00OO00000O00O0O0 ==1 :#line:3396
		try :wiz .removeFile (os .join (DATABASE ,O00O0000O0OO0O000 ))#line:3397
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O00O0000O0OO0O000 )#line:3398
		wiz .removeFolder (THUMBS )#line:3399
	else :wiz .log ('Clear thumbnames cancelled')#line:3401
	wiz .redoThumbs ()#line:3402
def purgeDb ():#line:3404
	OOOO00OOOO00O0OO0 =[];O0O0OOOOOOOOOOO00 =[]#line:3405
	for O00000OO000OOOOOO ,O000O0OOOOOOOOO0O ,O000O0OOO0O0O00OO in os .walk (HOME ):#line:3406
		for O0O0O00OO00O0OO0O in fnmatch .filter (O000O0OOO0O0O00OO ,'*.db'):#line:3407
			if O0O0O00OO00O0OO0O !='Thumbs.db':#line:3408
				O00O0OOOOO0O0O000 =os .path .join (O00000OO000OOOOOO ,O0O0O00OO00O0OO0O )#line:3409
				OOOO00OOOO00O0OO0 .append (O00O0OOOOO0O0O000 )#line:3410
				O0OO0OO0000OOO000 =O00O0OOOOO0O0O000 .replace ('\\','/').split ('/')#line:3411
				O0O0OOOOOOOOOOO00 .append ('(%s) %s'%(O0OO0OO0000OOO000 [len (O0OO0OO0000OOO000 )-2 ],O0OO0OO0000OOO000 [len (O0OO0OO0000OOO000 )-1 ]))#line:3412
	if KODIV >=16 :#line:3413
		O0OO0OOOOOOOO00OO =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OOOOOOOOOOO00 )#line:3414
		if O0OO0OOOOOOOO00OO ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:3415
		elif len (O0OO0OOOOOOOO00OO )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:3416
		else :#line:3417
			for OO000O0OOO00O00O0 in O0OO0OOOOOOOO00OO :wiz .purgeDb (OOOO00OOOO00O0OO0 [OO000O0OOO00O00O0 ])#line:3418
	else :#line:3419
		O0OO0OOOOOOOO00OO =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OOOOOOOOOOO00 )#line:3420
		if O0OO0OOOOOOOO00OO ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:3421
		else :wiz .purgeDb (OOOO00OOOO00O0OO0 [OO000O0OOO00O00O0 ])#line:3422
def testnotify ():#line:3427
	O0OOOOOO00O0O0OOO =wiz .workingURL (NOTIFICATION )#line:3428
	if O0OOOOOO00O0O0OOO ==True :#line:3429
		try :#line:3430
			OOOO0000OOO00OOOO ,O00O0OO000OO000O0 =wiz .splitNotify (NOTIFICATION )#line:3431
			if OOOO0000OOO00OOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:3432
			notify .notification (O00O0OO000OO000O0 ,True )#line:3433
		except Exception as OOO0O00O00O00OO0O :#line:3434
			wiz .log ("Error on Notifications Window: %s"%str (OOO0O00O00O00OO0O ),xbmc .LOGERROR )#line:3435
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:3436
def testnotify2 ():#line:3437
	OOOOOOO0OOO00O00O =wiz .workingURL (NOTIFICATION2 )#line:3438
	if OOOOOOO0OOO00O00O ==True :#line:3439
		try :#line:3440
			O0O0OOOO0O0OOOOO0 ,OOO00OOO0OOO00O00 =wiz .splitNotify (NOTIFICATION2 )#line:3441
			if O0O0OOOO0O0OOOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:3442
			notify .notification2 (OOO00OOO0OOO00O00 ,True )#line:3443
		except Exception as O000OO00OO0O0O00O :#line:3444
			wiz .log ("Error on Notifications Window: %s"%str (O000OO00OO0O0O00O ),xbmc .LOGERROR )#line:3445
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:3446
def testnotify3 ():#line:3447
	O00000O0OOOO00000 =wiz .workingURL (NOTIFICATION3 )#line:3448
	if O00000O0OOOO00000 ==True :#line:3449
		try :#line:3450
			O000OOO0OOOO000OO ,O0OOO0OOOOOO0O0OO =wiz .splitNotify (NOTIFICATION3 )#line:3451
			if O000OOO0OOOO000OO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:3452
			notify .notification3 (O0OOO0OOOOOO0O0OO ,True )#line:3453
		except Exception as O0O000000O0O00O00 :#line:3454
			wiz .log ("Error on Notifications Window: %s"%str (O0O000000O0O00O00 ),xbmc .LOGERROR )#line:3455
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:3456
def servicemanual ():#line:3457
	OO0O0O00000OOO00O =wiz .workingURL (HELPINFO )#line:3458
	if OO0O0O00000OOO00O ==True :#line:3459
		try :#line:3460
			O000O00O0O0OOO000 ,OOO0OO0O000O0OOO0 =wiz .splitNotify (HELPINFO )#line:3461
			if O000O00O0O0OOO000 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:3462
			notify .helpinfo (OOO0OO0O000O0OOO0 ,True )#line:3463
		except Exception as OOOO000O0000OOO0O :#line:3464
			wiz .log ("Error on Notifications Window: %s"%str (OOOO000O0000OOO0O ),xbmc .LOGERROR )#line:3465
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:3466
def testupdate ():#line:3468
	if BUILDNAME =="":#line:3469
		notify .updateWindow ()#line:3470
	else :#line:3471
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:3472
def testfirst ():#line:3474
	notify .firstRun ()#line:3475
def testfirstRun ():#line:3477
	notify .firstRunSettings ()#line:3478
def fastinstall ():#line:3481
	notify .firstRuninstall ()#line:3482
def addDir (OOO000OOOOO0OOOOO ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:3489
	O00OOOOOOO0O0OO00 =sys .argv [0 ]#line:3490
	if not mode ==None :O00OOOOOOO0O0OO00 +="?mode=%s"%urllib .quote_plus (mode )#line:3491
	if not name ==None :O00OOOOOOO0O0OO00 +="&name="+urllib .quote_plus (name )#line:3492
	if not url ==None :O00OOOOOOO0O0OO00 +="&url="+urllib .quote_plus (url )#line:3493
	OOOOOOO0OO0000000 =True #line:3494
	if themeit :OOO000OOOOO0OOOOO =themeit %OOO000OOOOO0OOOOO #line:3495
	O0OOOOOO0OOO000OO =xbmcgui .ListItem (OOO000OOOOO0OOOOO ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:3496
	O0OOOOOO0OOO000OO .setInfo (type ="Video",infoLabels ={"Title":OOO000OOOOO0OOOOO ,"Plot":description })#line:3497
	O0OOOOOO0OOO000OO .setProperty ("Fanart_Image",fanart )#line:3498
	if not menu ==None :O0OOOOOO0OOO000OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:3499
	OOOOOOO0OO0000000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OOOOOOO0O0OO00 ,listitem =O0OOOOOO0OOO000OO ,isFolder =True )#line:3500
	return OOOOOOO0OO0000000 #line:3501
def addFile (OO0O0O0OO0O00OO00 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:3503
	O000OOO00OO00OO0O =sys .argv [0 ]#line:3504
	if not mode ==None :O000OOO00OO00OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:3505
	if not name ==None :O000OOO00OO00OO0O +="&name="+urllib .quote_plus (name )#line:3506
	if not url ==None :O000OOO00OO00OO0O +="&url="+urllib .quote_plus (url )#line:3507
	OO0000OO0O00O00OO =True #line:3508
	if themeit :OO0O0O0OO0O00OO00 =themeit %OO0O0O0OO0O00OO00 #line:3509
	OOO00OO0000OOO0OO =xbmcgui .ListItem (OO0O0O0OO0O00OO00 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:3510
	OOO00OO0000OOO0OO .setInfo (type ="Video",infoLabels ={"Title":OO0O0O0OO0O00OO00 ,"Plot":description })#line:3511
	OOO00OO0000OOO0OO .setProperty ("Fanart_Image",fanart )#line:3512
	if not menu ==None :OOO00OO0000OOO0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:3513
	OO0000OO0O00O00OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OOO00OO00OO0O ,listitem =OOO00OO0000OOO0OO ,isFolder =False )#line:3514
	return OO0000OO0O00O00OO #line:3515
def get_params ():#line:3517
	OOOO00O0OO0O00OO0 =[]#line:3518
	O00OO00O0OO0000OO =sys .argv [2 ]#line:3519
	if len (O00OO00O0OO0000OO )>=2 :#line:3520
		OOOOOOOO0OO00OO00 =sys .argv [2 ]#line:3521
		O000OO0O0OOO0OO00 =OOOOOOOO0OO00OO00 .replace ('?','')#line:3522
		if (OOOOOOOO0OO00OO00 [len (OOOOOOOO0OO00OO00 )-1 ]=='/'):#line:3523
			OOOOOOOO0OO00OO00 =OOOOOOOO0OO00OO00 [0 :len (OOOOOOOO0OO00OO00 )-2 ]#line:3524
		O00OO0O00OOOOO0OO =O000OO0O0OOO0OO00 .split ('&')#line:3525
		OOOO00O0OO0O00OO0 ={}#line:3526
		for OO0O00OOO00000O0O in range (len (O00OO0O00OOOOO0OO )):#line:3527
			OOOO0000O00OOOO00 ={}#line:3528
			OOOO0000O00OOOO00 =O00OO0O00OOOOO0OO [OO0O00OOO00000O0O ].split ('=')#line:3529
			if (len (OOOO0000O00OOOO00 ))==2 :#line:3530
				OOOO00O0OO0O00OO0 [OOOO0000O00OOOO00 [0 ]]=OOOO0000O00OOOO00 [1 ]#line:3531
		return OOOO00O0OO0O00OO0 #line:3533
def remove_addons ():#line:3535
	try :#line:3536
			import json #line:3537
			O00OOO0OOOO0OO000 =urllib2 .urlopen (remove_url ).readlines ()#line:3538
			for OOOO0OO00OOO0O000 in O00OOO0OOOO0OO000 :#line:3539
				OO0OO0OOOO00000O0 =OOOO0OO00OOO0O000 .split (':')[1 ].strip ()#line:3541
				OO0O000000000000O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(OO0OO0OOOO00000O0 ,'false')#line:3542
				O000OOOO00O00OO0O =xbmc .executeJSONRPC (OO0O000000000000O )#line:3543
				O000OO000O0OO0O0O =json .loads (O000OOOO00O00OO0O )#line:3544
				O0O0O00000OOOO00O =os .path .join (addons_folder ,OO0OO0OOOO00000O0 )#line:3546
				if os .path .exists (O0O0O00000OOOO00O ):#line:3548
					for OO00OO0OO000OO0O0 ,OOOOOOO00OO0O0O0O ,O000O000O0OOO0OO0 in os .walk (O0O0O00000OOOO00O ):#line:3549
						for O0OO0000O0O0O00O0 in O000O000O0OOO0OO0 :#line:3550
							os .unlink (os .path .join (OO00OO0OO000OO0O0 ,O0OO0000O0O0O00O0 ))#line:3551
						for O00OOO0000O0OOO0O in OOOOOOO00OO0O0O0O :#line:3552
							shutil .rmtree (os .path .join (OO00OO0OO000OO0O0 ,O00OOO0000O0OOO0O ))#line:3553
					os .rmdir (O0O0O00000OOOO00O )#line:3554
			xbmc .executebuiltin ('Container.Refresh')#line:3556
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:3557
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3558
	except :pass #line:3559
def remove_addons2 ():#line:3560
	try :#line:3561
			import json #line:3562
			OO000OO0O0O0O0OOO =urllib2 .urlopen (remove_url2 ).readlines ()#line:3563
			for O000O0OO00O0000OO in OO000OO0O0O0O0OOO :#line:3564
				OOO0000OO0OO0OOOO =O000O0OO00O0000OO .split (':')[1 ].strip ()#line:3566
				OO00O0OOOO0OO0O0O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(OOO0000OO0OO0OOOO ,'false')#line:3567
				O0O00OO0000O00OOO =xbmc .executeJSONRPC (OO00O0OOOO0OO0O0O )#line:3568
				O0OOO000O00OO0OO0 =json .loads (O0O00OO0000O00OOO )#line:3569
				OOO00O0OO0OOOO00O =os .path .join (user_folder ,OOO0000OO0OO0OOOO )#line:3571
				if os .path .exists (OOO00O0OO0OOOO00O ):#line:3573
					for O000O0O0O0OOOOOO0 ,O00O0OO0O0O0000O0 ,OOOO0000O0O0O0000 in os .walk (OOO00O0OO0OOOO00O ):#line:3574
						for O00O00O0OO0OO0O00 in OOOO0000O0O0O0000 :#line:3575
							os .unlink (os .path .join (O000O0O0O0OOOOOO0 ,O00O00O0OO0OO0O00 ))#line:3576
						for OO0O0000O00OO000O in O00O0OO0O0O0000O0 :#line:3577
							shutil .rmtree (os .path .join (O000O0O0O0OOOOOO0 ,OO0O0000O00OO000O ))#line:3578
					os .rmdir (OOO00O0OO0OOOO00O )#line:3579
	except :pass #line:3581
params =get_params ()#line:3583
url =None #line:3584
name =None #line:3585
mode =None #line:3586
try :mode =urllib .unquote_plus (params ["mode"])#line:3588
except :pass #line:3589
try :name =urllib .unquote_plus (params ["name"])#line:3590
except :pass #line:3591
try :url =urllib .unquote_plus (params ["url"])#line:3592
except :pass #line:3593
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:3595
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:3596
def setView (O0OOOO000O0O00O0O ,OOOO0O0OOO00OOOO0 ):#line:3597
	if wiz .getS ('auto-view')=='true':#line:3598
		O0OOO0O0OOOOOO0O0 =wiz .getS (OOOO0O0OOO00OOOO0 )#line:3599
		if O0OOO0O0OOOOOO0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0OOO0O0OOOOOO0O0 ='55'#line:3600
		if O0OOO0O0OOOOOO0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0OOO0O0OOOOOO0O0 ='50'#line:3601
		wiz .ebi ("Container.SetViewMode(%s)"%O0OOO0O0OOOOOO0O0 )#line:3602
if mode ==None :index ()#line:3604
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:3606
elif mode =='builds':buildMenu ()#line:3607
elif mode =='viewbuild':viewBuild (name )#line:3608
elif mode =='buildinfo':buildInfo (name )#line:3609
elif mode =='buildpreview':buildVideo (name )#line:3610
elif mode =='install':buildWizard (name ,url )#line:3611
elif mode =='theme':buildWizard (name ,mode ,url )#line:3612
elif mode =='viewthirdparty':viewThirdList (name )#line:3613
elif mode =='installthird':thirdPartyInstall (name ,url )#line:3614
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:3615
elif mode =='maint':maintMenu (name )#line:3617
elif mode =='passpin':passandpin ()#line:3618
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:3619
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:3620
elif mode =='advancedsetting':advancedWindow (name )#line:3621
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:3622
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:3623
elif mode =='asciicheck':wiz .asciiCheck ()#line:3624
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:3625
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:3626
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:3627
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:3628
elif mode =='oldThumbs':wiz .oldThumbs ()#line:3629
elif mode =='clearbackup':wiz .cleanupBackup ()#line:3630
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:3631
elif mode =='currentsettings':viewAdvanced ()#line:3632
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:3633
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:3634
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:3635
elif mode =='fixskin':backtokodi ()#line:3636
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:3637
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:3638
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:3639
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:3640
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:3641
elif mode =='freshstart':freshStart ()#line:3642
elif mode =='forceupdate':wiz .forceUpdate ()#line:3643
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:3644
elif mode =='forceclose':wiz .killxbmc ()#line:3645
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:3646
elif mode =='hidepassword':wiz .hidePassword ()#line:3647
elif mode =='unhidepassword':wiz .unhidePassword ()#line:3648
elif mode =='enableaddons':enableAddons ()#line:3649
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:3650
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:3651
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:3652
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:3653
elif mode =='uploadlog':uploadLog .Main ()#line:3654
elif mode =='viewlog':LogViewer ()#line:3655
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:3656
elif mode =='viewerrorlog':errorChecking (all =True )#line:3657
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:3658
elif mode =='purgedb':purgeDb ()#line:3659
elif mode =='fixaddonupdate':fixUpdate ()#line:3660
elif mode =='removeaddons':removeAddonMenu ()#line:3661
elif mode =='removeaddon':removeAddon (name )#line:3662
elif mode =='removeaddondata':removeAddonDataMenu ()#line:3663
elif mode =='removedata':removeAddonData (name )#line:3664
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:3665
elif mode =='systeminfo':systemInfo ()#line:3666
elif mode =='restorezip':restoreit ('build')#line:3667
elif mode =='restoregui':restoreit ('gui')#line:3668
elif mode =='restoreaddon':restoreit ('addondata')#line:3669
elif mode =='restoreextzip':restoreextit ('build')#line:3670
elif mode =='restoreextgui':restoreextit ('gui')#line:3671
elif mode =='restoreextaddon':restoreextit ('addondata')#line:3672
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:3673
elif mode =='apk':apkMenu (name )#line:3675
elif mode =='apkscrape':apkScraper (name )#line:3676
elif mode =='apkinstall':apkInstaller (name ,url )#line:3677
elif mode =='speed':speedMenu ()#line:3678
elif mode =='net':net_tools ()#line:3679
elif mode =='GetList':GetList (url )#line:3680
elif mode =='youtube':youtubeMenu (name )#line:3681
elif mode =='viewVideo':playVideo (url )#line:3682
elif mode =='addons':addonMenu (name )#line:3684
elif mode =='addoninstall':addonInstaller (name ,url )#line:3685
elif mode =='savedata':saveMenu ()#line:3687
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:3688
elif mode =='managedata':manageSaveData (name )#line:3689
elif mode =='whitelist':wiz .whiteList (name )#line:3690
elif mode =='trakt':traktMenu ()#line:3692
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:3693
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:3694
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:3695
elif mode =='cleartrakt':traktit .clearSaved (name )#line:3696
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:3697
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:3698
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:3699
elif mode =='realdebrid':realMenu ()#line:3701
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:3702
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:3703
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:3704
elif mode =='cleardebrid':debridit .clearSaved (name )#line:3705
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:3706
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:3707
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:3708
elif mode =='login':loginMenu ()#line:3710
elif mode =='savelogin':loginit .loginIt ('update',name )#line:3711
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:3712
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:3713
elif mode =='clearlogin':loginit .clearSaved (name )#line:3714
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:3715
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:3716
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:3717
elif mode =='contact':notify .contact (CONTACT )#line:3719
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:3720
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:3721
elif mode =='developer':developer ()#line:3723
elif mode =='converttext':wiz .convertText ()#line:3724
elif mode =='createqr':wiz .createQR ()#line:3725
elif mode =='testnotify':testnotify ()#line:3726
elif mode =='testnotify2':testnotify2 ()#line:3727
elif mode =='servicemanual':servicemanual ()#line:3728
elif mode =='fastinstall':fastinstall ()#line:3729
elif mode =='testupdate':testupdate ()#line:3730
elif mode =='testfirst':testfirst ()#line:3731
elif mode =='testfirstrun':testfirstRun ()#line:3732
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:3733
elif mode =='bg':wiz .bg_install (name ,url )#line:3735
elif mode =='bgcustom':wiz .bg_custom ()#line:3736
elif mode =='bgremove':wiz .bg_remove ()#line:3737
elif mode =='bgdefault':wiz .bg_default ()#line:3738
elif mode =='rdset':rdsetup ()#line:3739
elif mode =='mor':morsetup ()#line:3740
elif mode =='mor2':morsetup2 ()#line:3741
elif mode =='resolveurl':resolveurlsetup ()#line:3742
elif mode =='urlresolver':urlresolversetup ()#line:3743
elif mode =='forcefastupdate':forcefastupdate ()#line:3744
elif mode =='traktset':traktsetup ()#line:3745
elif mode =='placentaset':placentasetup ()#line:3746
elif mode =='flixnetset':flixnetsetup ()#line:3747
elif mode =='reptiliaset':reptiliasetup ()#line:3748
elif mode =='yodasset':yodasetup ()#line:3749
elif mode =='numbersset':numberssetup ()#line:3750
elif mode =='uranusset':uranussetup ()#line:3751
elif mode =='genesisset':genesissetup ()#line:3752
elif mode =='fastupdate':fastupdate ()#line:3753
elif mode ==2 :#line:3754
        wiz .torent_menu ()#line:3755
elif mode ==3 :#line:3756
        wiz .popcorn_menu ()#line:3757
elif mode ==8 :#line:3758
        wiz .metaliq_fix ()#line:3759
elif mode ==9 :#line:3760
        wiz .quasar_menu ()#line:3761
elif mode ==5 :#line:3762
        swapSkins ('skin.Premium.mod')#line:3763
elif mode ==13 :#line:3764
        wiz .elementum_menu ()#line:3765
elif mode ==16 :#line:3766
        wiz .fix_wizard ()#line:3767
elif mode ==17 :#line:3768
        wiz .last_play ()#line:3769
elif mode ==18 :#line:3770
        wiz .normal_metalliq ()#line:3771
elif mode ==19 :#line:3772
        wiz .fast_metalliq ()#line:3773
elif mode ==20 :#line:3774
        wiz .fix_buffer2 ()#line:3775
elif mode ==21 :#line:3776
        wiz .fix_buffer3 ()#line:3777
elif mode ==11 :#line:3778
        wiz .fix_buffer ()#line:3779
elif mode ==15 :#line:3780
        wiz .fix_font ()#line:3781
elif mode ==14 :#line:3782
        wiz .clean_pass ()#line:3783
elif mode ==22 :#line:3784
        wiz .movie_update ()#line:3785
elif mode =='adv_settings':buffer1 ()#line:3786
elif mode =='getpass':getpass ()#line:3787
elif mode =='setpass':setpass ()#line:3788
elif mode =='9':disply_hwr ()#line:3789
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))